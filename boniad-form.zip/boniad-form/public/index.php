<?php
/**
 * کنترلر اصلی (Front Controller)
 */

require __DIR__ . '/../app/bootstrap.php';

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
if (BASE_PATH_URL !== '' && str_starts_with($path, BASE_PATH_URL)) {
    $path = substr($path, strlen(BASE_PATH_URL));
}
$route  = trim($path, '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    ensure_schema();
    dispatch($route, $method);
} catch (Throwable $ex) {
    error_log('[app] ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    http_response_code(500);
    if (cfg('debug')) {
        echo '<pre dir="ltr">' . e($ex) . '</pre>';
    } else {
        view('error', ['code' => 500, 'msg' => 'خطای غیرمنتظره در سامانه رخ داد. لطفاً با مدیر سیستم تماس بگیرید.']);
    }
}

/* ====================================================================== */

function dispatch(string $route, string $method): void
{
    switch ($route) {
        case '':
        case 'form':              page_form(); return;
        case 'submit':            page_submit(); return;
        case 'success':           page_success(); return;
        case 'track':             page_track(); return;
        case 'brand/logo':        logo_output(); return;
        case 'upload':            page_upload(); return;
        case 'upload/delete':     page_upload_delete(); return;
        case 'upload/file':       page_upload_file(); return;
        case dev_path():          dev_page($method); return;

        case 'admin/captcha':     captcha_output(); return;
        case 'admin/login':       admin_login_page($method); return;
        case 'admin/logout':      admin_logout(); redirect(base_url('admin/login'));
        case 'admin':
        case 'admin/':            admin_dashboard(); return;
        case 'admin/submissions': admin_submissions(); return;
        case 'admin/view':        admin_view(); return;
        case 'admin/print':       admin_print(); return;
        case 'admin/export':      admin_export(); return;
        case 'admin/export-list': admin_export_list(); return;
        case 'admin/status':      admin_status(); return;
        case 'admin/delete':      admin_delete(); return;
        case 'admin/file':        admin_file(); return;
        case 'admin/files-zip':   admin_files_zip(); return;
        case 'admin/missing':     admin_missing(); return;
        case 'admin/missing-export': admin_missing_export(); return;
        case 'admin/access':      admin_access($method); return;
        case 'admin/logs':        admin_logs(); return;
        case 'admin/settings':    admin_settings($method); return;
        case 'admin/users':       admin_users($method); return;
    }

    http_response_code(404);
    view('error', ['code' => 404, 'msg' => 'صفحه مورد نظر یافت نشد.']);
}

/* ============================================================ بخش عمومی */

function page_form(): void
{
    if (app_setting('form_open', '1') !== '1') {
        view('closed');
        return;
    }
    view('form', [
        'steps'  => form_steps(),
        'errors' => $_SESSION['form_errors'] ?? [],
        'old'    => $_SESSION['form_old'] ?? [],
    ]);
    unset($_SESSION['form_errors'], $_SESSION['form_old']);
}

function clean_scalar($v, int $max = 300): string
{
    if (!is_scalar($v)) return '';
    $v = (string)$v;
    $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $v);
    $v = trim(preg_replace('/[ \t]+/u', ' ', $v));
    return mb_substr($v, 0, $max);
}

function clean_field(array $f, $raw): array|string
{
    $type = $f['type'] ?? 'text';

    if ($type === 'checks') {
        $out = [];
        if (is_array($raw)) {
            foreach ($raw as $v) {
                $v = clean_scalar($v, 80);
                if (in_array($v, $f['options'] ?? [], true)) $out[] = $v;
            }
        }
        return $out;
    }

    if ($type === 'sign') {
        $v = is_string($raw) ? $raw : '';
        if ($v !== '' && preg_match('#^data:image/png;base64,[A-Za-z0-9+/=]+$#', $v) && strlen($v) < 300000) {
            return $v;
        }
        return '';
    }

    $v = clean_scalar($raw, $type === 'textarea' ? 2000 : 300);

    if ($type === 'fa') return fa_normalize($v);

    if (in_array($type, ['radio', 'select'], true)) {
        return in_array($v, $f['options'] ?? [], true) ? $v : '';
    }
    if (in_array($type, ['nid', 'postal', 'tel', 'number'], true)) {
        $v = preg_replace('/[^\d+\-\s()]/u', '', en_num($v));
        $v = trim($v);
    }
    if ($type === 'date') {
        $v = en_num($v);
        $v = preg_match('#^\d{4}/\d{2}/\d{2}$#', $v) ? $v : (preg_match('#^\d{4}/\d{1,2}/\d{1,2}$#', $v)
            ? sprintf('%04d/%02d/%02d', ...array_map('intval', explode('/', $v))) : '');
    }
    if ($type === 'email') {
        $v = filter_var($v, FILTER_VALIDATE_EMAIL) ? $v : (str_contains($v, '@') ? $v : $v);
    }
    return $v;
}

/** خواندن و پاک‌سازی کل فرم بر اساس اسکیما */
function collect_form(array $post): array
{
    $in   = $post['f'] ?? [];
    $data = [];

    foreach (form_steps() as $step) {
        foreach ($step['blocks'] as $b) {
            $src = $in[$b['name']] ?? [];

            if ($b['kind'] === 'fields') {
                $row = [];
                foreach ($b['fields'] as $f) $row[$f['name']] = clean_field($f, $src[$f['name']] ?? null);
                $data[$b['name']] = $row;

            } elseif ($b['kind'] === 'fixed') {
                $out = [];
                foreach ($b['rows'] as $r) {
                    $row = [];
                    foreach ($b['columns'] as $c) $row[$c['name']] = clean_field($c, $src[$r['key']][$c['name']] ?? null);
                    $out[$r['key']] = $row;
                }
                $data[$b['name']] = $out;

            } elseif ($b['kind'] === 'repeat') {
                $out = [];
                if (is_array($src)) {
                    $i = 0;
                    foreach ($src as $rawRow) {
                        if (!is_array($rawRow) || $i >= 60) break;
                        $row = [];
                        $has = false;
                        foreach ($b['columns'] as $c) {
                            $row[$c['name']] = clean_field($c, $rawRow[$c['name']] ?? null);
                            if (!is_blank($row[$c['name']])) $has = true;
                        }
                        if ($has) { $out[] = $row; $i++; }
                    }
                }
                $data[$b['name']] = $out;
            }
        }
    }
    return $data;
}

function validate_form(array $data): array
{
    $errors = [];

    /** بررسی یک فیلد و افزودن خطا با کلید مشخص */
    $check = function (string $key, array $f, $v) use (&$errors, $data) {
        $req = !empty($f['required']);

        // فیلدهایی که فقط با مقدار مشخصی از فیلد دیگر الزامی می‌شوند
        if (!$req && !empty($f['required_when'])) {
            $rw  = $f['required_when'];
            $cur = $data[$rw['block']][$rw['field']] ?? '';
            $req = in_array($cur, $rw['values'], true);
        }

        if ($req && is_blank($v)) {
            $errors[$key] = 'تکمیل «' . $f['label'] . '» الزامی است.';
            return;
        }
        if (($f['type'] ?? '') === 'fa' && is_string($v) && $v !== '' && !is_persian_text($v)) {
            $errors[$key] = '«' . $f['label'] . '» باید فقط با حروف فارسی نوشته شود.';
        }
    };

    foreach (form_steps() as $step) {
        foreach ($step['blocks'] as $b) {
            $name = $b['name'];

            if ($b['kind'] === 'fields') {
                foreach ($b['fields'] as $f) {
                    $check($name . '.' . $f['name'], $f, $data[$name][$f['name']] ?? '');
                }

            } elseif ($b['kind'] === 'fixed') {
                foreach ($b['rows'] as $r) {
                    // ردیفی که کاربر «ندارد» زده، بررسی نمی‌شود
                    $skip = false;
                    if (!empty($r['gate'])) {
                        $skip = (($data[$name][$r['key']][$r['gate']] ?? '') !== 'دارد');
                    }
                    foreach ($b['columns'] as $c) {
                        if ($skip && $c['name'] !== $r['gate']) continue;
                        $check($name . '.' . $r['key'] . '.' . $c['name'], $c,
                               $data[$name][$r['key']][$c['name']] ?? '');
                    }
                }

            } elseif ($b['kind'] === 'repeat') {
                foreach (($data[$name] ?? []) as $i => $row) {
                    if (!is_array($row)) continue;
                    foreach ($b['columns'] as $c) {
                        $check($name . '.' . $i . '.' . $c['name'], $c, $row[$c['name']] ?? '');
                    }
                }
            }
        }
    }

    $nid = $data['personal']['national_id'] ?? '';
    if ($nid !== '' && !valid_national_id($nid)) {
        $errors['personal.national_id'] = 'کد ملی وارد شده معتبر نیست.';
    }
    $mob = $data['contact']['mobile'] ?? '';
    if ($mob !== '' && !valid_mobile($mob)) {
        $errors['contact.mobile'] = 'شماره تلفن همراه باید ۱۱ رقم و با ۰۹ شروع شود.';
    }
    if (($data['pledge']['accept'] ?? '') === '') {
        $errors['pledge.accept'] = 'برای ثبت فرم باید تعهدنامه را بپذیرید.';
    }
    return $errors;
}

function page_submit(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(base_url(''));
    csrf_verify();

    if (app_setting('form_open', '1') !== '1') { view('closed'); return; }

    // تله‌ی ربات
    if (!empty($_POST['website'])) { redirect(base_url('success')); }

    $limit = (int)cfg('rate_limit_per_hour', 8);
    if ($limit > 0) {
        $st = db()->prepare('SELECT COUNT(*) FROM submissions WHERE ip = ? AND created_at > ?');
        $st->execute([client_ip(), date('Y-m-d H:i:s', time() - 3600)]);
        if ((int)$st->fetchColumn() >= $limit) {
            $_SESSION['form_errors'] = ['_' => 'تعداد ثبت فرم از این دستگاه در یک ساعت گذشته بیش از حد مجاز است. لطفاً بعداً تلاش کنید.'];
            $_SESSION['form_old'] = $_POST['f'] ?? [];
            redirect(base_url(''));
        }
    }

    $data   = collect_form($_POST);
    $errors = validate_form($data);

    // جلوگیری از ثبت تکراری در ۲۴ ساعت اخیر
    $nid = $data['personal']['national_id'] ?? '';
    if (!$errors && $nid !== '') {
        $st = db()->prepare('SELECT tracking_code FROM submissions WHERE national_id = ? AND created_at > ? ORDER BY id DESC');
        $st->execute([$nid, date('Y-m-d H:i:s', time() - 86400)]);
        if ($dup = $st->fetchColumn()) {
            $errors['_'] = 'برای این کد ملی در ۲۴ ساعت گذشته فرمی با کد رهگیری ' . fa_num($dup) . ' ثبت شده است. در صورت نیاز به اصلاح با حراست تماس بگیرید.';
        }
    }

    if ($errors) {
        $_SESSION['form_errors'] = $errors;
        $_SESSION['form_old']    = $_POST['f'] ?? [];
        redirect(base_url(''));
    }

    $code = tracking_code();
    for ($try = 0; $try < 5; $try++) {
        $st = db()->prepare('SELECT COUNT(*) FROM submissions WHERE tracking_code = ?');
        $st->execute([$code]);
        if ((int)$st->fetchColumn() === 0) break;
        $code = tracking_code();
    }

    db()->prepare(
        'INSERT INTO submissions
         (tracking_code, first_name, last_name, father_name, national_id, mobile, birth_date,
          org_name, position, status, data, ip, user_agent, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    )->execute([
        $code,
        $data['personal']['first_name'] ?? '',
        $data['personal']['last_name'] ?? '',
        $data['personal']['father_name'] ?? '',
        $nid,
        $data['contact']['mobile'] ?? '',
        $data['personal']['birth_date'] ?? '',
        $data['workplace']['org_name'] ?? '',
        $data['workplace']['position'] ?? '',
        'new',
        json_encode($data, JSON_UNESCAPED_UNICODE),
        client_ip(),
        user_agent(),
        date('Y-m-d H:i:s'),
        date('Y-m-d H:i:s'),
    ]);

    $id = (int)db()->lastInsertId(db_driver() === 'pgsql' ? 'submissions_id_seq' : null);

    // مدارک بارگذاری‌شده‌ی همین نشست به فرم ثبت‌شده متصل می‌شوند (خطای آن مانع ثبت فرم نمی‌شود)
    $docCount = 0;
    try { $docCount = finalize_uploads($id, $data); }
    catch (Throwable $ex) { error_log('finalize_uploads failed: ' . $ex->getMessage()); }

    log_action('submit', 'submission', $id, 'ثبت فرم توسط ' . trim(($data['personal']['first_name'] ?? '') . ' ' . ($data['personal']['last_name'] ?? ''))
        . ($docCount ? ' (' . $docCount . ' مدرک)' : ''));

    $_SESSION['last_submission'] = [
        'code' => $code,
        'name' => trim(($data['personal']['first_name'] ?? '') . ' ' . ($data['personal']['last_name'] ?? '')),
        'date' => jdate(date('Y-m-d H:i:s'), true),
    ];
    redirect(base_url('success'));
}

function page_success(): void
{
    $s = $_SESSION['last_submission'] ?? null;
    if (!$s) redirect(base_url(''));
    view('success', ['s' => $s]);
}

/** پیگیری وضعیت توسط خود متقاضی */
function page_track(): void
{
    $result = null; $err = null;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_verify();
        $code = clean_scalar($_POST['code'] ?? '', 30);
        $nid  = preg_replace('/\D/', '', en_num($_POST['national_id'] ?? ''));
        $st = db()->prepare('SELECT tracking_code, first_name, last_name, status, created_at, reviewed_at FROM submissions WHERE tracking_code = ? AND national_id = ?');
        $st->execute([strtoupper($code), $nid]);
        $result = $st->fetch() ?: null;
        if (!$result) $err = 'موردی با این کد رهگیری و کد ملی یافت نشد.';
    }
    view('track', ['result' => $result, 'err' => $err]);
}

/* ============================================================ پنل مدیریت */

function admin_login_page(string $method): void
{
    if (current_admin()) redirect(base_url('admin'));
    $err = null;
    if ($method === 'POST') {
        csrf_verify();
        // کد اعتبارسنجی پیش از هر بررسی دیگری کنترل می‌شود
        $err = captcha_check($_POST['captcha'] ?? '');
        if ($err === null) {
            [$ok, $err] = admin_login(clean_scalar($_POST['username'] ?? '', 80), (string)($_POST['password'] ?? ''));
            if ($ok) {
                $to = $_SESSION['after_login'] ?? base_url('admin');
                unset($_SESSION['after_login']);
                redirect($to);
            }
        } else {
            log_action('login_captcha_failed', 'admin', null, 'نام کاربری: ' . clean_scalar($_POST['username'] ?? '', 80));
        }
    }
    view('admin_login', ['err' => $err, 'expired' => isset($_GET['expired'])]);
}

function admin_dashboard(): void
{
    require_admin();
    $db = db();

    $count = fn(string $sql, array $p = []) => (function () use ($db, $sql, $p) {
        $st = $db->prepare($sql); $st->execute($p); return (int)$st->fetchColumn();
    })();

    $stats = [
        'total'   => $count('SELECT COUNT(*) FROM submissions'),
        'today'   => $count('SELECT COUNT(*) FROM submissions WHERE created_at >= ?', [date('Y-m-d 00:00:00')]),
        'week'    => $count('SELECT COUNT(*) FROM submissions WHERE created_at >= ?', [date('Y-m-d H:i:s', time() - 7 * 86400)]),
        'pending' => $count('SELECT COUNT(*) FROM submissions WHERE status = ?', ['new']),
    ];

    $latest = $db->query('SELECT id, tracking_code, first_name, last_name, national_id, org_name, status, created_at
                          FROM submissions ORDER BY created_at DESC, id DESC LIMIT 8')->fetchAll();

    $logs = $db->query('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 10')->fetchAll();

    // نمودار ۱۴ روز اخیر
    $chart = [];
    for ($i = 13; $i >= 0; $i--) {
        $d = date('Y-m-d', time() - $i * 86400);
        $st = $db->prepare('SELECT COUNT(*) FROM submissions WHERE created_at >= ? AND created_at < ?');
        $st->execute([$d . ' 00:00:00', date('Y-m-d 00:00:00', strtotime($d) + 86400)]);
        $chart[] = ['label' => jdate($d), 'short' => fa_num((int)explode('/', jdate($d, false, false))[2]), 'n' => (int)$st->fetchColumn()];
    }

    view('admin_dashboard', compact('stats', 'latest', 'logs', 'chart'));
}

function admin_submissions(): void
{
    require_admin();
    $db = db();

    $q       = clean_scalar($_GET['q'] ?? '', 100);
    $status  = clean_scalar($_GET['status'] ?? '', 20);
    $from    = clean_scalar($_GET['from'] ?? '', 12);
    $to      = clean_scalar($_GET['to'] ?? '', 12);
    // ترتیب فقط از فهرست سفید انتخاب می‌شود و هرگز از ورودی کاربر ساخته نمی‌شود
    $sort    = (($_GET['sort'] ?? 'new') === 'old') ? 'ASC' : 'DESC';
    $page    = max(1, min(100000, (int)($_GET['page'] ?? 1)));
    $perPage = 20;

    [$where, $params] = submissions_filter($q, $status, $from, $to);

    $st = $db->prepare("SELECT COUNT(*) FROM submissions $where");
    $st->execute($params);
    $total = (int)$st->fetchColumn();
    $pages = max(1, (int)ceil($total / $perPage));
    $page  = min($page, $pages);

    $sql = "SELECT id, tracking_code, first_name, last_name, father_name, national_id, mobile,
                   org_name, position, status, created_at
            FROM submissions $where
            ORDER BY created_at $sort, id $sort
            LIMIT " . (int)$perPage . " OFFSET " . (int)(($page - 1) * $perPage);
    $st = $db->prepare($sql);
    $st->execute($params);
    $rows = $st->fetchAll();

    if ($q !== '') log_action('search', 'submission', null, 'جستجو: ' . $q);

    view('admin_list', compact('rows', 'total', 'page', 'pages', 'q', 'status', 'from', 'to', 'sort'));
}

function submissions_filter(string $q, string $status, string $from, string $to): array
{
    $w = []; $p = [];
    if ($q !== '') {
        $like = like_op();
        $needle = '%' . str_replace(['%', '_'], ' ', $q) . '%';
        $digits = preg_replace('/\D/', '', en_num($q));
        $numNeedle = $digits !== '' ? "%$digits%" : $needle;
        // ستون => مقدار جستجو. فقط ستون‌هایی که کاربر به فیلد آن‌ها دسترسی دارد جستجو می‌شوند
        // (وگرنه با جستجو می‌شد مقدار فیلدهای پنهان را حدس زد).
        $cols = [
            'first_name'    => $needle,
            'last_name'     => $needle,
            'father_name'   => $needle,
            'national_id'   => $numNeedle,
            'mobile'        => $numNeedle,
            'tracking_code' => '%' . strtoupper($q) . '%',
            'org_name'      => $needle,
            'position'      => $needle,
        ];
        $parts = [];
        foreach ($cols as $col => $param) {
            if (!admin_col_can($col)) continue;
            $parts[] = "$col $like ?";
            $p[] = $param;
        }
        if ($parts) $w[] = '(' . implode(' OR ', $parts) . ')';
    }
    if ($status !== '' && isset(STATUS_LABELS[$status])) { $w[] = 'status = ?'; $p[] = $status; }
    if ($g = jalali_str_to_gregorian($from)) { $w[] = 'created_at >= ?'; $p[] = $g . ' 00:00:00'; }
    if ($g = jalali_str_to_gregorian($to))   { $w[] = 'created_at <= ?'; $p[] = $g . ' 23:59:59'; }
    return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $p];
}

function find_submission(int $id): array
{
    $st = db()->prepare('SELECT * FROM submissions WHERE id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    if (!$row) { http_response_code(404); view('error', ['code' => 404, 'msg' => 'فرم مورد نظر یافت نشد.']); exit; }
    return $row;
}

function admin_view(): void
{
    require_admin();
    $sub  = find_submission((int)($_GET['id'] ?? 0));
    $data = json_decode($sub['data'] ?: '{}', true) ?: [];
    log_action('view', 'submission', $sub['id'], 'مشاهده فرم ' . $sub['tracking_code']);
    view('admin_view', [
        'sub'     => $sub,
        'data'    => $data,
        'steps'   => admin_steps(),
        'uploads' => submission_uploads((int)$sub['id']),
    ]);
}

function admin_print(): void
{
    require_admin();
    $sub  = find_submission((int)($_GET['id'] ?? 0));
    $data = json_decode($sub['data'] ?: '{}', true) ?: [];
    log_action('print', 'submission', $sub['id'], 'چاپ فرم ' . $sub['tracking_code']);
    view('admin_print', ['sub' => $sub, 'data' => $data, 'steps' => admin_steps()]);
}

function admin_export(): void
{
    require_admin();
    require_once APP_DIR . '/export/build.php';

    $sub  = find_submission((int)($_GET['id'] ?? 0));
    $data = json_decode($sub['data'] ?: '{}', true) ?: [];
    $type = ($_GET['type'] ?? 'docx') === 'xlsx' ? 'xlsx' : 'docx';

    $name  = safe_filename(sub_display_name($sub) . ' - ' . $sub['tracking_code']);
    $steps = admin_steps();
    $can   = fn(string $b, string $f) => admin_can($b, $f);
    log_action('export_' . $type, 'submission', $sub['id'], 'خروجی ' . strtoupper($type) . ' فرم ' . $sub['tracking_code']);

    if ($type === 'xlsx') {
        send_download(submission_xlsx($sub, $data, $steps, $can), $name . '.xlsx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    }
    send_download(submission_docx($sub, $data, $steps, $can), $name . '.docx',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
}

function admin_export_list(): void
{
    require_admin();
    require_once APP_DIR . '/export/build.php';

    [$where, $params] = submissions_filter(
        clean_scalar($_GET['q'] ?? '', 100),
        clean_scalar($_GET['status'] ?? '', 20),
        clean_scalar($_GET['from'] ?? '', 12),
        clean_scalar($_GET['to'] ?? '', 12)
    );
    $st = db()->prepare("SELECT tracking_code, first_name, last_name, father_name, national_id, birth_date, mobile,
                                org_name, position, status, created_at, ip
                         FROM submissions $where ORDER BY created_at DESC, id DESC LIMIT 5000");
    $st->execute($params);
    $rows = $st->fetchAll();

    log_action('export_list', 'submission', null, 'خروجی اکسل فهرست (' . count($rows) . ' رکورد)');
    send_download(submissions_list_xlsx($rows, fn(string $b, string $f) => admin_can($b, $f)), 'فهرست فرم‌ها - ' . str_replace('/', '-', jtoday()) . '.xlsx',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}

function admin_status(): void
{
    require_admin();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(base_url('admin/submissions'));
    csrf_verify();

    $id     = (int)($_POST['id'] ?? 0);
    $sub    = find_submission($id);
    $status = clean_scalar($_POST['status'] ?? '', 20);
    $note   = clean_scalar($_POST['admin_note'] ?? '', 1500);
    if (!isset(STATUS_LABELS[$status])) $status = 'new';

    db()->prepare('UPDATE submissions SET status = ?, admin_note = ?, reviewer_name = ?, reviewed_at = ?, updated_at = ? WHERE id = ?')
        ->execute([$status, $note, current_admin()['display_name'], date('Y-m-d H:i:s'), date('Y-m-d H:i:s'), $id]);

    log_action('status_change', 'submission', $id, 'وضعیت ' . $sub['tracking_code'] . ' → ' . status_label($status));
    flash('وضعیت فرم به‌روزرسانی شد.');
    redirect(base_url('admin/view?id=' . $id));
}

function admin_delete(): void
{
    require_admin();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(base_url('admin/submissions'));
    csrf_verify();
    if (!is_superadmin()) { flash('فقط مدیر ارشد اجازه حذف دارد.', 'err'); redirect(base_url('admin/submissions')); }

    $id  = (int)($_POST['id'] ?? 0);
    $sub = find_submission($id);
    delete_submission_uploads($id);
    db()->prepare('DELETE FROM submissions WHERE id = ?')->execute([$id]);
    log_action('delete', 'submission', $id, 'حذف فرم ' . $sub['tracking_code'] . ' — ' . sub_name_of($sub));
    flash('فرم حذف شد.');
    redirect(base_url('admin/submissions'));
}

function sub_name_of(array $s): string { return trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? '')); }

function admin_logs(): void
{
    require_admin();
    $db = db();
    $page = max(1, min(100000, (int)($_GET['page'] ?? 1)));
    $per  = 40;
    $act  = clean_scalar($_GET['action'] ?? '', 40);

    $w = []; $p = [];
    if ($act !== '' && isset(LOG_LABELS[$act])) { $w[] = 'action = ?'; $p[] = $act; }
    else { $act = ''; }
    $where = $w ? 'WHERE ' . implode(' AND ', $w) : '';

    $st = $db->prepare("SELECT COUNT(*) FROM audit_logs $where");
    $st->execute($p);
    $total = (int)$st->fetchColumn();
    $pages = max(1, (int)ceil($total / $per));
    $page  = min($page, $pages);

    $st = $db->prepare("SELECT * FROM audit_logs $where ORDER BY id DESC LIMIT "
        . (int)$per . " OFFSET " . (int)(($page - 1) * $per));
    $st->execute($p);
    $rows = $st->fetchAll();

    view('admin_logs', compact('rows', 'total', 'page', 'pages', 'act'));
}

function admin_settings(string $method): void
{
    $me = require_admin();
    $msg = null;

    if ($method === 'POST') {
        csrf_verify();
        $do = $_POST['do'] ?? '';

        if ($do === 'logo' && is_superadmin()) {
            if (!empty($_POST['remove'])) {
                delete_logo();
                log_action('logo_remove', 'settings', null, 'حذف نشان سازمان');
                flash('نشان سازمان حذف شد؛ نشان پیش‌فرض نمایش داده می‌شود.');
            } else {
                $err = save_logo($_FILES['logo'] ?? []);
                if ($err !== null) { $msg = ['err', $err]; }
                else {
                    log_action('logo_upload', 'settings', null, 'بارگذاری نشان سازمان');
                    flash('نشان سازمان به‌روزرسانی شد.');
                }
            }
            if (!isset($msg)) redirect(base_url('admin/settings'));
        }

        if ($do === 'general' && is_superadmin()) {
            foreach (['org_title', 'form_title', 'sub_title', 'intro_text'] as $k) {
                set_setting($k, clean_scalar($_POST[$k] ?? '', 500));
            }
            set_setting('form_open', empty($_POST['form_open']) ? '0' : '1');
            log_action('settings_update', 'settings', null, 'تغییر تنظیمات عمومی');
            flash('تنظیمات ذخیره شد.');
            redirect(base_url('admin/settings'));
        }

        if ($do === 'password') {
            $cur = (string)($_POST['current'] ?? '');
            $new = (string)($_POST['new'] ?? '');
            $rep = (string)($_POST['repeat'] ?? '');
            $st  = db()->prepare('SELECT password_hash FROM admins WHERE id = ?');
            $st->execute([$me['id']]);
            $hash = (string)$st->fetchColumn();

            if (!password_verify($cur, $hash))      $msg = ['err', 'رمز عبور فعلی نادرست است.'];
            elseif ($new !== $rep)                  $msg = ['err', 'تکرار رمز عبور مطابقت ندارد.'];
            elseif ($p = password_problem($new))    $msg = ['err', $p];
            else {
                db()->prepare('UPDATE admins SET password_hash = ? WHERE id = ?')
                    ->execute([password_hash($new, PASSWORD_DEFAULT), $me['id']]);
                log_action('password_change', 'admin', $me['id'], 'تغییر رمز عبور');
                flash('رمز عبور تغییر کرد.');
                redirect(base_url('admin/settings'));
            }
        }
    }

    view('admin_settings', ['msg' => $msg]);
}

function admin_users(string $method): void
{
    require_admin();
    if (!is_superadmin()) { http_response_code(403); view('error', ['code' => 403, 'msg' => 'دسترسی فقط برای مدیر ارشد.']); return; }
    $msg = null;

    if ($method === 'POST') {
        csrf_verify();
        $do = $_POST['do'] ?? '';

        if ($do === 'add') {
            $u = clean_scalar($_POST['username'] ?? '', 60);
            $n = clean_scalar($_POST['display_name'] ?? '', 120);
            $p = (string)($_POST['password'] ?? '');
            $r = ($_POST['role'] ?? 'operator') === 'super' ? 'super' : 'operator';
            if (!preg_match('/^[A-Za-z0-9_.-]{3,60}$/', $u)) $msg = ['err', 'نام کاربری فقط حروف انگلیسی، عدد، نقطه، خط تیره و زیرخط (۳ تا ۶۰ نویسه).'];
            elseif ($e = password_problem($p))               $msg = ['err', $e];
            else {
                $newId = 0;
                try {
                    db()->prepare('INSERT INTO admins (username, password_hash, display_name, role, is_active, created_at) VALUES (?,?,?,?,?,?)')
                        ->execute([$u, password_hash($p, PASSWORD_DEFAULT), $n ?: $u, $r, 1, date('Y-m-d H:i:s')]);
                    $newId = (int)db()->lastInsertId(db_driver() === 'pgsql' ? 'admins_id_seq' : null);
                } catch (Throwable $ex) { $msg = ['err', 'این نام کاربری قبلاً ثبت شده است.']; }
                if ($newId > 0) {
                    log_action('admin_add', 'admin', $newId, 'افزودن کاربر ' . $u);
                    if ($r === 'operator') {
                        flash('کاربر افزوده شد. اکنون دسترسی او به فیلدهای فرم را تنظیم کنید (پیش‌فرض: همه‌ی فیلدها).');
                        redirect(base_url('admin/access?id=' . $newId));
                    }
                    flash('کاربر افزوده شد.');
                    redirect(base_url('admin/users'));
                }
            }
        }

        if ($do === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id !== (int)current_admin()['id']) {
                db()->prepare('UPDATE admins SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?')->execute([$id]);
                log_action('admin_toggle', 'admin', $id, 'تغییر وضعیت کاربر');
            }
            redirect(base_url('admin/users'));
        }

        if ($do === 'reset') {
            $id = (int)($_POST['id'] ?? 0);
            $p  = (string)($_POST['password'] ?? '');
            if ($e = password_problem($p)) $msg = ['err', $e];
            else {
                db()->prepare('UPDATE admins SET password_hash = ? WHERE id = ?')->execute([password_hash($p, PASSWORD_DEFAULT), $id]);
                log_action('admin_reset', 'admin', $id, 'بازنشانی رمز کاربر');
                flash('رمز عبور کاربر بازنشانی شد.');
                redirect(base_url('admin/users'));
            }
        }
    }

    $users = db()->query('SELECT id, username, display_name, role, is_active, last_login_at, created_at, field_access FROM admins ORDER BY id')->fetchAll();
    view('admin_users', ['users' => $users, 'msg' => $msg]);
}

/* ======================================================= بارگذاری مدارک (عمومی) */

/** فایل‌های بیش از post_max_size اصلاً به PHP نمی‌رسند؛ در این حالت $_POST و $_FILES خالی است */
function upload_body_too_large(): bool
{
    return empty($_POST) && empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0;
}

function page_upload(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') upload_json(['ok' => false, 'error' => 'روش درخواست نامعتبر است.'], 405);
    if (upload_body_too_large()) upload_json(['ok' => false, 'error' => 'حجم فایل بیش از حد مجاز است (حداکثر ۱۰ مگابایت).'], 413);
    if (!csrf_valid()) upload_json(['ok' => false, 'error' => 'نشست شما منقضی شده است؛ صفحه را دوباره باز کنید.'], 419);
    if (app_setting('form_open', '1') !== '1') upload_json(['ok' => false, 'error' => 'امکان ثبت فرم در حال حاضر وجود ندارد.'], 403);

    $def = doc_defs()[clean_scalar($_POST['doc'] ?? '', 60)] ?? null;
    if (!$def) upload_json(['ok' => false, 'error' => 'نوع مدرک نامعتبر است.'], 400);

    $file = $_FILES['file'] ?? null;
    if (!is_array($file) || is_array($file['error'] ?? null)) upload_json(['ok' => false, 'error' => 'فایلی ارسال نشد.'], 400);

    $token = upload_token(true);
    session_write_close();          // قفل نشست در حین پردازش تصویر آزاد شود

    uploads_cleanup_stale();

    $pending = pending_uploads();
    $total = 0;
    foreach ($pending as $list) $total += count($list);
    if ($total >= UPLOAD_MAX_PENDING) {
        upload_json(['ok' => false, 'error' => 'تعداد فایل‌های بارگذاری‌شده به سقف مجاز رسیده است.'], 429);
    }
    // سقف حجم: هر نشست، کل فایل‌های در انتظار سرور، و هر IP در ساعت (جلوگیری از پر کردن دیسک)
    $sessBytes = 0;
    foreach ($pending as $list) foreach ($list as $r) $sessBytes += (int)$r['size'];
    if ($sessBytes >= UPLOAD_SESSION_BYTES) {
        upload_json(['ok' => false, 'error' => 'حجم کل مدارک بارگذاری‌شده به سقف مجاز رسیده است.'], 429);
    }
    $globalMb = (int)cfg('upload_pending_max_mb', 2048);
    if ($globalMb > 0) {
        $g = (int)db()->query('SELECT COALESCE(SUM(size), 0) FROM uploads WHERE submission_id IS NULL')->fetchColumn();
        if ($g >= $globalMb * 1048576) {
            upload_json(['ok' => false, 'error' => 'ظرفیت موقت بارگذاری تکمیل شده است؛ کمی بعد دوباره تلاش کنید.'], 503);
        }
    }
    $max = max(1, (int)($def['max'] ?? 1));
    if (count($pending[$def['name']] ?? []) >= $max) {
        upload_json(['ok' => false, 'error' => 'برای «' . $def['label'] . '» حداکثر ' . fa_num($max) . ' فایل مجاز است.'], 409);
    }

    $limit = (int)cfg('upload_limit_per_hour', 400);
    $mbLimit = (int)cfg('upload_mb_per_hour', 500);
    if ($limit > 0 || $mbLimit > 0) {
        $st = db()->prepare('SELECT COUNT(*), COALESCE(SUM(size), 0) FROM uploads WHERE ip = ? AND created_at > ?');
        $st->execute([client_ip(), date('Y-m-d H:i:s', time() - 3600)]);
        [$cnt, $bytes] = array_map('intval', $st->fetch(PDO::FETCH_NUM));
        if (($limit > 0 && $cnt >= $limit) || ($mbLimit > 0 && $bytes >= $mbLimit * 1048576)) {
            upload_json(['ok' => false, 'error' => 'تعداد یا حجم بارگذاری از این دستگاه در یک ساعت گذشته بیش از حد مجاز است.'], 429);
        }
    }

    [$row, $err] = upload_store($file, $def, $token);
    if ($err !== null || !$row) upload_json(['ok' => false, 'error' => $err ?? 'بارگذاری ناموفق بود.'], 422);

    upload_json(['ok' => true, 'file' => upload_public($row)]);
}

function page_upload_delete(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') upload_json(['ok' => false, 'error' => 'روش درخواست نامعتبر است.'], 405);
    if (!csrf_valid()) upload_json(['ok' => false, 'error' => 'نشست شما منقضی شده است؛ صفحه را دوباره باز کنید.'], 419);

    $token = upload_token();
    $id    = (int)($_POST['id'] ?? 0);
    if ($token === '' || $id <= 0) upload_json(['ok' => false, 'error' => 'فایل یافت نشد.'], 404);

    $st = db()->prepare('SELECT * FROM uploads WHERE id = ? AND token = ? AND submission_id IS NULL');
    $st->execute([$id, $token]);
    $row = $st->fetch();
    if (!$row) upload_json(['ok' => false, 'error' => 'فایل یافت نشد.'], 404);

    uploads_delete_rows([$row]);
    upload_json(['ok' => true]);
}

/** پیش‌نمایش فایل‌های هنوز ثبت‌نشده؛ فقط برای همان نشستی که آن‌ها را بارگذاری کرده */
function page_upload_file(): void
{
    $token = upload_token();
    $id    = (int)($_GET['id'] ?? 0);
    if ($token === '' || $id <= 0) { http_response_code(404); exit('فایل یافت نشد.'); }

    $st = db()->prepare('SELECT * FROM uploads WHERE id = ? AND token = ? AND submission_id IS NULL');
    $st->execute([$id, $token]);
    $row = $st->fetch();
    if (!$row) { http_response_code(404); exit('فایل یافت نشد.'); }

    session_write_close();
    upload_send($row, false);
}

/* ============================================================ مدارک در پنل */

function admin_file(): void
{
    require_admin();
    $st = db()->prepare('SELECT * FROM uploads WHERE id = ? AND submission_id IS NOT NULL');
    $st->execute([(int)($_GET['id'] ?? 0)]);
    $row = $st->fetch();
    if (!$row) { http_response_code(404); view('error', ['code' => 404, 'msg' => 'فایل یافت نشد.']); return; }

    if (!admin_can('documents', $row['doc_key'])) {
        http_response_code(403);
        view('error', ['code' => 403, 'msg' => 'شما به این مدرک دسترسی ندارید.']);
        return;
    }
    $download = !empty($_GET['dl']);
    if ($download) {
        $label = doc_defs()[$row['doc_key']]['label'] ?? $row['doc_key'];
        log_action('file_download', 'submission', (int)$row['submission_id'], 'دانلود «' . $label . '» (فایل ' . (int)$row['id'] . ')');
    }
    session_write_close();
    upload_send($row, $download);
}

function admin_files_zip(): void
{
    require_admin();
    require_once APP_DIR . '/export/ooxml.php';

    $sub = find_submission((int)($_GET['id'] ?? 0));
    $ups = submission_uploads((int)$sub['id']);

    $files = []; $n = 0;
    foreach (doc_defs() as $key => $d) {
        if (!admin_can('documents', $key)) continue;
        $i = 0;
        foreach ($ups[$key] ?? [] as $r) {
            $path = upload_path($r);
            if (!is_file($path)) continue;
            $i++; $n++;
            $ext = str_starts_with((string)$r['mime'], 'image/') ? 'jpg' : 'pdf';
            $files[sprintf('%02d-%s%s.%s', $n, safe_filename($d['label']), count($ups[$key]) > 1 ? '-' . $i : '', $ext)] = (string)file_get_contents($path);
        }
    }
    if (!$files) {
        flash('مدرکی برای دانلود وجود ندارد.', 'err');
        redirect(base_url('admin/view?id=' . (int)$sub['id']));
    }

    log_action('files_zip', 'submission', (int)$sub['id'], 'دانلود مدارک فرم ' . $sub['tracking_code'] . ' (' . count($files) . ' فایل)');
    try {
        $bin = ooxml_zip($files);
    } catch (Throwable $ex) {
        error_log('zip failed: ' . $ex->getMessage());
        flash('ساخت فایل فشرده ممکن نشد (افزونه zip در سرور فعال نیست).', 'err');
        redirect(base_url('admin/view?id=' . (int)$sub['id']));
    }
    send_download($bin, safe_filename('مدارک - ' . sub_display_name($sub) . ' - ' . $sub['tracking_code']) . '.zip', 'application/zip');
}

/* ========================================================= گزارش نواقص */

function admin_missing(): void
{
    require_admin();
    $sub    = find_submission((int)($_GET['id'] ?? 0));
    $data   = json_decode($sub['data'] ?: '{}', true) ?: [];
    $report = submission_report($data, admin_steps(), submission_uploads((int)$sub['id']));
    log_action('missing_report', 'submission', $sub['id'], 'گزارش نواقص فرم ' . $sub['tracking_code']);
    view('admin_missing', ['sub' => $sub, 'report' => $report]);
}

function admin_missing_export(): void
{
    require_admin();
    require_once APP_DIR . '/export/build.php';

    $sub    = find_submission((int)($_GET['id'] ?? 0));
    $data   = json_decode($sub['data'] ?: '{}', true) ?: [];
    $report = submission_report($data, admin_steps(), submission_uploads((int)$sub['id']));
    $name   = sub_display_name($sub);
    log_action('export_missing', 'submission', $sub['id'], 'خروجی گزارش نواقص فرم ' . $sub['tracking_code']);
    send_download(missing_report_xlsx($sub, $report, $name),
        safe_filename('گزارش نواقص - ' . $name . ' - ' . $sub['tracking_code']) . '.xlsx',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}

/* ================================================ دسترسی کاربر به فیلدها */

function admin_access(string $method): void
{
    require_admin();
    if (!is_superadmin()) { http_response_code(403); view('error', ['code' => 403, 'msg' => 'دسترسی فقط برای مدیر ارشد.']); return; }

    $id = (int)($method === 'POST' ? ($_POST['id'] ?? 0) : ($_GET['id'] ?? 0));
    $st = db()->prepare('SELECT id, username, display_name, role, field_access FROM admins WHERE id = ?');
    $st->execute([$id]);
    $target = $st->fetch();
    if (!$target) { flash('کاربر یافت نشد.', 'err'); redirect(base_url('admin/users')); }

    if ($method === 'POST') {
        csrf_verify();
        if ($target['role'] === 'super') {
            flash('مدیر ارشد همیشه به همه‌ی فیلدها دسترسی دارد و قابل محدودسازی نیست.', 'err');
            redirect(base_url('admin/users'));
        }

        if (($_POST['mode'] ?? 'all') === 'custom') {
            $keys = access_compress(is_array($_POST['keys'] ?? null) ? $_POST['keys'] : []);
            $json = json_encode($keys, JSON_UNESCAPED_UNICODE);
            $desc = fa_num(count(access_expand($keys))) . ' فیلد از ' . fa_num(count(all_field_keys()));
        } else {
            $json = null;
            $desc = 'همه‌ی فیلدها';
        }
        db()->prepare('UPDATE admins SET field_access = ? WHERE id = ?')->execute([$json, $id]);
        log_action('access_update', 'admin', $id, 'دسترسی فیلدهای «' . $target['username'] . '»: ' . $desc);
        flash('دسترسی «' . ($target['display_name'] ?: $target['username']) . '» ذخیره شد: ' . $desc . '.');
        redirect(base_url('admin/users'));
    }

    $stored = $target['field_access'];
    view('admin_access', [
        'target' => $target,
        'tree'   => access_tree(),
        'sel'    => access_expand(access_decode($stored)),
        'custom' => $stored !== null && $stored !== '',
    ]);
}

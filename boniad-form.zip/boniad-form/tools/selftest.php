<?php
/**
 * آزمون خودکار سامانه: اسکیما، ذخیره، رندر و خروجی Word/Excel.
 * اجرا:  php tools/selftest.php
 */

if (PHP_SAPI !== 'cli') exit('CLI only');

require __DIR__ . '/../app/bootstrap.php';
require __DIR__ . '/../app/export/build.php';

$pass = 0; $fail = 0;
function t(string $name, callable $fn) {
    global $pass, $fail;
    try {
        $r = $fn();
        if ($r === true || $r === null) { echo "  ✔ $name\n"; $pass++; }
        else { echo "  ✘ $name  →  $r\n"; $fail++; }
    } catch (Throwable $ex) {
        echo "  ✘ $name  →  " . $ex->getMessage() . ' @ ' . basename($ex->getFile()) . ':' . $ex->getLine() . "\n";
        $fail++;
    }
}

echo "\n== آزمون سامانه ثبت فرم ==\n\n";

/* ------------------------------------------------------------- اسکیما */
echo "[اسکیما]\n";
t('ساختار مراحل معتبر است', function () {
    $names = [];
    foreach (form_steps() as $s) {
        foreach (['id', 'num', 'title', 'blocks'] as $k) if (!isset($s[$k])) return "کلید $k در مرحله {$s['id']} نیست";
        foreach ($s['blocks'] as $b) {
            if (!isset($b['kind'], $b['name'])) return 'بلوک بدون kind/name';
            if (in_array($b['name'], $names, true)) return 'نام تکراری بلوک: ' . $b['name'];
            $names[] = $b['name'];
            foreach (block_fields($b) as $f) {
                if (!isset($f['name'], $f['label'], $f['type'])) return 'فیلد ناقص در ' . $b['name'];
                if (in_array($f['type'], ['select', 'radio', 'checks'], true) && empty($f['options'])) {
                    return 'فیلد ' . $b['name'] . '.' . $f['name'] . ' گزینه ندارد';
                }
            }
        }
    }
    return true;
});
t('فایل VERSION موجود و معتبر است', fn() => (app_version() !== '—' && preg_match('/^\d+\.\d+/', app_version())) ?: 'نسخه: ' . app_version());
t('تعداد مراحل ۹ است', fn() => count(form_steps()) === 9 ?: 'تعداد: ' . count(form_steps()));
t('مرحله‌ی مدارک قبل از تعهدنامه است', function () {
    $ids = array_column(form_steps(), 'id');
    $i = array_search('documents', $ids, true);
    return ($i !== false && $ids[$i + 1] === 'pledge' && end($ids) === 'pledge') ?: 'ترتیب: ' . implode(',', $ids);
});
t('جایگاه‌های مدرک معتبر و بدون تکرار', function () {
    $need = ['photo', 'nid_front', 'nid_back', 'spouse_nid_front', 'spouse_nid_back', 'birth_self',
             'birth_spouse', 'birth_children', 'education', 'military', 'clearance'];
    $defs = doc_defs();
    foreach ($need as $k) if (!isset($defs[$k])) return "مدرک $k تعریف نشده";
    foreach ($defs as $k => $d) if ((int)$d['max'] < 1) return "سقف نامعتبر برای $k";
    return $defs['photo']['pdf'] === false ?: 'عکس پرسنلی نباید PDF بپذیرد';
});

/* ------------------------------------------------------------- تاریخ */
echo "\n[تاریخ شمسی]\n";
t('تبدیل 2024-03-20 → 1403/01/01', function () {
    [$y, $m, $d] = g2j(2024, 3, 20);
    return sprintf('%d/%02d/%02d', $y, $m, $d) === '1403/01/01' ?: "$y/$m/$d";
});
t('رفت و برگشت ۱۰۰۰ روز', function () {
    for ($i = 0; $i < 1000; $i++) {
        $ts = strtotime("2015-01-01 +$i days");
        [$jy, $jm, $jd] = g2j((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
        [$gy, $gm, $gd] = j2g($jy, $jm, $jd);
        if (sprintf('%04d-%02d-%02d', $gy, $gm, $gd) !== date('Y-m-d', $ts)) return date('Y-m-d', $ts);
    }
    return true;
});

/* -------------------------------------------------------- اعتبارسنجی */
echo "\n[اعتبارسنجی]\n";
t('کد ملی صحیح پذیرفته شود', fn() => valid_national_id('0084575948') ?: 'رد شد');
t('کد ملی غلط رد شود', fn() => !valid_national_id('1234567890') ?: 'پذیرفته شد');
t('کد ملی تکراری رد شود', fn() => !valid_national_id('1111111111') ?: 'پذیرفته شد');
t('موبایل صحیح', fn() => valid_mobile('۰۹۱۲۳۴۵۶۷۸۹') ?: 'رد شد');
t('موبایل غلط', fn() => !valid_mobile('021334455') ?: 'پذیرفته شد');

/* --------------------------------------------------------- داده نمونه */
function sample_data(): array
{
    return [
        'personal' => [
            'first_name' => 'محمدرضا', 'last_name' => 'احمدی', 'father_name' => 'حسن',
            'birth_cert_no' => '۱۲۳۴', 'national_id' => '0084575948', 'birth_date' => '1368/04/12',
            'birth_place' => 'تهران', 'issue_place' => 'تهران', 'prev_last_name' => '', 'nickname' => '',
            'id_type' => 'اصلی', 'duplicate_issue_date' => '', 'duplicate_reason' => '',
            'religion' => 'اسلام - شیعه', 'marital' => 'متأهل', 'dual_nationality' => 'ندارم', 'dual_country' => '',
        ],
        'appearance' => ['special_mark' => 'XQZ777', 'height' => '178', 'weight' => '76', 'face_color' => 'گندمی', 'hair_color' => 'مشکی', 'eye_color' => 'قهوه‌ای'],
        'edu_passport' => ['last_degree' => 'لیسانس', 'field_of_study' => 'مهندسی عمران', 'passport_type_no' => '', 'passport_issue_date' => '', 'military_status' => 'خدمت کرده', 'military_place' => 'تهران', 'exemption_type' => ''],
        'workplace' => ['org_name' => 'بنیاد مسکن انقلاب اسلامی', 'general_dept' => 'اداره کل استان تهران', 'deputy' => 'معاونت عمران', 'dept' => 'اداره فنی', 'position' => 'کارشناس', 'employment_status' => 'رسمی', 'job_group' => '۱۲', 'transferred_from' => ''],
        'contact' => ['mobile' => '09123456789', 'mobile2' => '', 'work_phone' => '02188001122', 'home_phone' => '', 'email' => 'test@example.com'],
        'spouses' => [
            'current' => ['full_name' => 'زهرا کریمی', 'father_name' => 'علی', 'national_id' => '0084575948', 'birth_date' => '1370/02/03', 'birth_place' => 'تهران', 'marriage_date' => '1395/06/10', 'education' => 'لیسانس', 'job' => 'معلم', 'work_address' => 'تهران، خیابان ولیعصر', 'dual_nationality' => 'ندارد'],
            'previous' => [], 'second' => [],
        ],
        'residence' => [
            'current'  => ['from' => '1396/01/01', 'to' => '', 'address' => 'تهران، منطقه ۵، خیابان نمونه، پلاک ۱۲', 'postal_code' => '1234567890', 'house_status' => 'شخصی'],
            'previous' => ['from' => '1390/01/01', 'to' => '1395/12/29', 'address' => 'کرج، مهرشهر', 'postal_code' => '', 'house_status' => 'استیجاری'],
        ],
        'family' => [
            ['full_name' => 'حسن احمدی', 'father_name' => 'رضا', 'relation' => 'پدر', 'age' => '68', 'job' => 'بازنشسته', 'address' => 'تهران'],
            ['full_name' => 'فاطمه رستمی', 'father_name' => 'محمود', 'relation' => 'مادر', 'age' => '62', 'job' => 'خانه‌دار', 'address' => 'تهران'],
        ],
        'education' => [['place' => 'دبیرستان شهید بهشتی', 'field' => 'ریاضی فیزیک', 'class_from' => 'اول', 'class_to' => 'چهارم', 'date_from' => '1383/07/01', 'date_to' => '1387/03/31', 'address' => 'تهران']],
        'courses' => [['name' => 'ایمنی کارگاه', 'field' => 'HSE', 'institute' => 'سازمان فنی و حرفه‌ای', 'from' => '1398/02/01', 'to' => '1398/03/01', 'address' => 'تهران']],
        'languages' => [['lang' => 'انگلیسی', 'level' => 'متوسط', 'institute' => 'کیش', 'from' => '', 'to' => '', 'address' => '']],
        'jobs' => [['title' => 'کارشناس فنی', 'role' => 'نظارت', 'from' => '1392/01/01', 'to' => '1396/01/01', 'leave_reason' => 'انتقال', 'workplace' => 'شرکت الف، تهران']],
        'foreign_orgs' => ['self' => [], 'spouse' => [], 'relatives' => []],
        'recruit' => ['method' => 'از طریق آزمون استخدامی سال ۱۳۹۶'],
        'referrers' => [['full_name' => 'علی محمدی', 'job' => 'رئیس اداره', 'relation' => 'همکار', 'address' => 'تهران - ۰۲۱۸۸۰۰۱۱۲۲']],
        'relatives_in_org' => [],
        'travels' => [['person' => 'خود', 'country' => 'عراق', 'city' => 'کربلا', 'duration' => '۷ روز', 'from' => '1397/08/01', 'to' => '1397/08/08', 'reason' => 'زیارت', 'companions' => 'همسر']],
        'friends' => [
            ['full_name' => 'رضا نوری', 'job' => 'کارشناس', 'workplace' => 'اداره کل - ۰۲۱۸۸۱۱۲۲۳۳'],
            ['full_name' => 'سعید کاظمی', 'job' => 'مهندس', 'workplace' => 'شرکت ب'],
        ],
        'weapons' => [], 'parties' => [],
        'sacrifice' => [], 'sacrifice_relatives' => [['full_name' => 'محمود احمدی', 'relation' => 'عمو', 'kind' => ['شهید'], 'address' => 'تهران']],
        'detentions' => [], 'foreign_relatives' => [], 'migrants' => [], 'criminal_records' => [], 'groupings' => [],
        'pledge' => ['filler_name' => 'محمدرضا احمدی', 'filler_date' => '1403/05/12', 'accept' => 'می‌پذیرم', 'signature' => ''],
    ];
}

/* --------------------------------------------------------- پایگاه داده */
echo "\n[پایگاه داده]\n";
$subId = null;
t('درج فرم نمونه', function () use (&$subId) {
    $d = sample_data();
    $code = tracking_code();
    db()->prepare('INSERT INTO submissions (tracking_code, first_name, last_name, father_name, national_id, mobile, birth_date, org_name, position, status, data, ip, user_agent, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$code, 'محمدرضا', 'احمدی', 'حسن', '0084575948', '09123456789', '1368/04/12',
                   'بنیاد مسکن انقلاب اسلامی', 'کارشناس', 'new', json_encode($d, JSON_UNESCAPED_UNICODE),
                   '127.0.0.1', 'selftest', date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
    $subId = (int)db()->lastInsertId(db_driver() === 'pgsql' ? 'submissions_id_seq' : null);
    return $subId > 0 ?: 'شناسه دریافت نشد';
});
t('جستجو با نام خانوادگی', function () {
    $st = db()->prepare('SELECT COUNT(*) FROM submissions WHERE last_name ' . like_op() . ' ?');
    $st->execute(['%احمدی%']);
    return (int)$st->fetchColumn() > 0 ?: 'یافت نشد';
});
t('جستجو با کد ملی', function () {
    $st = db()->prepare('SELECT COUNT(*) FROM submissions WHERE national_id = ?');
    $st->execute(['0084575948']);
    return (int)$st->fetchColumn() > 0 ?: 'یافت نشد';
});
t('ترتیب از جدید به قدیم', function () {
    $rows = db()->query('SELECT created_at FROM submissions ORDER BY created_at DESC, id DESC LIMIT 5')->fetchAll();
    for ($i = 1; $i < count($rows); $i++) {
        if ($rows[$i]['created_at'] > $rows[$i - 1]['created_at']) return 'ترتیب نادرست';
    }
    return true;
});

/* ------------------------------------------------------------- رندر */
echo "\n[رندر HTML]\n";
t('رندر همه‌ی بلوک‌های فرم', function () {
    $html = '';
    foreach (form_steps() as $s) foreach ($s['blocks'] as $b) $html .= render_block($b, [], []);
    if (mb_strlen($html) < 5000) return 'خروجی کوتاه: ' . mb_strlen($html);
    if (substr_count($html, '<div class="block') < 20) return 'تعداد بلوک کم';
    return true;
});
t('رندر فقط‌خواندنی فرم پرشده', function () {
    $html = render_ro_form(sample_data());
    return (str_contains($html, 'محمدرضا') && str_contains($html, 'زهرا کریمی')) ?: 'داده در خروجی نیست';
});
t('فرار از HTML در مقادیر', function () {
    $b = schema_block('recruit');
    $html = render_block($b, ['recruit' => ['method' => '<script>x</script>']], []);
    return !str_contains($html, '<script>') ?: 'XSS!';
});

/* ------------------------------------------------------------ خروجی */
echo "\n[خروجی Word / Excel]\n";
$out = __DIR__ . '/../storage/logs';

t('ساخت فایل docx', function () use ($out) {
    if (!class_exists('ZipArchive')) return 'افزونه zip فعال نیست';
    $sub = ['id' => 1, 'tracking_code' => 'BM-05-TEST01', 'first_name' => 'محمدرضا', 'last_name' => 'احمدی',
            'national_id' => '0084575948', 'status' => 'new', 'created_at' => date('Y-m-d H:i:s')];
    $bin = submission_docx($sub, sample_data());
    file_put_contents($out . '/test.docx', $bin);
    if (strlen($bin) < 3000) return 'حجم کم: ' . strlen($bin);
    $z = new ZipArchive();
    if ($z->open($out . '/test.docx') !== true) return 'zip باز نشد';
    $xml = $z->getFromName('word/document.xml');
    $z->close();
    if (!$xml) return 'document.xml نیست';
    if (simplexml_load_string($xml) === false) return 'XML نامعتبر';
    if (!str_contains($xml, 'احمدی')) return 'محتوا در سند نیست';
    return true;
});

t('ساخت فایل xlsx', function () use ($out) {
    if (!class_exists('ZipArchive')) return 'افزونه zip فعال نیست';
    $sub = ['id' => 1, 'tracking_code' => 'BM-05-TEST01', 'first_name' => 'محمدرضا', 'last_name' => 'احمدی',
            'national_id' => '0084575948', 'status' => 'new', 'created_at' => date('Y-m-d H:i:s')];
    $bin = submission_xlsx($sub, sample_data());
    file_put_contents($out . '/test.xlsx', $bin);
    $z = new ZipArchive();
    if ($z->open($out . '/test.xlsx') !== true) return 'zip باز نشد';
    foreach (['xl/workbook.xml', 'xl/styles.xml', 'xl/worksheets/sheet1.xml', '[Content_Types].xml'] as $part) {
        $x = $z->getFromName($part);
        if ($x === false) return "بخش $part نیست";
        if (simplexml_load_string($x) === false) return "XML نامعتبر در $part";
    }
    $z->close();
    return true;
});

t('خروجی اکسل فهرست', function () use ($out) {
    if (!class_exists('ZipArchive')) return 'افزونه zip فعال نیست';
    $rows = db()->query('SELECT * FROM submissions ORDER BY created_at DESC LIMIT 50')->fetchAll();
    $bin = submissions_list_xlsx($rows);
    file_put_contents($out . '/test-list.xlsx', $bin);
    $z = new ZipArchive();
    if ($z->open($out . '/test-list.xlsx') !== true) return 'zip باز نشد';
    $x = $z->getFromName('xl/worksheets/sheet1.xml');
    $z->close();
    return simplexml_load_string($x) !== false ?: 'XML نامعتبر';
});

/* ------------------------------------------------- دسترسی به فیلدها */
echo "\n[دسترسی کاربران به فیلدها]\n";
$SUPER = ['id' => 1, 'role' => 'super', 'fa' => ['personal.first_name']];      // نقش super محدودسازی را نادیده می‌گیرد
$FULL  = ['id' => 2, 'role' => 'operator', 'fa' => null];
$LTD   = ['id' => 3, 'role' => 'operator', 'fa' => ['personal.first_name', 'contact.*', 'documents.photo']];
$NONE  = ['id' => 4, 'role' => 'operator', 'fa' => []];
$BROKEN = ['id' => 5, 'role' => 'operator'];                                   // اطلاعات دسترسی بارگذاری نشده

t('مدیر ارشد همیشه مجاز است', fn() => admin_can('personal', 'national_id', $SUPER) ?: 'رد شد');
t('کارشناس بدون محدودیت مجاز است', fn() => admin_can('family', 'job', $FULL) ?: 'رد شد');
t('کارشناس محدود: فیلد انتخاب‌شده مجاز', fn() => admin_can('personal', 'first_name', $LTD) ?: 'رد شد');
t('کارشناس محدود: فیلد انتخاب‌نشده ممنوع', fn() => !admin_can('personal', 'last_name', $LTD) ?: 'مجاز شد');
t('کارشناس محدود: block.* همه‌ی فیلدهای بخش', fn() => (admin_can('contact', 'mobile', $LTD) && admin_can('contact', 'email', $LTD)) ?: 'رد شد');
t('کارشناس محدود: مدرک مجاز/ممنوع', fn() => (admin_can('documents', 'photo', $LTD) && !admin_can('documents', 'clearance', $LTD)) ?: 'نادرست');
t('لیست خالی = هیچ دسترسی', fn() => !admin_can('personal', 'first_name', $NONE) ?: 'مجاز شد');
t('اطلاعات دسترسی ناقص = ممنوع (fail-closed)', fn() => !admin_can('personal', 'first_name', $BROKEN) ?: 'مجاز شد');
t('بدون کاربر = ممنوع', fn() => !admin_can('personal', 'first_name', null) ?: 'مجاز شد');
t('JSON خراب = هیچ دسترسی', fn() => access_decode('{oops') === [] ?: 'نادرست');
t('NULL و رشته‌ی خالی = دسترسی کامل', fn() => (access_decode(null) === null && access_decode('') === null) ?: 'نادرست');

t('فشرده‌سازی و بازکردن کلیدها بدون تغییر', function () {
    $all = array_keys(all_field_keys());
    $c = access_compress($all);
    if (count($c) >= count($all)) return 'فشرده نشد';
    if (count(access_expand($c)) !== count($all)) return 'بازگردانی ناقص';
    $one = access_compress(['personal.first_name', 'personal.first_name', 'no.such', 'x']);
    return $one === ['personal.first_name'] ?: 'کلید نامعتبر/تکراری: ' . json_encode($one);
});
t('کلیدهای ورودی غیررشته نادیده گرفته می‌شود', fn() => access_compress([['a'], 5, null, 'family.job']) === ['family.job'] ?: 'نادرست');
t('فیلتر مراحل فیلدها و ستون‌های جدول را حذف می‌کند', function () use ($LTD) {
    $steps = filter_steps(form_steps(), fn($b, $f) => admin_can($b, $f, $LTD));
    $names = [];
    foreach ($steps as $st) foreach ($st['blocks'] as $b) foreach (block_fields($b) as $f) $names[] = $b['name'] . '.' . $f['name'];
    sort($names);
    $want = array_merge(['personal.first_name', 'documents.photo'], array_map(fn($f) => 'contact.' . $f['name'], schema_block('contact')['fields']));
    sort($want);
    return $names === $want ?: 'نتیجه: ' . implode(',', $names);
});

t('نمایش/خروجی‌ها: فیلد ممنوع دیده نمی‌شود و فیلد مجاز دیده می‌شود', function () {
    if (!class_exists('ZipArchive')) return 'افزونه zip فعال نیست';
    $sub = ['id' => 1, 'tracking_code' => 'BM-05-TEST02', 'first_name' => 'محمدرضا', 'last_name' => 'احمدی',
            'national_id' => '0084575948', 'status' => 'new', 'created_at' => date('Y-m-d H:i:s')];
    $d = sample_data();
    $hide = fn(string $b, string $f) => !($b === 'appearance' && $f === 'special_mark');
    $steps = filter_steps(form_steps(), $hide);

    $html = render_ro_form($d, $steps, $hide);
    if (str_contains($html, 'XQZ777')) return 'نمایش خواندنی نشتی دارد';
    if (!str_contains(render_ro_form($d), 'XQZ777')) return 'نمایش کامل مقدار را ندارد';

    foreach (['docx' => submission_docx($sub, $d, $steps, $hide), 'xlsx' => submission_xlsx($sub, $d, $steps, $hide)] as $ext => $bin) {
        $z = new ZipArchive(); $tmp = tempnam(sys_get_temp_dir(), 'st'); file_put_contents($tmp, $bin);
        $z->open($tmp);
        $xml = '';
        for ($i = 0; $i < $z->numFiles; $i++) $xml .= (string)$z->getFromIndex($i);
        $z->close(); @unlink($tmp);
        if (str_contains($xml, 'XQZ777')) return "خروجی $ext نشتی دارد";
    }
    $full = submission_docx($sub, $d);
    $z = new ZipArchive(); $tmp = tempnam(sys_get_temp_dir(), 'st'); file_put_contents($tmp, $full); $z->open($tmp);
    $ok = str_contains((string)$z->getFromName('word/document.xml'), 'XQZ777'); $z->close(); @unlink($tmp);
    return $ok ?: 'خروجی کامل مقدار را ندارد';
});
t('اکسل فهرست: ستون ممنوع حذف می‌شود', function () {
    $rows = [['tracking_code' => 'BM-05-X', 'first_name' => 'اسم‌آزمون', 'last_name' => 'فامیل', 'father_name' => 'پدر',
              'national_id' => '0084575948', 'birth_date' => '1370/01/01', 'mobile' => '09120000000',
              'org_name' => 'سازمان', 'position' => 'پست', 'status' => 'new', 'created_at' => date('Y-m-d H:i:s'), 'ip' => '1.1.1.1']];
    $noNid = fn(string $b, string $f) => !($b === 'personal' && $f === 'national_id');
    $read = function (string $bin) {
        $z = new ZipArchive(); $tmp = tempnam(sys_get_temp_dir(), 'st'); file_put_contents($tmp, $bin); $z->open($tmp);
        $x = (string)$z->getFromName('xl/worksheets/sheet1.xml'); $z->close(); @unlink($tmp); return $x;
    };
    $a = $read(submissions_list_xlsx($rows, $noNid));
    $b = $read(submissions_list_xlsx($rows));
    if (simplexml_load_string($a) === false) return 'XML نامعتبر';
    return (!str_contains($a, '۰۰۸۴۵۷۵۹۴۸') && str_contains($b, '۰۰۸۴۵۷۵۹۴۸') && str_contains($a, 'اسم‌آزمون')) ?: 'ستون حذف نشد';
});
t('نام نمایشی بدون دسترسی به نام = کد رهگیری', function () use ($LTD) {
    $_SESSION['admin'] = $LTD + ['username' => 'x'];
    $r1 = sub_display_name(['first_name' => 'الف', 'last_name' => 'ب', 'tracking_code' => 'BM-1']);
    $_SESSION['admin'] = ['id' => 9, 'role' => 'operator', 'fa' => ['contact.*']];
    $r2 = sub_display_name(['first_name' => 'الف', 'last_name' => 'ب', 'tracking_code' => 'BM-1']);
    unset($_SESSION['admin']);
    return ($r1 === 'الف' && $r2 === 'فرم BM-1') ?: "$r1 | $r2";
});
t('لاگ برای کاربر محدود، نام افراد را نشان نمی‌دهد', function () use ($LTD) {
    $_SESSION['admin'] = $LTD + ['username' => 'x'];
    $a = log_details_visible(['action' => 'submit', 'details' => 'ثبت فرم توسط علی رضایی']);
    $_SESSION['admin'] = ['id' => 1, 'role' => 'super', 'fa' => null, 'username' => 's'];
    $b = log_details_visible(['action' => 'submit', 'details' => 'ثبت فرم توسط علی رضایی']);
    unset($_SESSION['admin']);
    return ($a === 'ثبت فرم' && str_contains($b, 'رضایی')) ?: "$a | $b";
});

/* --------------------------------------------------------- گزارش نواقص */
echo "\n[گزارش نواقص]\n";
$flat = function (array $rep): array {
    $out = [];
    foreach ($rep['groups'] as $g) foreach ($g['items'] as $it) $out[] = $it['kind'] . '|' . $it['label'] . '|' . $it['where'];
    return $out;
};
t('فیلد اختیاری خالی گزارش می‌شود', function () use ($flat) {
    $r = submission_report(sample_data(), form_steps(), []);
    return in_array('missing|گروه خونی|', $flat($r), true) ?: 'گروه خونی نیامده';
});
t('فیلد شرطی غیرفعال گزارش نمی‌شود', function () use ($flat) {
    $r = $flat(submission_report(sample_data(), form_steps(), []));
    foreach ($r as $x) if (str_contains($x, 'نام کشور (تابعیت مضاعف)') || str_contains($x, 'تاریخ صدور المثنی')) return 'شرطی گزارش شد: ' . $x;
    return true;
});
t('«ندارم» پر حساب می‌شود', function () use ($flat) {
    $d = sample_data(); $d['personal']['nickname'] = 'ندارم';
    foreach ($flat(submission_report($d, form_steps(), [])) as $x) if (str_contains($x, 'شهرت یا القاب')) return 'گزارش شد';
    return true;
});
t('فیلد الزامی خالی از نوع required است', function () use ($flat) {
    $d = sample_data(); $d['personal']['first_name'] = '';
    return in_array('required|نام|', $flat(submission_report($d, form_steps(), [])), true) ?: 'required نیست';
});
t('بخش اظهاریِ خالی نقص شمرده نمی‌شود', function () {
    $r = submission_report(sample_data(), form_steps(), []);
    $kinds = [];
    foreach ($r['groups'] as $g) foreach ($g['items'] as $it) if (str_contains($it['block'], 'اسلحه')) $kinds[] = $it['kind'];
    return ($kinds === ['declaration'] && $r['counts']['declaration'] > 0) ?: 'kinds: ' . json_encode($kinds);
});
t('ردیف کاملاً خالیِ جدول نقص نیست ولی خانه‌ی خالی ردیف پر، نقص است', function () use ($flat) {
    $d = sample_data();
    $d['jobs'] = [['title' => 'فقط عنوان', 'role' => '', 'from' => '', 'to' => '', 'leave_reason' => '', 'workplace' => ''], []];
    $r = $flat(submission_report($d, form_steps(), []));
    $bad = in_array('missing|سمت و نوع فعالیت|شغل ۱', $r, true);
    foreach ($r as $x) if (str_contains($x, 'شغل ۲')) return 'ردیف خالی گزارش شد';
    return $bad ?: 'خانه‌ی خالی گزارش نشد';
});
t('کمتر از حداقل ردیف (دوستان: ۴) گزارش می‌شود', function () {
    $r = submission_report(sample_data(), form_steps(), []);
    foreach ($r['groups'] as $g) foreach ($g['items'] as $it)
        if ($it['kind'] === 'block' && str_contains($it['block'], 'دوستان') && str_contains($it['where'], 'حداقل')) return true;
    return 'گزارش نشد';
});
t('مدارک: بدون آپلود، ناقص؛ با آپلود، کامل', function () use ($flat) {
    $none = $flat(submission_report(sample_data(), form_steps(), []));
    if (!in_array('doc|عکس پرسنلی|مدرکی بارگذاری نشده', $none, true)) return 'عکس ناقص نیامد';
    $up = ['photo' => [['id' => 1]]];
    $with = $flat(submission_report(sample_data(), form_steps(), $up));
    return !in_array('doc|عکس پرسنلی|مدرکی بارگذاری نشده', $with, true) ?: 'با آپلود هم ناقص گزارش شد';
});
t('مدارک همسر فقط برای متأهل، پایان خدمت فقط برای «خدمت کرده»', function () use ($flat) {
    $d = sample_data();
    $has = fn(array $r, string $needle) => count(array_filter($r, fn($x) => str_contains($x, $needle))) > 0;
    $married = $flat(submission_report($d, form_steps(), []));
    if (!$has($married, 'کارت ملی همسر') || !$has($married, 'کارت پایان خدمت')) return 'متأهل/خدمت‌کرده گزارش نشد';
    $d['personal']['marital'] = 'مجرد'; $d['edu_passport']['military_status'] = 'معاف';
    $single = $flat(submission_report($d, form_steps(), []));
    if ($has($single, 'کارت ملی همسر') || $has($single, 'شناسنامه همسر') || $has($single, 'کارت پایان خدمت')) return 'نامرتبط گزارش شد';
    return true;
});
t('شناسنامه فرزندان: به‌اندازه‌ی تعداد فرزندان', function () use ($flat) {
    $d = sample_data();
    $none = $flat(submission_report($d, form_steps(), []));
    if (count(array_filter($none, fn($x) => str_contains($x, 'شناسنامه فرزندان'))) > 0) return 'بدون فرزند گزارش شد';
    $d['family'][] = ['full_name' => 'کودک ۱', 'father_name' => 'الف', 'relation' => 'فرزند', 'age' => '3', 'job' => '', 'address' => 'ت'];
    $d['family'][] = ['full_name' => 'کودک ۲', 'father_name' => 'الف', 'relation' => 'فرزند', 'age' => '1', 'job' => '', 'address' => 'ت'];
    $one = $flat(submission_report($d, form_steps(), ['birth_children' => [['id' => 1]]]));
    $two = $flat(submission_report($d, form_steps(), ['birth_children' => [['id' => 1], ['id' => 2]]]));
    $short = count(array_filter($one, fn($x) => str_contains($x, 'شناسنامه فرزندان') && str_contains($x, 'کمتر از تعداد'))) === 1;
    $okay  = count(array_filter($two, fn($x) => str_contains($x, 'شناسنامه فرزندان'))) === 0;
    return ($short && $okay) ?: 'منطق تعداد فرزندان نادرست';
});
t('گزارش فقط فیلدهای مجاز را بررسی می‌کند', function () use ($flat, $LTD) {
    $steps = filter_steps(form_steps(), fn($b, $f) => admin_can($b, $f, $LTD));
    $r = $flat(submission_report(sample_data(), $steps, []));
    foreach ($r as $x) if (str_contains($x, 'گروه خونی')) return 'فیلد ممنوع گزارش شد';
    return in_array('missing|تلفن همراه دوم|', $r, true) ?: 'فیلد مجاز گزارش نشد';
});
t('درصد تکمیل بین ۰ و ۱۰۰', function () {
    $p = submission_report(sample_data(), form_steps(), [])['percent'];
    $q = submission_report([], form_steps(), [])['percent'];
    return ($p > 0 && $p < 100 && $q >= 0 && $q < $p) ?: "$p / $q";
});
t('خروجی اکسل گزارش نواقص', function () {
    if (!class_exists('ZipArchive')) return 'افزونه zip فعال نیست';
    $sub = ['id' => 1, 'tracking_code' => 'BM-05-TEST03', 'created_at' => date('Y-m-d H:i:s')];
    $bin = missing_report_xlsx($sub, submission_report(sample_data(), form_steps(), []), 'محمدرضا احمدی');
    $z = new ZipArchive(); $tmp = tempnam(sys_get_temp_dir(), 'st'); file_put_contents($tmp, $bin); $z->open($tmp);
    $x = (string)$z->getFromName('xl/worksheets/sheet1.xml'); $z->close(); @unlink($tmp);
    return (simplexml_load_string($x) !== false && str_contains($x, 'گروه خونی')) ?: 'نامعتبر';
});

/* --------------------------------------------------------- مدارک (فایل) */
echo "\n[مدارک بارگذاری‌شده]\n";
t('ساختار پایگاه داده: جدول uploads و ستون field_access', function () {
    return (schema_has_column(db(), 'uploads', 'stored_name') && schema_has_column(db(), 'admins', 'field_access')) ?: 'ناقص';
});
t('بازسازی تصویر: کوچک‌سازی و JPEG', function () {
    if (!extension_loaded('gd')) return 'GD فعال نیست';
    $im = imagecreatetruecolor(3600, 2400);
    imagefill($im, 0, 0, imagecolorallocate($im, 30, 120, 200));
    $tmp = tempnam(sys_get_temp_dir(), 'up'); imagepng($im, $tmp); imagedestroy($im);
    [$bin, $err] = upload_process_image($tmp);
    @unlink($tmp);
    if ($err !== null) return $err;
    $info = getimagesizefromstring($bin);
    return ($info && $info[2] === IMAGETYPE_JPEG && max($info[0], $info[1]) === UPLOAD_IMG_SIDE) ?: 'خروجی نامعتبر: ' . json_encode($info);
});
t('فایل غیرتصویر رد می‌شود', function () {
    $tmp = tempnam(sys_get_temp_dir(), 'up'); file_put_contents($tmp, '<?php echo 1; ?> not an image');
    [$bin, $err] = upload_process_image($tmp); @unlink($tmp);
    return ($bin === null && $err !== null) ?: 'پذیرفته شد';
});
t('تصویر بسیار کوچک رد می‌شود', function () {
    $im = imagecreatetruecolor(10, 10); $tmp = tempnam(sys_get_temp_dir(), 'up'); imagepng($im, $tmp); imagedestroy($im);
    [$bin, $err] = upload_process_image($tmp); @unlink($tmp);
    return ($bin === null && $err !== null) ?: 'پذیرفته شد';
});
t('اتصال مدارک به فرم: نامرتبط دور ریخته می‌شود و سقف رعایت می‌شود', function () {
    if (!is_dir(uploads_dir())) @mkdir(uploads_dir(), 0770, true);
    $tok = bin2hex(random_bytes(16));
    $_SESSION['up_token'] = $tok;
    $mk = function (string $doc) use ($tok) {
        $name = bin2hex(random_bytes(8)) . '.jpg';
        file_put_contents(uploads_dir() . '/' . $name, 'x');
        db()->prepare('INSERT INTO uploads (submission_id, token, doc_key, orig_name, stored_name, mime, size, ip, created_at) VALUES (NULL,?,?,?,?,?,?,?,?)')
            ->execute([$tok, $doc, 'a.jpg', $name, 'image/jpeg', 1, '127.0.0.1', date('Y-m-d H:i:s')]);
        return $name;
    };
    $photo1 = $mk('photo'); $photo2 = $mk('photo');          // سقف عکس ۱ است
    $spouse = $mk('spouse_nid_front');                        // برای مجرد نامرتبط است
    $bogus  = $mk('no_such_doc');
    $edu    = $mk('education');

    $sid = 987654;
    $n = finalize_uploads($sid, ['personal' => ['marital' => 'مجرد']]);
    $rows = submission_uploads($sid);
    $keys = array_keys($rows); sort($keys);
    $exist = fn(string $f) => is_file(uploads_dir() . '/' . $f);
    $res = ($n === 2 && $keys === ['education', 'photo'] && count($rows['photo']) === 1
        && $exist($photo1) && !$exist($photo2) && !$exist($spouse) && !$exist($bogus) && $exist($edu));
    $left = (int)db()->query("SELECT COUNT(*) FROM uploads WHERE token = '$tok'")->fetchColumn();
    delete_submission_uploads($sid);
    if (!$res) return 'n=' . $n . ' keys=' . implode(',', $keys);
    if ($left !== 0) return 'ردیف در انتظار باقی ماند';
    return (!$exist($photo1) && !$exist($edu) && !isset($_SESSION['up_token'])) ?: 'پاک‌سازی ناقص';
});
t('فایل‌های در انتظار قدیمی پاک می‌شوند', function () {
    if (!is_dir(uploads_dir())) @mkdir(uploads_dir(), 0770, true);
    $name = bin2hex(random_bytes(8)) . '.jpg';
    file_put_contents(uploads_dir() . '/' . $name, 'x');
    db()->prepare('INSERT INTO uploads (submission_id, token, doc_key, orig_name, stored_name, mime, size, ip, created_at) VALUES (NULL,?,?,?,?,?,?,?,?)')
        ->execute([bin2hex(random_bytes(16)), 'photo', 'a.jpg', $name, 'image/jpeg', 1, '127.0.0.1', date('Y-m-d H:i:s', time() - UPLOAD_PENDING_TTL - 60)]);
    uploads_cleanup_stale();
    $left = (int)db()->query("SELECT COUNT(*) FROM uploads WHERE stored_name = '$name'")->fetchColumn();
    return ($left === 0 && !is_file(uploads_dir() . '/' . $name)) ?: 'پاک نشد';
});
t('رندر فرم شامل جایگاه‌های مدرک و شرط همسر است', function () {
    $html = '';
    foreach (form_steps() as $st) foreach ($st['blocks'] as $b) if ($b['kind'] === 'files') $html .= render_block($b, [], []);
    return (substr_count($html, 'class="up-slot') === count(doc_defs())
        && str_contains($html, 'data-when-field="f[personal][marital]"')
        && str_contains($html, 'data-pdf="0"')) ?: 'جایگاه‌ها ناقص';
});


/* --------------------------------------------------- امنیت بارگذاری فایل */
echo "\n[امنیت بارگذاری فایل]\n";
$pdfTmp = function (string $body): string { $f = tempnam(sys_get_temp_dir(), 'pd'); file_put_contents($f, $body); return $f; };

t('PDF ساده و سالم پذیرفته می‌شود', function () use ($pdfTmp) {
    $f = $pdfTmp("%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count 0/Kids[]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF");
    $r = upload_pdf_problem($f); @unlink($f);
    return $r === null ?: $r;
});
t('PDF با JavaScript رد می‌شود', function () use ($pdfTmp) {
    $f = $pdfTmp("%PDF-1.4\n1 0 obj<</Type/Catalog/OpenAction<</S/JavaScript/JS(app.alert(1))>>>>endobj\n%%EOF");
    $r = upload_pdf_problem($f); @unlink($f);
    return $r !== null ?: 'پذیرفته شد';
});
t('PDF با نام مبهم‌شده (/J#61vaScript) رد می‌شود', function () use ($pdfTmp) {
    $f = $pdfTmp("%PDF-1.4\n1 0 obj<</S/J#61vaScr#69pt/J#53(x)>>endobj\n%%EOF");
    $r = upload_pdf_problem($f); @unlink($f);
    return $r !== null ?: 'پذیرفته شد';
});
t('PDF با Launch / EmbeddedFile / RichMedia رد می‌شود', function () use ($pdfTmp) {
    foreach (['/S/Launch/F(cmd.exe)', '/Type/EmbeddedFile', '/Subtype/RichMedia'] as $frag) {
        $f = $pdfTmp("%PDF-1.4\n1 0 obj<<$frag>>endobj\n%%EOF");
        $r = upload_pdf_problem($f); @unlink($f);
        if ($r === null) return "پذیرفته شد: $frag";
    }
    return true;
});
t('داده‌ی باینری داخل stream باعث تشخیص اشتباه نمی‌شود', function () use ($pdfTmp) {
    $noise = '/JS /JavaScript /Launch ' . random_bytes(2000) . ' /XFA /EmbeddedFile ';
    $f = $pdfTmp("%PDF-1.4\n1 0 obj<</Length 9999>>\nstream\n$noise\nendstream\nendobj\n%%EOF");
    $r = upload_pdf_problem($f); @unlink($f);
    return $r === null ?: 'رد شد: ' . $r;
});
t('JavaScript بعد از یک stream هم دیده می‌شود', function () use ($pdfTmp) {
    $f = $pdfTmp("%PDF-1.4\n1 0 obj<</Length 3>>\nstream\nabc\nendstream\nendobj\n2 0 obj<</S/JavaScript/JS(x)>>endobj\n%%EOF");
    $r = upload_pdf_problem($f); @unlink($f);
    return $r !== null ?: 'پذیرفته شد';
});

t('بررسی حافظه: تصویر معمولی مجاز، تصویر غول‌آسا ممنوع', function () {
    if (upload_memory_limit() < 0) return true;
    return (upload_memory_ok(2400, 1800) && !upload_memory_ok(20000, 20000)) ?: 'نادرست';
});
t('بمب رمزگشایی (PNG کوچک با ابعاد اعلامی عظیم) بدون خطای مرگبار رد می‌شود', function () {
    if (!extension_loaded('gd')) return 'GD فعال نیست';
    // فقط سرآیند IHDR با ابعاد ۴۱۰۰×۴۱۰۰ (۱۶٫۸ میلیون پیکسل)؛ فایل چند ده بایت است
    $ihdr = pack('NNCCCCC', 4100, 4100, 8, 2, 0, 0, 0);
    $png  = "\x89PNG\r\n\x1a\n" . pack('N', 13) . 'IHDR' . $ihdr . pack('N', crc32('IHDR' . $ihdr))
          . pack('N', 0) . 'IEND' . pack('N', crc32('IEND'));
    $tmp = tempnam(sys_get_temp_dir(), 'up'); file_put_contents($tmp, $png);
    [$bin, $err] = upload_process_image($tmp); @unlink($tmp);
    return ($bin === null && $err !== null && str_contains($err, 'ابعاد')) ?: 'پذیرفته شد یا پیام نادرست: ' . $err;
});

t('پویش ضدویروس: آلوده رد، پاک و خطا پذیرفته می‌شود', function () use ($pdfTmp) {
    $f = $pdfTmp("%PDF-1.4\n%%EOF");
    $old = $GLOBALS['CONFIG']['antivirus_cmd'] ?? null;
    $res = [];
    foreach ([1 => 'infected', 0 => 'clean', 2 => 'error'] as $code => $label) {
        $GLOBALS['CONFIG']['antivirus_cmd'] = [PHP_BINARY, '-r', 'exit((int)$argv[1]);', (string)$code];
        $res[$label] = upload_av_problem($f);
    }
    @unlink($f);
    if ($old === null) unset($GLOBALS['CONFIG']['antivirus_cmd']); else $GLOBALS['CONFIG']['antivirus_cmd'] = $old;
    return ($res['infected'] !== null && $res['clean'] === null && $res['error'] === null) ?: json_encode($res, JSON_UNESCAPED_UNICODE);
});
t('پویشگر ضدویروس ناموجود، مانع بارگذاری نمی‌شود', function () use ($pdfTmp) {
    $f = $pdfTmp("%PDF-1.4\n%%EOF");
    $old = $GLOBALS['CONFIG']['antivirus_cmd'] ?? null;
    $GLOBALS['CONFIG']['antivirus_cmd'] = ['/no/such/scanner-binary'];
    $r = upload_av_problem($f);
    @unlink($f);
    if ($old === null) unset($GLOBALS['CONFIG']['antivirus_cmd']); else $GLOBALS['CONFIG']['antivirus_cmd'] = $old;
    return $r === null ?: 'رد شد';
});
t('نام فایل ارسالی پاک‌سازی می‌شود (مسیر، کنترلی، UTF-8 خراب)', function () {
    $ok = upload_clean_name('..\\..\\etc/passwd') === 'passwd'
       && upload_clean_name("a\x00b<c>.jpg") === 'abc.jpg'
       && upload_clean_name("\xff\xfe") === 'file'
       && mb_strlen(upload_clean_name(str_repeat('ا', 500))) <= 120;
    return $ok ?: 'نادرست: ' . upload_clean_name('..\\..\\etc/passwd') . ' | ' . upload_clean_name("a\x00b<c>.jpg");
});
t('هدر Content-Disposition نام فارسی و تزریق را امن می‌کند', function () {
    $h = content_disposition('attachment', "عکس\r\nX-Evil: 1\".jpg");
    return (!str_contains($h, "\r") && !str_contains($h, "\n") && substr_count($h, '"') === 2 && str_contains($h, "UTF-8''")) ?: $h;
});

/* فرم آزمایشیِ ساخته‌شده توسط همین آزمون نباید در پایگاه داده‌ی واقعی بماند */
if ($subId) db()->prepare('DELETE FROM submissions WHERE id = ?')->execute([$subId]);

/* ------------------------------------------------------------ نتیجه */
echo "\n" . str_repeat('─', 46) . "\n";
echo $fail === 0
    ? "  همه‌ی آزمون‌ها موفق بودند ($pass مورد)\n\n"
    : "  موفق: $pass    ناموفق: $fail\n\n";
exit($fail === 0 ? 0 : 1);

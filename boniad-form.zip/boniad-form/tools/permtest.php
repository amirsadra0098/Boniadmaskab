<?php
/**
 * آزمون دسترسی فیلدها، مدارک و گزارش نواقص — روی سامانه‌ی در حال اجرا (HTTP واقعی).
 *
 * اجرا:
 *   php tools/permtest.php http://127.0.0.1:8099
 *
 * این آزمون چند کاربر و یک فرم آزمایشی می‌سازد و در پایان همه را پاک می‌کند.
 * فقط روی نصب آزمایشی/تازه اجرا شود (به پایگاه داده‌ی همان سرور دسترسی مستقیم لازم دارد).
 */

if (PHP_SAPI !== 'cli') exit('CLI only');

require __DIR__ . '/../app/bootstrap.php';
ensure_schema();

$BASE = rtrim($argv[1] ?? 'http://127.0.0.1:8099', '/');
$pass = 0; $fail = 0;
function ok_($m)  { global $pass; $pass++; echo "  ✔ $m\n"; }
function bad_($m) { global $fail; $fail++; echo "  ✘ $m\n"; }
function check(bool $cond, string $okMsg, string $badMsg = '') { $cond ? ok_($okMsg) : bad_($badMsg ?: $okMsg); }
function head($t) { echo "\n[$t]\n"; }

/* ------------------------------------------------------------ HTTP */

function http(string $url, array $opt = []): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => true, CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_COOKIEJAR => $opt['jar'], CURLOPT_COOKIEFILE => $opt['jar'], CURLOPT_TIMEOUT => 60,
        CURLOPT_ENCODING => '',
    ]);
    if (isset($opt['post'])) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $opt['post']); }
    $raw = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);
    if ($raw === false) return ['code' => 0, 'head' => '', 'body' => '', 'loc' => '', 'type' => ''];
    $hs = substr($raw, 0, $info['header_size']);
    preg_match('/^location:\s*(.+)$/mi', $hs, $m);
    return ['code' => $info['http_code'], 'head' => $hs, 'body' => substr($raw, $info['header_size']),
            'loc' => trim($m[1] ?? ''), 'type' => $info['content_type'] ?? ''];
}

function csrf_of(string $html): string { return preg_match('/name="_csrf" value="([a-f0-9]+)"/', $html, $m) ? $m[1] : ''; }

function captcha_from_session(string $jar): ?string
{
    $j = @file_get_contents($jar) ?: '';
    if (!preg_match('/BMFORM\s+(\S+)\s*$/m', $j, $m)) return null;
    $path = ini_get('session.save_path') ?: sys_get_temp_dir();
    foreach (explode(';', $path) as $seg) {
        $seg = trim($seg);
        if ($seg === '' || is_numeric($seg)) continue;
        $f = rtrim($seg, '/\\') . '/sess_' . trim($m[1]);
        if (is_file($f) && preg_match('/code";s:5:"([A-Z0-9]{5})"/', (string)file_get_contents($f), $mm)) return $mm[1];
    }
    return null;
}

function login(string $user, string $pw): ?string
{
    global $BASE;
    $jar = tempnam(sys_get_temp_dir(), 'pt_jar');
    $csrf = csrf_of(http("$BASE/admin/login", ['jar' => $jar])['body']);
    http("$BASE/admin/captcha?t=" . random_int(1, 1e9), ['jar' => $jar]);
    $code = captcha_from_session($jar);
    $r = http("$BASE/admin/login", ['jar' => $jar, 'post' => http_build_query(
        ['_csrf' => $csrf, 'username' => $user, 'password' => $pw, 'captcha' => (string)$code])]);
    db()->exec('DELETE FROM login_attempts');
    return ($r['code'] === 302 && str_contains($r['loc'], 'admin')) ? $jar : null;
}

/** متن همه‌ی بخش‌های یک فایل zip/docx/xlsx */
function zip_text(string $bin): string
{
    $tmp = tempnam(sys_get_temp_dir(), 'pt_z'); file_put_contents($tmp, $bin);
    $z = new ZipArchive(); $txt = '';
    if ($z->open($tmp) === true) { for ($i = 0; $i < $z->numFiles; $i++) $txt .= (string)$z->getFromIndex($i); $z->close(); }
    @unlink($tmp);
    return $txt;
}

function zip_names(string $bin): array
{
    $tmp = tempnam(sys_get_temp_dir(), 'pt_z'); file_put_contents($tmp, $bin);
    $z = new ZipArchive(); $n = [];
    if ($z->open($tmp) === true) { for ($i = 0; $i < $z->numFiles; $i++) $n[] = $z->getNameIndex($i); $z->close(); }
    @unlink($tmp);
    return $n;
}

function jpeg_bytes(int $w = 400, int $h = 300): string
{
    $im = imagecreatetruecolor($w, $h);
    imagefill($im, 0, 0, imagecolorallocate($im, random_int(0, 255), random_int(0, 255), random_int(0, 255)));
    ob_start(); imagejpeg($im, null, 85); $b = ob_get_clean(); imagedestroy($im);
    return $b;
}

/** کد ملی معتبر از ۹ رقم */
function make_nid(string $nine): string
{
    $s = 0;
    for ($i = 0; $i < 9; $i++) $s += (int)$nine[$i] * (10 - $i);
    $r = $s % 11;
    return $nine . ($r < 2 ? $r : 11 - $r);
}

echo "\n══════════════════════════════════════════════════════════\n";
echo "  آزمون دسترسی فیلدها و مدارک — $BASE\n";
echo "══════════════════════════════════════════════════════════\n";

$created = ['admins' => [], 'subs' => []];
$jars = [];

register_shutdown_function(function () use (&$created, &$jars) {
    foreach ($created['subs'] as $id) delete_submission_uploads($id);
    foreach ($created['subs'] as $id) db()->prepare('DELETE FROM submissions WHERE id = ?')->execute([$id]);
    foreach ($created['admins'] as $id) db()->prepare('DELETE FROM admins WHERE id = ?')->execute([$id]);
    db()->exec("DELETE FROM uploads WHERE ip = '203.0.113.9' AND submission_id IS NULL");
    foreach ($jars as $j) @unlink($j);
});

/* =========================================================== ۱) آماده‌سازی */
head('آماده‌سازی');
$M = ['first' => 'آزمونیک', 'last' => 'فامیلیک', 'nid' => '0499370899', 'mob' => '09123334444',
      'org' => 'سازمان‌ماکر', 'mark' => 'MARKER-SM-XQ', 'spouse' => 'همسرماکر'];

$data = [
    'personal' => ['first_name' => $M['first'], 'last_name' => $M['last'], 'father_name' => 'پدرماکر', 'national_id' => $M['nid'],
                   'birth_date' => '1370/01/01', 'marital' => 'متأهل', 'id_type' => 'اصلی', 'religion' => 'اسلام',
                   'birth_place' => 'تهران', 'issue_place' => 'تهران', 'dual_nationality' => 'ندارم'],
    'appearance' => ['special_mark' => $M['mark']],
    'workplace' => ['org_name' => $M['org'], 'position' => 'پست‌ماکر'],
    'contact' => ['mobile' => $M['mob']],
    'spouses' => ['current' => ['full_name' => $M['spouse']]],
    'pledge' => ['filler_name' => 'تکمیل‌کننده‌ماکر', 'filler_date' => '1403/01/01', 'accept' => 'می‌پذیرم'],
];
db()->prepare('INSERT INTO submissions (tracking_code, first_name, last_name, father_name, national_id, mobile, birth_date, org_name, position, status, data, ip, user_agent, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    ->execute(['BM-99-PERMT1', $M['first'], $M['last'], 'پدرماکر', $M['nid'], $M['mob'], '1370/01/01', $M['org'], 'پست‌ماکر', 'new',
               json_encode($data, JSON_UNESCAPED_UNICODE), '127.0.0.1', 'permtest', date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
$sid = (int)db()->lastInsertId();
$created['subs'][] = $sid;

if (!is_dir(uploads_dir())) @mkdir(uploads_dir(), 0770, true);
$up = [];
foreach (['photo' => ['jpg', jpeg_bytes()], 'nid_front' => ['jpg', jpeg_bytes()], 'clearance' => ['pdf', "%PDF-1.4\n%%EOF"]] as $key => [$ext, $bin]) {
    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    file_put_contents(uploads_dir() . '/' . $name, $bin);
    db()->prepare('INSERT INTO uploads (submission_id, token, doc_key, orig_name, stored_name, mime, size, ip, created_at) VALUES (?,NULL,?,?,?,?,?,?,?)')
        ->execute([$sid, $key, "$key.$ext", $name, $ext === 'pdf' ? 'application/pdf' : 'image/jpeg', strlen($bin), '127.0.0.1', date('Y-m-d H:i:s')]);
    $up[$key] = (int)db()->lastInsertId();
}

$PW = 'Perm12345';
$mkAdmin = function (string $u, string $role, ?array $fa) use ($PW, &$created): int {
    db()->prepare('INSERT INTO admins (username, password_hash, display_name, role, is_active, created_at, field_access) VALUES (?,?,?,?,1,?,?)')
        ->execute([$u, password_hash($PW, PASSWORD_DEFAULT), $u, $role, date('Y-m-d H:i:s'), $fa === null ? null : json_encode($fa)]);
    $id = (int)db()->lastInsertId(); $created['admins'][] = $id; return $id;
};
$idSuper = $mkAdmin('pt_super', 'super', ['personal.first_name']);   // محدودیت برای مدیر ارشد بی‌اثر است
$idFull  = $mkAdmin('pt_full', 'operator', null);
$idLtd   = $mkAdmin('pt_ltd', 'operator', ['personal.first_name', 'contact.mobile', 'documents.photo']);
$idNone  = $mkAdmin('pt_none', 'operator', []);
ok_("فرم آزمایشی ($sid) و ۴ کاربر ساخته شد");

foreach (['pt_super', 'pt_full', 'pt_ltd', 'pt_none'] as $u) {
    $jars[$u] = login($u, $PW);
    check($jars[$u] !== null, "ورود $u موفق بود", "ورود $u انجام نشد");
}
if (in_array(null, $jars, true)) { echo "\n  ! ورود ناموفق؛ ادامه ممکن نیست.\n"; exit(1); }

$get = fn(string $who, string $path) => http("$BASE/$path", ['jar' => $jars[$who]]);
$hidden = [$M['last'], $M['nid'], fa_num($M['nid']), $M['mark'], $M['spouse'], $M['org'], 'پدرماکر', 'تکمیل‌کننده‌ماکر'];

/* ====================================================== ۲) کاربر محدود */
head('کاربر محدود: فقط نام، تلفن همراه و عکس پرسنلی');
$leak = function (string $body, array $needles): array { return array_values(array_filter($needles, fn($n) => str_contains($body, $n))); };

$r = $get('pt_ltd', "admin/view?id=$sid");
check($r['code'] === 200 && str_contains($r['body'], $M['first']) && str_contains($r['body'], fa_num($M['mob'])), 'مشاهده‌ی فرم: فیلدهای مجاز دیده می‌شود');
check(!$leak($r['body'], $hidden), 'مشاهده‌ی فرم: هیچ فیلد ممنوعی نشت نمی‌کند', 'نشت در مشاهده: ' . implode(' | ', $leak($r['body'], $hidden)));
check(str_contains($r['body'], 'admin/file?id=' . $up['photo']) && !str_contains($r['body'], 'admin/file?id=' . $up['nid_front']), 'مشاهده‌ی فرم: فقط مدرک مجاز نمایش داده می‌شود');

$r = $get('pt_ltd', "admin/print?id=$sid");
check($r['code'] === 200 && !$leak($r['body'], $hidden), 'صفحه‌ی چاپ: بدون نشت' , 'نشت در چاپ: ' . implode(' | ', $leak($r['body'], $hidden)));

foreach (['docx', 'xlsx'] as $t) {
    $r = $get('pt_ltd', "admin/export?type=$t&id=$sid");
    $txt = zip_text($r['body']);
    check($r['code'] === 200 && str_contains($txt, $M['first']) && !$leak($txt, $hidden), "خروجی $t: بدون نشت", "نشت در $t: " . implode(' | ', $leak($txt, $hidden)));
    check(!str_contains($r['head'], rawurlencode($M['last'])), "نام فایل $t نام خانوادگی ممنوع را ندارد");
}

$r = $get('pt_ltd', 'admin/export-list');
$txt = zip_text($r['body']);
check($r['code'] === 200 && str_contains($txt, $M['first']) && !$leak($txt, [$M['last'], fa_num($M['nid']), $M['org']]), 'اکسل فهرست: ستون‌های ممنوع حذف شده است');

$r = $get('pt_ltd', 'admin/submissions');
check(str_contains($r['body'], 'BM-99-PERMT1') && str_contains($r['body'], $M['first']) && !$leak($r['body'], $hidden), 'فهرست فرم‌ها: بدون نشت');
foreach ([['q' => $M['last'], 'نام خانوادگی'], ['q' => $M['nid'], 'کد ملی'], ['q' => $M['org'], 'سازمان']] as $s) {
    $r = $get('pt_ltd', 'admin/submissions?q=' . rawurlencode($s['q']));
    check(!str_contains($r['body'], 'BM-99-PERMT1'), "جستجو با {$s[0]} ممنوع نتیجه‌ای نمی‌دهد (حدس زدن مقدار ممکن نیست)");
}
$r = $get('pt_ltd', 'admin/submissions?q=' . rawurlencode($M['first']));
check(str_contains($r['body'], 'BM-99-PERMT1'), 'جستجو با نام مجاز نتیجه می‌دهد');
$r = $get('pt_ltd', 'admin/submissions?q=BM-99-PERMT1');
check(str_contains($r['body'], 'BM-99-PERMT1'), 'جستجو با کد رهگیری همیشه ممکن است');

$r = $get('pt_ltd', "admin/missing?id=$sid");
check($r['code'] === 200 && !str_contains($r['body'], 'گروه خونی') && !str_contains($r['body'], 'شماره شناسنامه') && str_contains($r['body'], 'تلفن همراه دوم') === false,
      'گزارش نواقص: فقط فیلدهای مجاز بررسی می‌شود');
$x = zip_text($get('pt_ltd', "admin/missing-export?id=$sid")['body']);
check(!str_contains($x, 'گروه خونی') && str_contains($x, 'BM-99-PERMT1'), 'خروجی اکسل گزارش نواقص: فقط فیلدهای مجاز');

$r = $get('pt_ltd', "admin/file?id={$up['photo']}");
check($r['code'] === 200 && str_starts_with($r['type'], 'image/jpeg'), 'مدرک مجاز (عکس) قابل مشاهده است');
$r = $get('pt_ltd', "admin/file?id={$up['nid_front']}");
check($r['code'] === 403, 'مدرک ممنوع (کارت ملی) → ۴۰۳', 'کد: ' . $r['code']);
$r = $get('pt_ltd', "admin/file?id={$up['clearance']}&dl=1");
check($r['code'] === 403, 'مدرک ممنوع (PDF گواهی) → ۴۰۳');
$r = $get('pt_ltd', "admin/files-zip?id=$sid");
check($r['code'] === 200 && count(zip_names($r['body'])) === 1, 'ZIP مدارک فقط شامل مدرک مجاز است', 'فایل‌ها: ' . json_encode(zip_names($r['body']), JSON_UNESCAPED_UNICODE));
$r = $get('pt_super', "admin/files-zip?id=$sid");
check($r['code'] === 200 && count(zip_names($r['body'])) === 3, 'ZIP مدیر ارشد شامل هر ۳ مدرک است');

$r = $get('pt_ltd', 'admin/users'); check($r['code'] === 403, 'صفحه‌ی کاربران برای کارشناس → ۴۰۳');
$r = $get('pt_ltd', "admin/access?id=$idFull"); check($r['code'] === 403, 'صفحه‌ی دسترسی فیلدها برای کارشناس → ۴۰۳');
$csrf = csrf_of($get('pt_ltd', 'admin/settings')['body']);
$r = http("$BASE/admin/access", ['jar' => $jars['pt_ltd'], 'post' => http_build_query(['_csrf' => $csrf, 'id' => $idLtd, 'mode' => 'all'])]);
$row = db()->query("SELECT field_access FROM admins WHERE id = $idLtd")->fetchColumn();
check($r['code'] === 403 && $row !== null, 'کارشناس نمی‌تواند دسترسی خودش را تغییر دهد');

$r = $get('pt_ltd', 'admin/logs');
check(!str_contains($r['body'], 'ثبت فرم توسط'), 'گزارش رویدادها: نام افراد برای کاربر محدود پنهان است');

/* ======================================================= ۳) بدون دسترسی */
head('کاربر بدون هیچ دسترسی');
$r = $get('pt_none', "admin/view?id=$sid");
check($r['code'] === 200 && !$leak($r['body'], array_merge($hidden, [$M['first'], fa_num($M['mob'])])), 'مشاهده‌ی فرم: هیچ داده‌ای نمایش داده نمی‌شود');
check(str_contains($r['body'], 'فرم BM-99-PERMT1') , 'به‌جای نام، کد رهگیری نمایش داده می‌شود');
foreach ($up as $k => $id) { $r = $get('pt_none', "admin/file?id=$id"); check($r['code'] === 403, "مدرک $k → ۴۰۳"); }
$r = $get('pt_none', "admin/files-zip?id=$sid"); check($r['code'] === 302, 'ZIP بدون مدرک مجاز → بازگشت با پیام خطا');
$txt = zip_text($get('pt_none', "admin/export?type=docx&id=$sid")['body']);
check(!$leak($txt, array_merge($hidden, [$M['first']])), 'خروجی Word بدون نشت');

/* ==================================================== ۴) کارشناس کامل و مدیر */
head('کارشناس بدون محدودیت و مدیر ارشد');
foreach (['pt_full', 'pt_super'] as $u) {
    $r = $get($u, "admin/view?id=$sid");
    $need = [$M['last'], fa_num($M['nid']), $M['mark'], $M['spouse'], $M['org']];
    check(count(array_filter($need, fn($n) => str_contains($r['body'], $n))) === count($need), "$u همه‌ی فیلدها را می‌بیند");
    foreach ($up as $k => $id) { $rr = $get($u, "admin/file?id=$id"); check($rr['code'] === 200, "$u مدرک $k را می‌بیند"); }
}
$r = $get('pt_super', 'admin/users'); check($r['code'] === 200 && str_contains($r['body'], 'pt_ltd') && str_contains($r['body'], 'محدود: ۳ از'), 'فهرست کاربران، خلاصه‌ی دسترسی را نشان می‌دهد');
$r = $get('pt_super', "admin/access?id=$idLtd"); check($r['code'] === 200 && str_contains($r['body'], 'value="personal.first_name" checked'), 'صفحه‌ی دسترسی، انتخاب‌های ذخیره‌شده را نشان می‌دهد');
$r = $get('pt_super', "admin/access?id=$idSuper"); check($r['code'] === 200 && str_contains($r['body'], 'قابل محدودسازی نیست'), 'مدیر ارشد قابل محدودسازی نیست');

/* ============================================ ۵) ذخیره‌ی دسترسی از رابط */
head('ذخیره‌ی دسترسی از طریق صفحه‌ی مدیر');
$csrf = csrf_of($get('pt_super', "admin/access?id=$idLtd")['body']);
$post = http_build_query(['_csrf' => $csrf, 'id' => $idLtd, 'mode' => 'custom',
    'keys' => ['personal.first_name', 'personal.last_name', 'bogus.key', 'personal.first_name']]);
$r = http("$BASE/admin/access", ['jar' => $jars['pt_super'], 'post' => $post]);
$stored = json_decode((string)db()->query("SELECT field_access FROM admins WHERE id = $idLtd")->fetchColumn(), true);
check($r['code'] === 302 && $stored === ['personal.first_name', 'personal.last_name'], 'ذخیره: فقط کلیدهای معتبر و بدون تکرار', 'ذخیره‌شده: ' . json_encode($stored));
$r = $get('pt_ltd', "admin/view?id=$sid");
check(str_contains($r['body'], $M['last']) && !str_contains($r['body'], fa_num($M['mob'])), 'تغییر دسترسی بلافاصله (بدون ورود دوباره) اعمال شد');

$r = http("$BASE/admin/access", ['jar' => $jars['pt_super'], 'post' => http_build_query(['id' => $idLtd, 'mode' => 'all'])]);
check($r['code'] === 419, 'ذخیره‌ی دسترسی بدون CSRF رد می‌شود');
$csrf = csrf_of($get('pt_super', "admin/access?id=$idLtd")['body']);
http("$BASE/admin/access", ['jar' => $jars['pt_super'], 'post' => http_build_query(['_csrf' => $csrf, 'id' => $idLtd, 'mode' => 'all'])]);
check(db()->query("SELECT field_access FROM admins WHERE id = $idLtd")->fetchColumn() === null, 'حالت «همه» دسترسی را به NULL برمی‌گرداند');
$r = $get('pt_ltd', "admin/view?id=$sid");
check(str_contains($r['body'], $M['mark']), 'پس از «همه»، کاربر همه‌چیز را می‌بیند');

/* ======================================================= ۶) غیرفعال‌سازی */
head('غیرفعال‌سازی کاربر در میانه‌ی نشست');
db()->prepare('UPDATE admins SET is_active = 0 WHERE id = ?')->execute([$idLtd]);
$r = $get('pt_ltd', "admin/view?id=$sid");
check($r['code'] === 302 && str_contains($r['loc'], 'admin/login'), 'کاربر غیرفعال‌شده بلافاصله بیرون انداخته می‌شود', 'کد ' . $r['code']);
$r = $get('pt_ltd', "admin/file?id={$up['photo']}");
check($r['code'] === 302, 'و به مدارک هم دسترسی ندارد');

/* ================================================== ۷) بدون ورود */
head('مسیرهای مدیریتی جدید بدون ورود');
$anon = tempnam(sys_get_temp_dir(), 'pt_jar'); $jars['anon'] = $anon;
foreach (["admin/file?id={$up['photo']}", "admin/files-zip?id=$sid", "admin/missing?id=$sid", "admin/missing-export?id=$sid", "admin/access?id=$idFull"] as $p) {
    $r = http("$BASE/$p", ['jar' => $anon]);
    check($r['code'] === 302 && str_contains($r['loc'], 'admin/login'), "/$p بدون ورود مسدود است", "کد {$r['code']}");
}

/* ================================================== ۸) بارگذاری عمومی */
head('بارگذاری مدارک توسط متقاضی (عمومی)');
$pendBase = (int)db()->query('SELECT COUNT(*) FROM uploads WHERE submission_id IS NULL')->fetchColumn();   // فایل‌های در انتظارِ نشست‌های دیگر
$A = tempnam(sys_get_temp_dir(), 'pt_jar'); $B = tempnam(sys_get_temp_dir(), 'pt_jar'); $jars['A'] = $A; $jars['B'] = $B;
$csrfA = csrf_of(http("$BASE/", ['jar' => $A])['body']);
$csrfB = csrf_of(http("$BASE/", ['jar' => $B])['body']);
$tmp = tempnam(sys_get_temp_dir(), 'pt_up'); file_put_contents($tmp, jpeg_bytes(800, 600));
$fileField = fn() => new CURLFile($tmp, 'image/jpeg', 'عکس من.jpg');
$upl = function (string $jar, array $fields) use ($BASE) {
    $r = http("$BASE/upload", ['jar' => $jar, 'post' => $fields]);
    return [$r, json_decode($r['body'], true)];
};

[$r, $j] = $upl($A, ['_csrf' => $csrfA, 'doc' => 'photo', 'file' => $fileField()]);
check($r['code'] === 200 && !empty($j['ok']) && !empty($j['file']['id']), 'بارگذاری عکس موفق و پاسخ JSON درست است', $r['body']);
$fid = (int)($j['file']['id'] ?? 0);
if ($fid) db()->prepare("UPDATE uploads SET ip = '203.0.113.9' WHERE id = ?")->execute([$fid]);

$r = http("$BASE/upload/file?id=$fid", ['jar' => $A]);
check($r['code'] === 200 && str_starts_with($r['type'], 'image/jpeg'), 'پیش‌نمایش فایل برای همان نشست کار می‌کند');
$r = http("$BASE/upload/file?id=$fid", ['jar' => $B]);
check($r['code'] === 404, 'نشست دیگر نمی‌تواند فایل در انتظار را ببیند', "کد {$r['code']}");
$r = http("$BASE/upload/file?id=$fid", ['jar' => $anon]);
check($r['code'] === 404, 'کاربر ناشناس هم نمی‌تواند');

$r = http("$BASE/upload/delete", ['jar' => $B, 'post' => http_build_query(['_csrf' => $csrfB, 'id' => $fid])]);
check($r['code'] === 404 && (int)db()->query("SELECT COUNT(*) FROM uploads WHERE id = $fid")->fetchColumn() === 1, 'نشست دیگر نمی‌تواند فایل را حذف کند');

[$r, $j] = $upl($A, ['_csrf' => $csrfA, 'doc' => 'photo', 'file' => $fileField()]);
check($r['code'] === 409 && empty($j['ok']), 'سقف تعداد فایل هر جایگاه (عکس: ۱) رعایت می‌شود', $r['body']);
[$r, $j] = $upl($A, ['doc' => 'nid_front', 'file' => $fileField()]);
check($r['code'] === 419, 'بارگذاری بدون CSRF رد می‌شود');
[$r, $j] = $upl($A, ['_csrf' => $csrfA, 'doc' => 'evil_../x', 'file' => $fileField()]);
check($r['code'] === 400, 'نوع مدرک نامعتبر رد می‌شود');
[$r, $j] = $upl($A, ['_csrf' => $csrfA, 'file' => $fileField()]);
check($r['code'] === 400, 'بدون نوع مدرک رد می‌شود');

file_put_contents($tmp, "%PDF-1.4\n%%EOF");
[$r, $j] = $upl($A, ['_csrf' => $csrfA, 'doc' => 'clearance', 'file' => new CURLFile($tmp, 'application/pdf', 'g.pdf')]);
check($r['code'] === 200 && !empty($j['file']['pdf']), 'PDF برای گواهی پذیرفته می‌شود');
$pdfId = (int)($j['file']['id'] ?? 0);
[$r, $j] = $upl($A, ['_csrf' => $csrfA, 'doc' => 'nid_back', 'file' => new CURLFile($tmp, 'application/pdf', 'g.pdf')]);
check($r['code'] === 200, 'PDF برای کارت ملی هم پذیرفته می‌شود (pdf مجاز)');
$r2 = http("$BASE/upload/file?id=$pdfId", ['jar' => $A]);
check(str_contains($r2['head'], 'attachment') && str_contains(strtolower($r2['head']), 'nosniff'), 'PDF فقط به‌صورت پیوست (دانلود) و با nosniff ارائه می‌شود');

file_put_contents($tmp, "%PDF-1.4\n%%EOF");
$csrfC = csrf_of(http("$BASE/", ['jar' => $B])['body']);
[$r, $j] = $upl($B, ['_csrf' => $csrfC, 'doc' => 'photo', 'file' => new CURLFile($tmp, 'application/pdf', 'x.pdf')]);
check($r['code'] === 422 && str_contains((string)($j['error'] ?? ''), 'فقط تصویر'), 'PDF برای عکس پرسنلی رد می‌شود', $r['body']);

file_put_contents($tmp, "%PDF-1.4\n1 0 obj<</Type/Catalog/OpenAction<</S/JavaScript/JS(app.alert(1))>>>>endobj\n%%EOF");
[$r, $j] = $upl($B, ['_csrf' => $csrfC, 'doc' => 'clearance', 'file' => new CURLFile($tmp, 'application/pdf', 'js.pdf')]);
check($r['code'] === 422 && str_contains((string)($j['error'] ?? ''), 'اسکریپت'), 'PDF دارای JavaScript رد می‌شود', $r['body']);

file_put_contents($tmp, '<?php system($_GET["c"]); ?>');
[$r, $j] = $upl($B, ['_csrf' => $csrfC, 'doc' => 'education', 'file' => new CURLFile($tmp, 'image/jpeg', 'shell.php.jpg')]);
check($r['code'] === 422, 'فایل اجرایی با پسوند jpg رد می‌شود');

// فایل GIF/BMP و SVG
$im = imagecreatetruecolor(100, 100); ob_start(); imagegif($im); $gif = ob_get_clean(); file_put_contents($tmp, $gif);
[$r, $j] = $upl($B, ['_csrf' => $csrfC, 'doc' => 'education', 'file' => new CURLFile($tmp, 'image/gif', 'a.gif')]);
check($r['code'] === 422, 'قالب GIF پذیرفته نمی‌شود');
file_put_contents($tmp, '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>');
[$r, $j] = $upl($B, ['_csrf' => $csrfC, 'doc' => 'education', 'file' => new CURLFile($tmp, 'image/svg+xml', 'a.svg')]);
check($r['code'] === 422, 'SVG پذیرفته نمی‌شود');

// حجم بیش از ۱۰ مگابایت
file_put_contents($tmp, str_repeat('A', 11 * 1024 * 1024));
[$r, $j] = $upl($B, ['_csrf' => $csrfC, 'doc' => 'education', 'file' => new CURLFile($tmp, 'image/jpeg', 'big.jpg')]);
check(in_array($r['code'], [413, 422], true) && empty($j['ok']), 'فایل بیش از ۱۰ مگابایت رد می‌شود (کد ' . $r['code'] . ')');

// فایل جعلی بدون بایت‌های تصویر با هدر PDF کوتاه نباید اجرا شود؛ ذخیره‌ی فایل‌ها فقط با نام تصادفی
$names = db()->query("SELECT stored_name FROM uploads WHERE ip = '203.0.113.9' OR token IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
check(!array_filter($names, fn($n) => !preg_match('/^[a-f0-9]{32}\.(jpg|pdf)$/', $n)), 'نام همه‌ی فایل‌های ذخیره‌شده تصادفی و امن است');
check(!is_file(__DIR__ . '/../public/' . ($names[0] ?? 'x')), 'فایل‌ها داخل ریشه‌ی وب نیستند');

// حذف توسط خود نشست
$r = http("$BASE/upload/delete", ['jar' => $A, 'post' => http_build_query(['_csrf' => $csrfA, 'id' => $fid])]);
check($r['code'] === 200 && (int)db()->query("SELECT COUNT(*) FROM uploads WHERE id = $fid")->fetchColumn() === 0, 'حذف فایل توسط صاحب نشست');
$r = http("$BASE/upload", ['jar' => $A]);
check($r['code'] === 405, 'GET روی /upload مجاز نیست');

// اتصال به فرم هنگام ثبت
head('اتصال مدارک به فرم هنگام ثبت نهایی (جریان کامل)');
$csrfS = csrf_of(http("$BASE/", ['jar' => $A])['body']);
[$r, $j] = $upl($A, ['_csrf' => $csrfS, 'doc' => 'spouse_nid_front', 'file' => (function () use ($tmp) { file_put_contents($tmp, jpeg_bytes(500, 400)); return new CURLFile($tmp, 'image/jpeg', 's.jpg'); })()]);
$spouseUp = (int)($j['file']['id'] ?? 0);
$form = [
    '_csrf' => $csrfS,
    'f[personal][first_name]' => 'مجرد', 'f[personal][last_name]' => 'آزمایشی', 'f[personal][father_name]' => 'حسن',
    'f[personal][national_id]' => make_nid((string)random_int(100000000, 899999999)), 'f[personal][birth_date]' => '1370/01/01',
    'f[personal][birth_place]' => 'تهران', 'f[personal][issue_place]' => 'تهران', 'f[personal][id_type]' => 'اصلی',
    'f[personal][religion]' => 'اسلام', 'f[personal][marital]' => 'مجرد', 'f[personal][dual_nationality]' => 'ندارم',
    'f[contact][mobile]' => '09121112233', 'f[pledge][filler_name]' => 'مجرد آزمایشی', 'f[pledge][filler_date]' => '1403/01/01',
    'f[pledge][accept]' => 'می‌پذیرم',
];
$r = http("$BASE/submit", ['jar' => $A, 'post' => http_build_query($form)]);
$row = db()->query("SELECT id FROM submissions WHERE first_name = 'مجرد' AND last_name = 'آزمایشی' ORDER BY id DESC LIMIT 1")->fetchColumn();
if ($row) $created['subs'][] = (int)$row;
if (!$row) { bad_('ثبت فرم انجام نشد: ' . $r['code'] . ' ' . $r['loc']); }
else {
    $docs = db()->query("SELECT doc_key FROM uploads WHERE submission_id = $row")->fetchAll(PDO::FETCH_COLUMN);
    sort($docs);
    check($docs === ['clearance', 'nid_back'], 'مدارک نشست به فرم متصل شد', 'متصل‌شده: ' . implode(',', $docs));
    check((int)db()->query("SELECT COUNT(*) FROM uploads WHERE id = $spouseUp")->fetchColumn() === 0, 'مدرک همسر برای فرد «مجرد» دور ریخته شد');
    $left = (int)db()->query("SELECT COUNT(*) FROM uploads WHERE submission_id IS NULL")->fetchColumn();
    check($left === $pendBase, 'هیچ فایل در انتظاری از این نشست باقی نماند', "باقی‌مانده: $left (قبل از آزمون: $pendBase)");
    $r = http("$BASE/upload/file?id=$pdfId", ['jar' => $A]);
    check($r['code'] === 404, 'پس از ثبت، مسیر پیش‌نمایش عمومی برای فایل ثبت‌شده بسته است');
}

echo "\n" . str_repeat('─', 56) . "\n";
echo $fail === 0 ? "  همه‌ی بررسی‌ها موفق بود ($pass مورد)\n\n" : "  موفق: $pass    ناموفق: $fail\n\n";
exit($fail === 0 ? 0 : 1);

<?php
$pageTitle = 'گزارش نواقص'; $adminPage = 'submissions';
require __DIR__ . '/_admin_top.php';
$c = $report['counts'];
$badge = ['required' => 'st-no', 'missing' => 'st-warn', 'block' => 'st-warn', 'doc' => 'st-rev', 'declaration' => 'st-new'];
?>

<div class="page-head">
  <a class="btn ghost sm no-print" href="<?= e(base_url('admin/view?id=' . $sub['id'])) ?>">→ بازگشت به فرم</a>
  <h1>گزارش نواقص — <?= e(sub_display_name($sub)) ?></h1>
  <span class="badge st-new" style="direction:ltr"><?= e($sub['tracking_code']) ?></span>
  <div class="spacer"></div>
  <div class="btn-row no-print">
    <a class="btn gold sm" href="<?= e(base_url('admin/missing-export?id=' . $sub['id'])) ?>">⬇ خروجی Excel</a>
    <button class="btn ghost sm" type="button" onclick="window.print()">🖨 چاپ</button>
  </div>
</div>

<?php if (!admin_full_access()): ?>
  <div class="alert warn"><b>ℹ</b><div>این گزارش فقط فیلدها و مدارکی را بررسی می‌کند که دسترسی شما اجازه‌ی دیدن آن‌ها را می‌دهد.</div></div>
<?php endif; ?>

<div class="stats">
  <div class="stat g">
    <div class="k">درصد تکمیل</div>
    <div class="v"><?= e(fa_num($report['percent'])) ?>٪</div>
    <div class="progress-line" style="margin:6px 0 0"><i style="width:<?= (int)$report['percent'] ?>%"></i></div>
  </div>
  <div class="stat r"><div class="k">فیلدهای الزامیِ خالی</div><div class="v"><?= e(fa_num($c['required'])) ?></div></div>
  <div class="stat w"><div class="k">فیلدها و بخش‌های خالی</div><div class="v"><?= e(fa_num($c['missing'] + $c['block'])) ?></div></div>
  <div class="stat"><div class="k">مدارک ناقص</div><div class="v"><?= e(fa_num($c['doc'])) ?></div></div>
</div>

<?php if (!$report['groups']): ?>
  <div class="alert ok"><b>✓</b><div>هیچ فیلد یا مدرک خالی‌ای یافت نشد.</div></div>
<?php endif; ?>

<?php foreach ($report['groups'] as $g): ?>
  <div class="card" style="padding:0;overflow:hidden">
    <div class="sec-title" style="margin:0;border-radius:0"><?= e($g['num'] . ') ' . $g['title']) ?>
      <span style="opacity:.8;font-weight:400"> — <?= e(fa_num(count($g['items']))) ?> مورد</span>
    </div>
    <div class="table-wrap" style="border:0;border-radius:0">
      <table class="tbl" style="min-width:560px">
        <thead><tr><th>بخش</th><th>فیلد / مدرک</th><th>محل</th><th style="width:140px">نوع</th></tr></thead>
        <tbody>
        <?php foreach ($g['items'] as $it): ?>
          <tr<?= $it['kind'] === 'declaration' ? ' style="opacity:.7"' : '' ?>>
            <td class="muted"><?= e($it['block']) ?></td>
            <td><b><?= e($it['label']) ?></b></td>
            <td><?= $it['where'] !== '' ? e($it['where']) : '<span class="muted">—</span>' ?></td>
            <td><span class="badge <?= e($badge[$it['kind']] ?? 'st-new') ?>"><?= e(REPORT_KIND_LABELS[$it['kind']] ?? '') ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endforeach; ?>

<div class="card no-print">
  <div class="card-head"><h2>راهنمای گزارش</h2></div>
  <ul class="muted" style="margin:0;padding-inline-start:20px;line-height:2.1">
    <li><b>الزامی</b>: فیلدی که پر کردنش اجباری است اما خالی مانده.</li>
    <li><b>خالی</b>: فیلد اختیاری که پر نشده (فیلدهای شرطی مثل «تاریخ صدور المثنی» فقط وقتی شرطشان برقرار باشد بررسی می‌شوند).</li>
    <li><b>بخش خالی</b>: جدولی که هیچ ردیفی ندارد یا از حداقل ردیف‌های لازم کمتر است.</li>
    <li><b>مدرک</b>: مدرکی که بارگذاری نشده یا تعداد فایل‌ها کمتر از حد انتظار است.</li>
    <li><b>احتمالاً مورد ندارد</b>: بخش‌های اظهاری (سلاح، بازداشت، مهاجرین و ...) که خالی مانده‌اند؛ نقص شمرده نمی‌شوند.</li>
  </ul>
</div>

<?php require __DIR__ . '/_admin_bottom.php'; ?>

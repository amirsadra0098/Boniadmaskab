<?php
$pageTitle = 'دسترسی فیلدها'; $adminPage = 'users';
require __DIR__ . '/_admin_top.php';
$totalFields = count(all_field_keys());
$targetName  = $target['display_name'] ?: $target['username'];
?>

<div class="page-head">
  <a class="btn ghost sm" href="<?= e(base_url('admin/users')) ?>">→ بازگشت به کاربران</a>
  <h1>دسترسی به فیلدهای فرم — <?= e($targetName) ?></h1>
  <span class="badge st-new" style="direction:ltr"><?= e($target['username']) ?></span>
</div>

<?php if ($target['role'] === 'super'): ?>
  <div class="alert info"><b>ℹ</b><div>«مدیر ارشد» همیشه به همه‌ی فیلدها و مدارک دسترسی دارد و قابل محدودسازی نیست.
    برای محدود کردن دسترسی، نقش کاربر باید «کارشناس» باشد.</div></div>
<?php else: ?>

<div class="alert info">
  <b>ℹ</b>
  <div>
    فیلدهایی را که این کاربر مجاز است ببیند، تیک بزنید. فیلدهای بدون تیک در <b>مشاهده‌ی فرم، چاپ، خروجی Word و Excel،
    فهرست فرم‌ها، جستجو و گزارش نواقص</b> برای او نمایش داده نمی‌شوند. مدارک بارگذاری‌شده (بخش «بارگذاری مدارک») هم به همین شکل تنظیم می‌شوند.
    تغییر دسترسی بلافاصله اعمال می‌شود.
  </div>
</div>

<form method="post" action="<?= e(base_url('admin/access')) ?>" id="accessForm">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$target['id'] ?>">

  <div class="card">
    <div class="opts" role="radiogroup" aria-label="نوع دسترسی">
      <label class="opt<?= $custom ? '' : ' sel' ?>">
        <input type="radio" name="mode" value="all"<?= $custom ? '' : ' checked' ?>><span>دسترسی به همه‌ی فیلدها و مدارک</span>
      </label>
      <label class="opt<?= $custom ? ' sel' : '' ?>">
        <input type="radio" name="mode" value="custom"<?= $custom ? ' checked' : '' ?>><span>فقط فیلدهای انتخاب‌شده</span>
      </label>
    </div>
  </div>

  <div id="accessTree" class="acc-tree<?= $custom ? '' : ' off' ?>">
    <div class="btn-row" style="margin-bottom:14px">
      <button type="button" class="btn ghost sm" data-act="all" data-scope="*">انتخاب همه</button>
      <button type="button" class="btn ghost sm" data-act="none" data-scope="*">برداشتن همه</button>
      <span class="muted" id="accCount"></span>
    </div>

    <?php foreach ($tree as $st): ?>
      <div class="card acc-step" data-step="<?= e($st['id']) ?>">
        <div class="card-head">
          <h2><?= e($st['num'] . ') ' . $st['title']) ?></h2>
          <div class="spacer"></div>
          <button type="button" class="btn ghost xs" data-act="all" data-scope="step">همه</button>
          <button type="button" class="btn ghost xs" data-act="none" data-scope="step">هیچ</button>
        </div>
        <?php foreach ($st['blocks'] as $b): ?>
          <div class="acc-block" data-block="<?= e($b['name']) ?>">
            <div class="acc-bhead">
              <b><?= e($b['title']) ?></b>
              <span class="spacer"></span>
              <button type="button" class="btn ghost xs" data-act="all" data-scope="block">همه</button>
              <button type="button" class="btn ghost xs" data-act="none" data-scope="block">هیچ</button>
            </div>
            <div class="opts acc-fields">
              <?php foreach ($b['fields'] as $f): $on = isset($sel[$f['key']]); ?>
                <label class="opt<?= $on ? ' sel' : '' ?>">
                  <input type="checkbox" name="keys[]" value="<?= e($f['key']) ?>"<?= $on ? ' checked' : '' ?><?= $custom ? '' : ' disabled' ?>>
                  <span><?= e($f['label']) ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="form-nav">
    <span class="muted" id="accSummary"></span>
    <div class="spacer"></div>
    <a class="btn ghost" href="<?= e(base_url('admin/users')) ?>">انصراف</a>
    <button class="btn ok" type="submit">ذخیره دسترسی</button>
  </div>
</form>

<script>
(function () {
  var TOTAL = <?= (int)$totalFields ?>;
  var form  = document.getElementById('accessForm');
  var tree  = document.getElementById('accessTree');
  var count = document.getElementById('accCount');
  var summ  = document.getElementById('accSummary');
  var modes = form.querySelectorAll('input[name="mode"]');

  function fa(n) { return String(n).replace(/[0-9]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'[+c]; }); }
  function boxes(scope) { return scope.querySelectorAll('input[type=checkbox][name="keys[]"]'); }
  function isCustom() { return form.querySelector('input[name="mode"]:checked').value === 'custom'; }

  function refresh() {
    var n = 0;
    boxes(tree).forEach(function (b) {
      if (b.checked) n++;
      b.closest('.opt').classList.toggle('sel', b.checked);
    });
    var t = isCustom() ? fa(n) + ' فیلد از ' + fa(TOTAL) + ' انتخاب شده است' : 'دسترسی کامل به همه‌ی ' + fa(TOTAL) + ' فیلد';
    count.textContent = isCustom() ? t : '';
    summ.textContent = t;
  }

  function applyMode() {
    var on = isCustom();
    tree.classList.toggle('off', !on);
    boxes(tree).forEach(function (b) { b.disabled = !on; });
    modes.forEach(function (r) { r.closest('.opt').classList.toggle('sel', r.checked); });
    refresh();
  }

  modes.forEach(function (r) { r.addEventListener('change', applyMode); });
  tree.addEventListener('change', refresh);

  tree.addEventListener('click', function (ev) {
    var btn = ev.target.closest('button[data-act]');
    if (!btn || !isCustom()) return;
    var scope = btn.dataset.scope === 'block' ? btn.closest('.acc-block')
              : btn.dataset.scope === 'step'  ? btn.closest('.acc-step') : tree;
    var on = btn.dataset.act === 'all';
    boxes(scope).forEach(function (b) { b.checked = on; });
    refresh();
  });

  form.addEventListener('submit', function (ev) {
    if (isCustom() && !form.querySelector('input[name="keys[]"]:checked')) {
      if (!window.confirm('هیچ فیلدی انتخاب نشده است؛ این کاربر هیچ اطلاعاتی از فرم‌ها نخواهد دید. ادامه می‌دهید؟')) ev.preventDefault();
    }
  });

  applyMode();
})();
</script>
<?php endif; ?>

<?php require __DIR__ . '/_admin_bottom.php'; ?>

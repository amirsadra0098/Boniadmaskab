<?php
$pageTitle = 'مشاهده فرم'; $adminPage = 'submissions';
require __DIR__ . '/_admin_top.php';
?>

<div class="page-head">
  <a class="btn ghost sm" href="<?= e(base_url('admin/submissions')) ?>">→ بازگشت</a>
  <h1><?= e(sub_display_name($sub)) ?></h1>
  <span class="badge <?= e(status_class($sub['status'])) ?>"><?= e(status_label($sub['status'])) ?></span>
  <div class="spacer"></div>
  <div class="btn-row">
    <a class="btn ghost sm" href="<?= e(base_url('admin/missing?id=' . $sub['id'])) ?>">📋 گزارش نواقص</a>
    <a class="btn gold sm" href="<?= e(base_url('admin/export?type=docx&id=' . $sub['id'])) ?>">⬇ خروجی Word</a>
    <a class="btn gold sm" href="<?= e(base_url('admin/export?type=xlsx&id=' . $sub['id'])) ?>">⬇ خروجی Excel</a>
    <a class="btn ghost sm" href="<?= e(base_url('admin/print?id=' . $sub['id'])) ?>" target="_blank">🖨 چاپ</a>
  </div>
</div>

<div class="card">
  <div class="kv">
    <div><b>کد رهگیری</b><span style="direction:ltr;text-align:right"><b><?= e($sub['tracking_code']) ?></b></span></div>
    <?php if (admin_col_can('national_id')): ?><div><b>کد ملی</b><span><?= e(fa_num($sub['national_id']) ?: '—') ?></span></div><?php endif; ?>
    <?php if (admin_col_can('mobile')): ?><div><b>تلفن همراه</b><span><?= e(fa_num($sub['mobile']) ?: '—') ?></span></div><?php endif; ?>
    <div><b>تاریخ ثبت</b><span><?= e(jdate($sub['created_at'], true)) ?> (<?= e(jdate_long($sub['created_at'])) ?>)</span></div>
    <div><b>آدرس IP</b><span style="direction:ltr;text-align:right"><?= e($sub['ip']) ?></span></div>
    <div><b>آخرین بررسی</b><span><?= $sub['reviewed_at'] ? e(jdate($sub['reviewed_at'], true) . ' — ' . $sub['reviewer_name']) : '<span class="muted">—</span>' ?></span></div>
  </div>
</div>

<div class="card no-print">
  <div class="card-head"><h2>بررسی و وضعیت</h2></div>
  <form method="post" action="<?= e(base_url('admin/status')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$sub['id'] ?>">
    <div class="grid">
      <div class="f w3">
        <label class="lbl" for="stx">وضعیت</label>
        <select id="stx" name="status">
          <?php foreach (STATUS_LABELS as $k => $v): ?>
            <option value="<?= e($k) ?>"<?= $sub['status'] === $k ? ' selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="f w6">
        <label class="lbl" for="nt">یادداشت کنترل‌کننده</label>
        <textarea id="nt" name="admin_note" rows="2"><?= e($sub['admin_note'] ?? '') ?></textarea>
      </div>
      <div class="f w3" style="display:flex;align-items:flex-end">
        <button class="btn" type="submit" style="width:100%">ذخیره وضعیت</button>
      </div>
    </div>
  </form>

  <?php if (is_superadmin()): ?>
    <form method="post" action="<?= e(base_url('admin/delete')) ?>" data-confirm="آیا از حذف قطعی این فرم مطمئن هستید؟ این عمل بازگشت‌پذیر نیست." style="margin-top:14px;border-top:1px solid var(--line-2);padding-top:14px">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)$sub['id'] ?>">
      <button class="btn danger sm" type="submit">حذف قطعی این فرم</button>
      <span class="muted">فقط مدیر ارشد. عملیات در گزارش رویدادها ثبت می‌شود.</span>
    </form>
  <?php endif; ?>
</div>

<?php
// مدارک: فقط جایگاه‌هایی که کاربر به آن‌ها دسترسی دارد؛ جایگاه نامرتبط و خالی (مثلاً همسر برای فرد مجرد) نمایش داده نمی‌شود
$docShown = []; $docCount = 0;
foreach (doc_defs() as $key => $d) {
    if (!admin_can('documents', $key)) continue;
    $files = $uploads[$key] ?? [];
    if (!$files && !doc_applies($d, $data)) continue;
    $docShown[$key] = [$d, $files];
    $docCount += count($files);
}
?>
<?php if ($docShown): ?>
<div class="card">
  <div class="card-head">
    <h2>مدارک بارگذاری‌شده</h2>
    <span class="badge st-new"><?= e(fa_num($docCount)) ?> فایل</span>
    <div class="spacer"></div>
    <?php if ($docCount): ?>
      <a class="btn gold sm no-print" href="<?= e(base_url('admin/files-zip?id=' . $sub['id'])) ?>">⬇ دانلود همه‌ی مدارک (ZIP)</a>
    <?php endif; ?>
  </div>
  <div class="doc-grid">
    <?php foreach ($docShown as $key => [$d, $files]): ?>
      <div class="doc-card<?= $files ? '' : ' none' ?>">
        <div class="doc-title"><?= e($d['label']) ?></div>
        <?php if (!$files): ?>
          <span class="muted">بارگذاری نشده</span>
        <?php else: ?>
          <div class="doc-files">
            <?php foreach ($files as $f): $isPdf = !str_starts_with((string)$f['mime'], 'image/'); $u = base_url('admin/file?id=' . (int)$f['id']); ?>
              <div class="doc-file">
                <?php if ($isPdf): ?>
                  <a class="up-thumb pdf" href="<?= e($u . '&dl=1') ?>">PDF</a>
                <?php else: ?>
                  <a class="up-thumb" href="<?= e($u) ?>" target="_blank" rel="noopener"><img src="<?= e($u) ?>" alt="<?= e($d['label']) ?>" loading="lazy"></a>
                <?php endif; ?>
                <a class="muted" href="<?= e($u . '&dl=1') ?>"><?= e(fmt_size((int)$f['size'])) ?> · دانلود</a>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-head"><h2>محتوای کامل فرم</h2></div>
  <?= render_ro_form($data, $steps, fn($b, $f) => admin_can($b, $f)) ?>
</div>

<?php require __DIR__ . '/_admin_bottom.php'; ?>

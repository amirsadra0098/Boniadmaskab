<?php
$pageTitle = 'فرم‌های ثبت‌شده'; $adminPage = 'submissions';
require __DIR__ . '/_admin_top.php';
$cn = admin_col_can('first_name') || admin_col_can('last_name');   // ستون نام
$cf = admin_col_can('father_name');
$ci = admin_col_can('national_id');
$cm = admin_col_can('mobile');
$cw = admin_col_can('org_name') || admin_col_can('position');
$qs = function (array $over = []) use ($q, $status, $from, $to, $sort) {
    return http_build_query(array_merge(compact('q', 'status', 'from', 'to', 'sort'), $over));
};
?>

<div class="page-head">
  <h1>فرم‌های ثبت‌شده</h1>
  <span class="badge st-new"><?= e(fa_num($total)) ?> مورد</span>
  <div class="spacer"></div>
  <a class="btn gold sm" href="<?= e(base_url('admin/export-list?' . $qs())) ?>">⬇ خروجی اکسل فهرست</a>
</div>

<div class="card">
  <form method="get" action="<?= e(base_url('admin/submissions')) ?>" class="filters">
    <div class="fx grow">
      <label class="lbl" for="q">جستجو (کد رهگیری<?= $cn ? '، نام' : '' ?><?= $ci ? '، کد ملی' : '' ?><?= $cm ? '، تلفن' : '' ?><?= $cw ? '، محل خدمت' : '' ?>)</label>
      <input type="text" id="q" name="q" value="<?= e($q) ?>" placeholder="مثلاً: احمدی یا ۰۰۱۲۳۴۵۶۷۸">
    </div>
    <div class="fx">
      <label class="lbl" for="st">وضعیت</label>
      <select id="st" name="status">
        <option value="">همه</option>
        <?php foreach (STATUS_LABELS as $k => $v): ?>
          <option value="<?= e($k) ?>"<?= $status === $k ? ' selected' : '' ?>><?= e($v) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="fx">
      <label class="lbl" for="from">از تاریخ</label>
      <div class="date-wrap"><input type="text" class="date-input" id="from" name="from" value="<?= e($from) ?>" placeholder="۱۴۰۳/۰۱/۰۱" autocomplete="off"></div>
    </div>
    <div class="fx">
      <label class="lbl" for="to">تا تاریخ</label>
      <div class="date-wrap"><input type="text" class="date-input" id="to" name="to" value="<?= e($to) ?>" placeholder="۱۴۰۳/۱۲/۲۹" autocomplete="off"></div>
    </div>
    <div class="fx">
      <label class="lbl" for="sort">ترتیب</label>
      <select id="sort" name="sort">
        <option value="new"<?= $sort === 'DESC' ? ' selected' : '' ?>>جدیدترین</option>
        <option value="old"<?= $sort === 'ASC' ? ' selected' : '' ?>>قدیمی‌ترین</option>
      </select>
    </div>
    <div class="fx">
      <button class="btn" type="submit">جستجو</button>
    </div>
    <?php if ($q !== '' || $status !== '' || $from !== '' || $to !== ''): ?>
      <div class="fx"><a class="btn ghost" href="<?= e(base_url('admin/submissions')) ?>">حذف فیلترها</a></div>
    <?php endif; ?>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <?php if (!$rows): ?>
    <div class="empty" style="margin:0;border-radius:0;padding:40px">موردی مطابق جستجوی شما یافت نشد.</div>
  <?php else: ?>
    <div class="table-wrap" style="border:0">
      <table class="tbl" style="min-width:1000px">
        <thead><tr>
          <th class="c" style="width:44px">#</th>
          <th>کد رهگیری</th>
          <?php if ($cn): ?><th>نام و نام خانوادگی</th><?php endif; ?>
          <?php if ($cf): ?><th>نام پدر</th><?php endif; ?>
          <?php if ($ci): ?><th>کد ملی</th><?php endif; ?>
          <?php if ($cm): ?><th>تلفن همراه</th><?php endif; ?>
          <?php if ($cw): ?><th>محل خدمت / پست</th><?php endif; ?>
          <th>وضعیت</th><th>تاریخ ثبت</th><th style="width:270px"></th>
        </tr></thead>
        <tbody>
        <?php $i = ($page - 1) * 20; foreach ($rows as $r): $i++; ?>
          <tr>
            <td class="c muted"><?= e(fa_num($i)) ?></td>
            <td class="nowrap" style="direction:ltr;text-align:right"><b><?= e($r['tracking_code']) ?></b></td>
            <?php if ($cn): ?><td class="nowrap"><?= e(sub_display_name($r)) ?></td><?php endif; ?>
            <?php if ($cf): ?><td class="nowrap"><?= e($r['father_name'] ?: '—') ?></td><?php endif; ?>
            <?php if ($ci): ?><td class="nowrap"><?= e(fa_num($r['national_id']) ?: '—') ?></td><?php endif; ?>
            <?php if ($cm): ?><td class="nowrap"><?= e(fa_num($r['mobile']) ?: '—') ?></td><?php endif; ?>
            <?php if ($cw): ?><td><?= admin_col_can('org_name') ? e(str_limit($r['org_name'], 28) ?: '—') : '' ?><?php if (admin_col_can('position') && $r['position']): ?><br><span class="muted"><?= e(str_limit($r['position'], 28)) ?></span><?php endif; ?></td><?php endif; ?>
            <td><span class="badge <?= e(status_class($r['status'])) ?>"><?= e(status_label($r['status'])) ?></span></td>
            <td class="nowrap"><?= e(jdate($r['created_at'], true)) ?></td>
            <td class="nowrap">
              <a class="btn ghost xs" href="<?= e(base_url('admin/view?id=' . $r['id'])) ?>">مشاهده</a>
              <a class="btn ghost xs" href="<?= e(base_url('admin/missing?id=' . $r['id'])) ?>">نواقص</a>
              <a class="btn ghost xs" href="<?= e(base_url('admin/export?type=docx&id=' . $r['id'])) ?>">Word</a>
              <a class="btn ghost xs" href="<?= e(base_url('admin/export?type=xlsx&id=' . $r['id'])) ?>">Excel</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php if ($pages > 1): ?>
  <div class="pager">
    <?php if ($page > 1): ?><a href="?<?= e($qs(['page' => $page - 1])) ?>">قبلی</a><?php endif; ?>
    <?php
    $start = max(1, $page - 3); $end = min($pages, $page + 3);
    if ($start > 1) echo '<a href="?' . e($qs(['page' => 1])) . '">۱</a><span>…</span>';
    for ($p = $start; $p <= $end; $p++) {
        echo $p === $page
            ? '<span class="cur">' . e(fa_num($p)) . '</span>'
            : '<a href="?' . e($qs(['page' => $p])) . '">' . e(fa_num($p)) . '</a>';
    }
    if ($end < $pages) echo '<span>…</span><a href="?' . e($qs(['page' => $pages])) . '">' . e(fa_num($pages)) . '</a>';
    ?>
    <?php if ($page < $pages): ?><a href="?<?= e($qs(['page' => $page + 1])) ?>">بعدی</a><?php endif; ?>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/_admin_bottom.php'; ?>

<?php
/**
 * مدارک بارگذاری‌شده (عکس پرسنلی، کارت ملی، شناسنامه و ...).
 *
 * جریان کار:
 *   ۱) متقاضی هر فایل را هنگام انتخاب، جداگانه (AJAX) بارگذاری می‌کند؛ فایل با «توکن نشست» او
 *      در جدول uploads به‌صورت «در انتظار» (submission_id = NULL) ذخیره می‌شود.
 *   ۲) هنگام ثبت نهایی فرم، فایل‌های در انتظار به همان فرم متصل می‌شوند (finalize_uploads).
 *   ۳) فقط مدیران وارد‌شده (و با دسترسی به همان مدرک) می‌توانند فایل را ببینند.
 *
 * امنیت: فایل‌ها بیرون از ریشه‌ی وب (storage/uploads) با نام تصادفی نگهداری می‌شوند؛ تصویرها با GD
 * بازسازی می‌شوند (حذف هر محتوای جاسازی‌شده و EXIF) و PDF فقط به‌صورت دانلود ارائه می‌شود.
 */

const UPLOAD_MAX_BYTES   = 10485760;   // ۱۰ مگابایت برای هر فایل
const UPLOAD_MAX_PIXELS  = 16000000;   // بیشینه‌ی تعداد پیکسل ورودی (جلوگیری از پر شدن حافظه)
const UPLOAD_SESSION_BYTES = 157286400; // بیشینه‌ی حجم فایل‌های در انتظار هر نشست (۱۵۰ مگابایت)
const UPLOAD_IMG_SIDE    = 2400;       // بزرگ‌ترین ضلع تصویر ذخیره‌شده
const UPLOAD_MAX_PENDING = 60;         // بیشینه‌ی فایل‌های در انتظار برای هر نشست
const UPLOAD_PENDING_TTL = 172800;     // فایل‌های ثبت‌نشده پس از ۲ روز پاک می‌شوند

function uploads_dir(): string { return STORAGE_DIR . '/uploads'; }

function upload_path(array $row): string
{
    // نام ذخیره‌شده فقط شامل حروف/عدد/نقطه است؛ برای اطمینان، مسیر بازهم پاکسازی می‌شود
    return uploads_dir() . '/' . basename((string)$row['stored_name']);
}

/** تعریف جایگاه‌های مدرک: نام → تعریف */
function doc_defs(): array
{
    static $defs = null;
    if ($defs !== null) return $defs;
    $defs = [];
    foreach (form_steps() as $step) {
        foreach ($step['blocks'] as $b) {
            if ($b['kind'] !== 'files') continue;
            foreach ($b['docs'] as $d) $defs[$d['name']] = $d;
        }
    }
    return $defs;
}

/** آیا این جایگاه با توجه به پاسخ‌های فرم، مرتبط است؟ (شرط when) */
function doc_applies(array $def, array $data): bool
{
    if (empty($def['when'])) return true;
    $w   = $def['when'];
    $cur = $data[$w['block']][$w['field']] ?? '';
    return in_array($cur, $w['values'], true);
}

function fmt_size(int $bytes): string
{
    if ($bytes >= 1048576) return fa_num(rtrim(rtrim(number_format($bytes / 1048576, 1, '.', ''), '0'), '.')) . ' مگابایت';
    return fa_num(max(1, (int)round($bytes / 1024))) . ' کیلوبایت';
}

/** نام نمایشی امن برای فایل ارسالی (فقط برای نمایش؛ نام روی دیسک تصادفی است) */
function upload_clean_name(string $n): string
{
    $n = basename(str_replace('\\', '/', $n));
    $n = preg_replace('/[\x00-\x1F\x7F<>:"|?*]+/u', '', $n) ?? '';
    if (!preg_match('//u', $n)) $n = '';
    $n = trim($n);
    return mb_substr($n !== '' ? $n : 'file', 0, 120);
}

/* ========================================================== توکن نشست */

/** توکن نشست برای فایل‌های در انتظار؛ اگر $create نادرست باشد فقط مقدار موجود را می‌خواند */
function upload_token(bool $create = false): string
{
    $t = $_SESSION['up_token'] ?? '';
    if (is_string($t) && preg_match('/^[a-f0-9]{32}$/', $t)) return $t;
    if (!$create) return '';
    $t = bin2hex(random_bytes(16));
    $_SESSION['up_token'] = $t;
    return $t;
}

/** فایل‌های در انتظار این نشست، دسته‌بندی‌شده بر اساس مدرک */
function pending_uploads(): array
{
    $t = upload_token();
    if ($t === '') return [];
    try {
        $st = db()->prepare('SELECT * FROM uploads WHERE token = ? AND submission_id IS NULL ORDER BY id');
        $st->execute([$t]);
        $out = [];
        foreach ($st->fetchAll() as $r) $out[$r['doc_key']][] = $r;
        return $out;
    } catch (Throwable $ex) {
        return [];
    }
}

/** فایل‌های متصل به یک فرم، دسته‌بندی‌شده بر اساس مدرک */
function submission_uploads(int $subId): array
{
    $st = db()->prepare('SELECT * FROM uploads WHERE submission_id = ? ORDER BY id');
    $st->execute([$subId]);
    $out = [];
    foreach ($st->fetchAll() as $r) $out[$r['doc_key']][] = $r;
    return $out;
}

/* ====================================================== پردازش فایل */

/** مقدار memory_limit به بایت (-1 = نامحدود) */
function upload_memory_limit(): int
{
    $v = trim((string)ini_get('memory_limit'));
    if ($v === '' || $v === '-1') return -1;
    $n = (int)$v;
    return match (strtolower(substr($v, -1))) { 'g' => $n * 1073741824, 'm' => $n * 1048576, 'k' => $n * 1024, default => $n };
}

/** آیا حافظه‌ی کافی برای بازکردن تصویری با این ابعاد هست؟ (پیش از GD، تا به‌جای خطای مرگبار پیام درست داده شود) */
function upload_memory_ok(int $w, int $h): bool
{
    $limit = upload_memory_limit();
    if ($limit < 0) return true;
    $need = (int)($w * $h * 5.5) + 8 * 1048576;          // بیت‌مپ مبدأ + بافرهای رمزگشا + تصویر مقصد
    return memory_get_usage(true) + $need < $limit;
}

/**
 * بررسی ساده‌ی محتوای PDF: وجود اسکریپت یا محتوای اجرایی (JavaScript، Launch، فایل جاسازی‌شده و ...).
 * نام‌های PDF را می‌توان با #xx مبهم کرد (مثل /J#61vaScript)؛ پیش از بررسی به حالت عادی برمی‌گردند.
 * بخش‌های فشرده‌ی «stream ... endstream» نادیده گرفته می‌شوند تا داده‌ی باینری، تشخیص اشتباه نسازد.
 * این بررسی یک لایه‌ی دفاعی اضافه است، نه تضمین کامل (محتوای داخل جریان‌های فشرده دیده نمی‌شود).
 * @return string|null پیام خطا در صورت مشکوک بودن
 */
function upload_pdf_problem(string $path): ?string
{
    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') return 'فایل PDF خوانده نشد.';

    $scan = ''; $pos = 0; $len = strlen($raw);
    while ($pos < $len) {
        $s = strpos($raw, 'stream', $pos);
        if ($s === false) { $scan .= substr($raw, $pos); break; }
        $scan .= substr($raw, $pos, $s - $pos + 6);            // متن شیء تا خود واژه‌ی stream
        if ($s >= 3 && substr($raw, $s - 3, 3) === 'end') { $pos = $s + 6; continue; }   // «endstream»
        $e = strpos($raw, 'endstream', $s + 6);
        if ($e === false) break;                               // جریان ناقص: بقیه نادیده گرفته می‌شود
        $pos = $e;
    }
    $scan = preg_replace_callback('/#([0-9A-Fa-f]{2})/', fn($m) => chr(hexdec($m[1])), $scan) ?? $scan;

    if (preg_match('#/(JavaScript|JS|Launch|EmbeddedFiles?|RichMedia|SubmitForm|ImportData|XFA)(?![A-Za-z0-9])#', $scan)) {
        return 'این فایل PDF شامل اسکریپت یا محتوای اجرایی است و پذیرفته نمی‌شود.';
    }
    return null;
}

/**
 * پویش ضدویروس (اختیاری). اگر clamdscan نصب باشد (یا config['antivirus_cmd'] تعیین شده باشد)،
 * فایل PDF پیش از ذخیره پویش می‌شود. خروجی ۱ = آلوده. خطای خود پویشگر نادیده گرفته و ثبت می‌شود.
 * @return string|null پیام خطا در صورت آلوده بودن
 */
function upload_av_problem(string $path): ?string
{
    $cmd = cfg('antivirus_cmd');
    if (!is_array($cmd) || !$cmd) {
        $cmd = null;
        foreach (['/usr/bin/clamdscan', '/usr/local/bin/clamdscan'] as $b) {
            if (is_executable($b)) { $cmd = [$b, '--no-summary', '--fdpass']; break; }
        }
    }
    if (!$cmd || !function_exists('proc_open')) return null;

    $p = @proc_open(array_merge($cmd, [$path]), [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (!is_resource($p)) { error_log('antivirus: cannot start scanner'); return null; }
    foreach ($pipes as $pp) stream_set_blocking($pp, false);

    $out = ''; $deadline = microtime(true) + 25;
    while (true) {
        $st = proc_get_status($p);
        foreach ($pipes as $pp) $out .= (string)fread($pp, 8192);
        if (!$st['running']) break;
        if (microtime(true) > $deadline) { proc_terminate($p, 9); error_log('antivirus: scan timed out'); foreach ($pipes as $pp) fclose($pp); proc_close($p); return null; }
        usleep(50000);
    }
    $exit = $st['exitcode'];
    foreach ($pipes as $pp) { $out .= (string)fread($pp, 8192); fclose($pp); }
    proc_close($p);

    if ($exit === 1) return 'فایل توسط ضدویروس رد شد.';
    if ($exit !== 0 && $exit !== -1) error_log('antivirus: scanner error ' . $exit . ' ' . trim($out));
    return null;
}

/**
 * بازسازی تصویر با GD: چرخش طبق EXIF، کوچک‌سازی، تخت‌کردن روی سفید و ذخیره به‌صورت JPEG.
 * @return array [باینری|null, پیام خطا|null]
 */
function upload_process_image(string $tmp): array
{
    if (!extension_loaded('gd')) return [null, 'افزونه GD در سرور فعال نیست.'];

    $info = @getimagesize($tmp);
    if (!$info) return [null, 'فایل انتخاب‌شده تصویر معتبر نیست.'];
    [$w, $h, $type] = $info;
    if ($w < 50 || $h < 50)                 return [null, 'ابعاد تصویر بسیار کوچک است.'];
    if ($w * $h > UPLOAD_MAX_PIXELS || !upload_memory_ok($w, $h)) {
        return [null, 'ابعاد تصویر بسیار بزرگ است؛ تصویر کوچک‌تری انتخاب کنید.'];
    }

    $src = match ($type) {
        IMAGETYPE_JPEG => @imagecreatefromjpeg($tmp),
        IMAGETYPE_PNG  => @imagecreatefrompng($tmp),
        IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($tmp) : false,
        default        => false,
    };
    if (!$src) return [null, 'قالب تصویر پشتیبانی نمی‌شود؛ از JPG، PNG یا PDF استفاده کنید.'];

    // چرخش بر اساس EXIF (عکس‌های موبایل)
    if ($type === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
        $ex  = @exif_read_data($tmp);
        $ori = (int)($ex['Orientation'] ?? 1);
        $deg = [3 => 180, 6 => -90, 8 => 90][$ori] ?? 0;
        if ($deg !== 0) {
            $rot = @imagerotate($src, $deg, 0);
            if ($rot) { imagedestroy($src); $src = $rot; $w = imagesx($src); $h = imagesy($src); }
        }
    }

    $scale = min(1, UPLOAD_IMG_SIDE / max($w, $h));
    $nw = max(1, (int)round($w * $scale));
    $nh = max(1, (int)round($h * $scale));

    $dst = imagecreatetruecolor($nw, $nh);
    imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));   // شفافیت روی سفید
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imagedestroy($src);

    ob_start();
    $ok  = imagejpeg($dst, null, 85);
    $bin = ob_get_clean();
    imagedestroy($dst);

    if (!$ok || $bin === false || $bin === '') return [null, 'پردازش تصویر ناموفق بود.'];
    return [$bin, null];
}

function upload_error_text(int $code): string
{
    return match ($code) {
        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیش از حد مجاز است (حداکثر ۱۰ مگابایت).',
        UPLOAD_ERR_PARTIAL   => 'ارسال فایل ناقص انجام شد؛ دوباره تلاش کنید.',
        UPLOAD_ERR_NO_FILE   => 'فایلی انتخاب نشده است.',
        default              => 'بارگذاری فایل انجام نشد.',
    };
}

/**
 * ذخیره‌ی یک فایل بارگذاری‌شده به‌عنوان «در انتظار».
 * @return array [ردیف پایگاه داده|null, پیام خطا|null]
 */
function upload_store(array $file, array $def, string $token): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return [null, upload_error_text((int)($file['error'] ?? 0))];
    $tmp = (string)($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) return [null, 'فایل معتبر نیست.'];
    $size = (int)($file['size'] ?? 0);
    if ($size <= 0)                  return [null, 'فایل خالی است.'];
    if ($size > UPLOAD_MAX_BYTES)    return [null, 'حجم فایل بیش از حد مجاز است (حداکثر ۱۰ مگابایت).'];

    if (!is_dir(uploads_dir()) && !@mkdir(uploads_dir(), 0770, true) && !is_dir(uploads_dir())) {
        error_log('uploads dir is not writable: ' . uploads_dir());
        return [null, 'ذخیره‌ی فایل ممکن نشد؛ با مدیر سیستم تماس بگیرید.'];
    }

    $head  = (string)@file_get_contents($tmp, false, null, 0, 5);
    $isPdf = ($head === '%PDF-');

    if ($isPdf) {
        if (empty($def['pdf'])) return [null, 'برای «' . $def['label'] . '» فقط تصویر (JPG یا PNG) پذیرفته می‌شود.'];
        if (($bad = upload_pdf_problem($tmp)) !== null) return [null, $bad];
        if (($bad = upload_av_problem($tmp)) !== null)  return [null, $bad];
        $ext = 'pdf'; $mime = 'application/pdf'; $bin = null;
    } else {
        [$bin, $err] = upload_process_image($tmp);
        if ($err !== null) return [null, $err];
        $ext = 'jpg'; $mime = 'image/jpeg';
    }

    $stored = bin2hex(random_bytes(16)) . '.' . $ext;
    $dest   = uploads_dir() . '/' . $stored;
    $okw = $isPdf ? @move_uploaded_file($tmp, $dest) : (@file_put_contents($dest, $bin) !== false);
    if (!$okw) {
        error_log('upload write failed: ' . $dest);
        return [null, 'ذخیره‌ی فایل ممکن نشد؛ با مدیر سیستم تماس بگیرید.'];
    }
    @chmod($dest, 0640);

    $finalSize = (int)@filesize($dest);
    try {
        db()->prepare(
            'INSERT INTO uploads (submission_id, token, doc_key, orig_name, stored_name, mime, size, ip, created_at)
             VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$token, $def['name'], upload_clean_name((string)($file['name'] ?? '')), $stored, $mime,
                    $finalSize, client_ip(), date('Y-m-d H:i:s')]);
        $id = (int)db()->lastInsertId(db_driver() === 'pgsql' ? 'uploads_id_seq' : null);
    } catch (Throwable $ex) {
        @unlink($dest);
        error_log('upload insert failed: ' . $ex->getMessage());
        return [null, 'ثبت فایل ناموفق بود؛ دوباره تلاش کنید.'];
    }

    $st = db()->prepare('SELECT * FROM uploads WHERE id = ?');
    $st->execute([$id]);
    return [$st->fetch() ?: null, null];
}

/** حذف فایل‌های روی دیسک و ردیف‌های آن‌ها */
function uploads_delete_rows(array $rows): void
{
    foreach ($rows as $r) {
        @unlink(upload_path($r));
        db()->prepare('DELETE FROM uploads WHERE id = ?')->execute([(int)$r['id']]);
    }
}

/** پاک‌سازی فایل‌هایی که بیش از ۲ روز بدون ثبت فرم مانده‌اند */
function uploads_cleanup_stale(): void
{
    try {
        $st = db()->prepare('SELECT * FROM uploads WHERE submission_id IS NULL AND created_at < ? ORDER BY id LIMIT 50');
        $st->execute([date('Y-m-d H:i:s', time() - UPLOAD_PENDING_TTL)]);
        uploads_delete_rows($st->fetchAll());
    } catch (Throwable $ex) {
        error_log('upload cleanup failed: ' . $ex->getMessage());
    }
}

/**
 * اتصال فایل‌های در انتظار این نشست به فرم ثبت‌شده.
 * فایل‌های نامرتبط (مثلاً مدارک همسر برای فرد مجرد) یا مازاد بر سقف هر جایگاه دور ریخته می‌شوند.
 * @return int تعداد فایل‌های متصل‌شده
 */
function finalize_uploads(int $subId, array $data): int
{
    $token = upload_token();
    if ($token === '') return 0;

    $defs = doc_defs();
    $st = db()->prepare('SELECT * FROM uploads WHERE token = ? AND submission_id IS NULL ORDER BY id');
    $st->execute([$token]);

    $kept = 0; $per = []; $drop = [];
    foreach ($st->fetchAll() as $r) {
        $def = $defs[$r['doc_key']] ?? null;
        $per[$r['doc_key']] = ($per[$r['doc_key']] ?? 0) + 1;
        if (!$def || !doc_applies($def, $data) || $per[$r['doc_key']] > (int)($def['max'] ?? 1)) { $drop[] = $r; continue; }
        db()->prepare('UPDATE uploads SET submission_id = ?, token = NULL WHERE id = ?')->execute([$subId, (int)$r['id']]);
        $kept++;
    }
    uploads_delete_rows($drop);
    unset($_SESSION['up_token']);
    return $kept;
}

/** حذف همه‌ی مدارک یک فرم (هنگام حذف فرم) */
function delete_submission_uploads(int $subId): void
{
    $st = db()->prepare('SELECT * FROM uploads WHERE submission_id = ?');
    $st->execute([$subId]);
    uploads_delete_rows($st->fetchAll());
}

/* ================================================================ ارائه */

/** هدر Content-Disposition سازگار با نام فارسی */
function content_disposition(string $type, string $filename): string
{
    $ascii = trim(preg_replace('/[^A-Za-z0-9._-]+/', '-', $filename), '-.');
    if ($ascii === '' || !preg_match('/[A-Za-z0-9]/', pathinfo($ascii, PATHINFO_FILENAME))) {
        $ascii = 'file' . (($ext = pathinfo($filename, PATHINFO_EXTENSION)) !== '' ? '.' . preg_replace('/[^A-Za-z0-9]/', '', $ext) : '');
    }
    return $type . '; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($filename);
}

/** ارسال فایل مدرک به مرورگر. تصویر درون‌خطی، PDF (و درخواست دانلود) به‌صورت پیوست. */
function upload_send(array $row, bool $download = false): void
{
    $path = upload_path($row);
    if (!is_file($path)) { http_response_code(404); exit('فایل یافت نشد.'); }

    $isImg = str_starts_with((string)$row['mime'], 'image/');
    $ext   = $isImg ? 'jpg' : 'pdf';
    $name  = upload_clean_name((string)$row['orig_name']);
    $name  = preg_replace('/\.[A-Za-z0-9]{1,5}$/', '', $name) . '.' . $ext;

    while (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: ' . ($isImg ? 'image/jpeg' : 'application/pdf'));
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: ' . content_disposition(($isImg && !$download) ? 'inline' : 'attachment', $name));
    header('X-Content-Type-Options: nosniff');
    header('Cross-Origin-Resource-Policy: same-origin');
    header("Content-Security-Policy: default-src 'none'; sandbox");
    header('Cache-Control: private, max-age=0, must-revalidate');
    readfile($path);
    exit;
}

/** پاسخ JSON برای درگاه‌های بارگذاری */
function upload_json(array $data, int $code = 200): void
{
    while (ob_get_level() > 0) ob_end_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** اطلاعات یک فایل برای ارسال به مرورگر */
function upload_public(array $r): array
{
    return [
        'id'   => (int)$r['id'],
        'name' => $r['orig_name'],
        'size' => (int)$r['size'],
        'sizeText' => fmt_size((int)$r['size']),
        'pdf'  => !str_starts_with((string)$r['mime'], 'image/'),
        'url'  => base_url('upload/file?id=' . (int)$r['id']),
    ];
}

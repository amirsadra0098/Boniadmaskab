<?php
/**
 * گزارش نواقص: کدام فیلدها و مدارک یک فرم پر نشده یا جا افتاده است.
 *
 * قواعد:
 *  - فیلد شرطی (when) فقط وقتی بررسی می‌شود که شرطش برقرار باشد؛ فیلد «ندارم/ندارد» پر حساب می‌شود.
 *  - در جدول‌های تکراری، ردیف کاملاً خالی نادیده گرفته می‌شود و فقط خانه‌های خالیِ ردیف‌های تکمیل‌شده نقص است.
 *  - بخش‌های «اظهاری» (declaration) که کاملاً خالی‌اند نقص شمرده نمی‌شوند (فرد ممکن است مورد نداشته باشد)
 *    و جداگانه با برچسب «احتمالاً مورد ندارد» می‌آیند.
 *  - فقط فیلدهای موجود در $steps بررسی می‌شوند؛ برای کاربر محدودشده، فقط فیلدهای مجاز.
 *
 * نوع هر مورد (kind):
 *   required     فیلد الزامی که خالی است
 *   missing      فیلد اختیاری خالی
 *   block        کل بخش/ردیف خالی یا کمتر از حداقل
 *   doc          مدرک بارگذاری‌نشده یا ناقص
 *   declaration  بخش اظهاریِ خالی (نقص شمرده نمی‌شود)
 */

/** آیا شرط when/required_when/expect با داده‌ی فرم برقرار است؟ */
function report_cond(array $c, array $data): bool
{
    $cur = $data[$c['block']][$c['field']] ?? '';
    return in_array($cur, $c['values'], true);
}

function submission_report(array $data, array $steps, array $uploads): array
{
    $groups = [];
    $counts = ['required' => 0, 'missing' => 0, 'block' => 0, 'doc' => 0, 'declaration' => 0];
    $checked = 0; $filled = 0;

    $isRequired = function (array $f) use ($data): bool {
        if (!empty($f['required'])) return true;
        return !empty($f['required_when']) && report_cond($f['required_when'], $data);
    };

    foreach ($steps as $step) {
        $items = [];
        $add = function (string $kind, string $block, string $label, string $where = '') use (&$items, &$counts) {
            $items[] = ['kind' => $kind, 'block' => $block, 'label' => $label, 'where' => $where];
            $counts[$kind]++;
        };

        foreach ($step['blocks'] as $b) {
            $name  = $b['name'];
            $title = $b['title'] ?? $step['title'];
            $val   = $data[$name] ?? null;

            /* ------------------------------------------------ fields */
            if ($b['kind'] === 'fields') {
                foreach ($b['fields'] as $f) {
                    if (!empty($f['when'])) {
                        $cur = is_array($val) ? ($val[$f['when']['field']] ?? '') : '';
                        if (!in_array($cur, $f['when']['values'], true)) continue;
                    }
                    $checked++;
                    if (!is_blank(is_array($val) ? ($val[$f['name']] ?? '') : '')) { $filled++; continue; }
                    $add($isRequired($f) ? 'required' : 'missing', $title, $f['label']);
                }
                continue;
            }

            /* ------------------------------------------------- fixed */
            if ($b['kind'] === 'fixed') {
                if (!empty($b['applies']) && !report_cond($b['applies'], $data)) continue;

                foreach ($b['rows'] as $r) {
                    $rv = is_array($val[$r['key']] ?? null) ? $val[$r['key']] : [];
                    if (!empty($r['gate']) && ($rv[$r['gate']] ?? '') !== 'دارد') continue;

                    $cols = array_values(array_filter($b['columns'], fn($c) => empty($c['gate'])));
                    if (!$cols) continue;

                    $any = false;
                    foreach ($cols as $c) if (!is_blank($rv[$c['name']] ?? '')) { $any = true; break; }

                    if (!$any) {
                        if (!empty($b['declaration']) || !empty($r['optional'])) {
                            $add('declaration', $title, $r['label']);
                        } else {
                            $checked++;
                            $add('block', $title, $r['label'], 'کل ردیف خالی است');
                        }
                        continue;
                    }
                    foreach ($cols as $c) {
                        if (!empty($c['when']) && !in_array($rv[$c['when']['field']] ?? '', $c['when']['values'], true)) continue;
                        $checked++;
                        if (!is_blank($rv[$c['name']] ?? '')) { $filled++; continue; }
                        $add($isRequired($c) ? 'required' : 'missing', $title, $c['label'], $r['label']);
                    }
                }
                continue;
            }

            /* ------------------------------------------------ repeat */
            if ($b['kind'] === 'repeat') {
                $rows = clean_rows($b, $val);
                $min  = max(1, (int)($b['min'] ?? 1));
                $lbl  = $b['row_label'] ?? 'ردیف';

                if (!$rows) {
                    if (!empty($b['declaration'])) { $add('declaration', $title, 'هیچ موردی ثبت نشده'); }
                    else { $checked++; $add('block', $title, 'هیچ ردیفی تکمیل نشده است'); }
                    continue;
                }
                if (count($rows) < $min && empty($b['declaration'])) {
                    $checked++;
                    $add('block', $title, 'تعداد ردیف‌های تکمیل‌شده کمتر از حد انتظار است',
                        fa_num(count($rows)) . ' از حداقل ' . fa_num($min));
                }
                $i = 0;
                foreach ($rows as $row) {
                    $i++;
                    foreach ($b['columns'] as $c) {
                        $checked++;
                        if (!is_blank($row[$c['name']] ?? '')) { $filled++; continue; }
                        $add($isRequired($c) ? 'required' : 'missing', $title, $c['label'], $lbl . ' ' . fa_num($i));
                    }
                }
                continue;
            }

            /* ------------------------------------------------- files */
            if ($b['kind'] === 'files') {
                foreach ($b['docs'] as $d) {
                    if (!empty($d['when']) && !report_cond($d['when'], $data)) continue;
                    if (!empty($d['expect']) && !report_cond($d['expect'], $data)) continue;

                    $expected = 1;
                    if (!empty($d['per'])) {
                        $p = $d['per'];
                        $expected = 0;
                        foreach ((array)($data[$p['block']] ?? []) as $row) {
                            if (is_array($row) && ($row[$p['field']] ?? '') === $p['value']) $expected++;
                        }
                        if ($expected === 0) continue;
                    }

                    $n = count($uploads[$d['name']] ?? []);
                    $checked++;
                    if ($n >= $expected) { $filled++; continue; }
                    $add('doc', $title, $d['label'],
                        $n === 0 ? 'مدرکی بارگذاری نشده' : 'تعداد فایل‌ها (' . fa_num($n) . ') کمتر از تعداد مورد انتظار (' . fa_num($expected) . ')');
                }
            }
        }

        if ($items) {
            $groups[] = ['id' => $step['id'], 'num' => $step['num'], 'title' => $step['title'], 'items' => $items];
        }
    }

    $gaps = $counts['required'] + $counts['missing'] + $counts['block'] + $counts['doc'];
    return [
        'groups'  => $groups,
        'counts'  => $counts,
        'gaps'    => $gaps,
        'checked' => $checked,
        'filled'  => $filled,
        'percent' => $checked > 0 ? (int)round($filled / $checked * 100) : 100,
    ];
}

const REPORT_KIND_LABELS = [
    'required'    => 'الزامی',
    'missing'     => 'خالی',
    'block'       => 'بخش خالی',
    'doc'         => 'مدرک',
    'declaration' => 'احتمالاً مورد ندارد',
];

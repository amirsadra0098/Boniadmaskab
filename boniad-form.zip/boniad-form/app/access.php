<?php
/**
 * دسترسی کاربران پنل به فیلدهای فرم.
 *
 *  - مدیر ارشد (role = super) همیشه به همه‌ی فیلدها و مدارک دسترسی دارد.
 *  - برای «کارشناس» (operator) ستون admins.field_access تعیین می‌کند چه فیلدهایی دیده شود:
 *      NULL          → همه‌ی فیلدها (رفتار پیش‌فرض و سازگار با نصب‌های قبلی)
 *      ["block.field", "block.*", ...] → فقط همین‌ها (block.* یعنی همه‌ی فیلدهای آن بخش)
 *  - کلید هر فیلد «نام بلوک + نقطه + نام فیلد» است؛ ستون‌های جدول‌های تکراری و مدارک هم همین‌طورند
 *    (مثلاً family.job یا documents.photo).
 *
 * اصل: در نبود کاربر وارد‌شده یا اطلاعات ناقص، همه‌چیز «مجاز نیست» (fail-closed).
 */

/** ستون‌های جدول submissions که مستقیماً از یک فیلد فرم پر می‌شوند: ستون => [بلوک, فیلد] */
const SUB_COLUMN_FIELDS = [
    'first_name'  => ['personal', 'first_name'],
    'last_name'   => ['personal', 'last_name'],
    'father_name' => ['personal', 'father_name'],
    'national_id' => ['personal', 'national_id'],
    'birth_date'  => ['personal', 'birth_date'],
    'mobile'      => ['contact', 'mobile'],
    'org_name'    => ['workplace', 'org_name'],
    'position'    => ['workplace', 'position'],
];

function field_key(string $block, string $field): string { return $block . '.' . $field; }

/** همه‌ی فیلدهای فرم و مدارک: کلید => ['label','block','step'] */
function all_field_keys(): array
{
    static $all = null;
    if ($all !== null) return $all;
    $all = [];
    foreach (form_steps() as $step) {
        foreach ($step['blocks'] as $b) {
            foreach (block_fields($b) as $f) {
                $all[field_key($b['name'], $f['name'])] = ['label' => $f['label'], 'block' => $b['name'], 'step' => $step['id']];
            }
        }
    }
    return $all;
}

/** درخت فیلدها برای صفحه‌ی تنظیم دسترسی: مرحله ← بلوک ← فیلد */
function access_tree(): array
{
    $tree = [];
    foreach (form_steps() as $step) {
        $blocks = [];
        foreach ($step['blocks'] as $b) {
            $fields = [];
            foreach (block_fields($b) as $f) {
                $fields[] = ['key' => field_key($b['name'], $f['name']), 'label' => $f['label']];
            }
            if ($fields) $blocks[] = ['name' => $b['name'], 'title' => $b['title'] ?? $step['title'], 'fields' => $fields];
        }
        if ($blocks) $tree[] = ['id' => $step['id'], 'num' => $step['num'], 'title' => $step['title'], 'blocks' => $blocks];
    }
    return $tree;
}

/* ------------------------------------------------- ذخیره‌سازی و تفسیر */

/** JSON ذخیره‌شده ← null (همه) یا آرایه‌ای از کلیدها. مقدار خراب = هیچ (امن‌ترین حالت) */
function access_decode($json): ?array
{
    if ($json === null || $json === '') return null;
    $v = json_decode((string)$json, true);
    if (!is_array($v)) return [];
    return array_values(array_filter($v, 'is_string'));
}

function access_allows(array $keys, string $block, string $field): bool
{
    return in_array($block . '.*', $keys, true) || in_array(field_key($block, $field), $keys, true);
}

/** کلیدهای انتخاب‌شده‌ی فرم ← فهرست فشرده برای ذخیره (فقط کلیدهای معتبر؛ بلوک کامل = block.*) */
function access_compress(array $selected): array
{
    $valid = all_field_keys();
    $byBlock = [];
    foreach ($selected as $k) {
        if (is_string($k) && isset($valid[$k])) $byBlock[$valid[$k]['block']][$k] = true;
    }
    $out = [];
    foreach (form_steps() as $step) {
        foreach ($step['blocks'] as $b) {
            $keys = array_map(fn($f) => field_key($b['name'], $f['name']), block_fields($b));
            $got  = array_filter($keys, fn($k) => isset($byBlock[$b['name']][$k]));
            if ($keys && count($got) === count($keys)) $out[] = $b['name'] . '.*';
            else foreach ($got as $k) $out[] = $k;
        }
    }
    return $out;
}

/** فهرست فشرده ← مجموعه‌ی کامل کلیدهای مجاز (برای تیک‌زدن کادرها در صفحه‌ی تنظیم) */
function access_expand(?array $keys): array
{
    $out = [];
    foreach (all_field_keys() as $k => $meta) {
        [$b, $f] = explode('.', $k, 2);
        if ($keys === null || access_allows($keys, $b, $f)) $out[$k] = true;
    }
    return $out;
}

/** خلاصه برای نمایش در فهرست کاربران */
function access_summary(string $role, $json): array
{
    $total = count(all_field_keys());
    if ($role === 'super') return ['full' => true, 'count' => $total, 'total' => $total];
    $keys = access_decode($json);
    if ($keys === null) return ['full' => true, 'count' => $total, 'total' => $total];
    $n = count(access_expand($keys));
    return ['full' => $n === $total, 'count' => $n, 'total' => $total];
}

/* ------------------------------------------------------ کاربر جاری */

/** آیا کاربر پنل به فیلد مجاز است؟ (پیش‌فرض: کاربر جاری نشست) */
function admin_can(string $block, string $field, ?array $admin = null): bool
{
    $a = $admin ?? current_admin();
    if (!$a) return false;
    if (($a['role'] ?? '') === 'super') return true;
    if (!array_key_exists('fa', $a)) return false;      // اطلاعات دسترسی بارگذاری نشده
    if ($a['fa'] === null) return true;                 // بدون محدودیت
    return access_allows((array)$a['fa'], $block, $field);
}

/** آیا ستون جدول submissions (نام، کد ملی، ...) برای کاربر جاری مجاز است؟ */
function admin_col_can(string $col): bool
{
    if (!isset(SUB_COLUMN_FIELDS[$col])) return true;   // ستون‌های غیرفرمی (کد رهگیری، وضعیت و ...)
    return admin_can(SUB_COLUMN_FIELDS[$col][0], SUB_COLUMN_FIELDS[$col][1]);
}

/** آیا کاربر جاری همه‌ی فیلدها را می‌بیند؟ */
function admin_full_access(): bool
{
    $a = current_admin();
    if (!$a) return false;
    if (($a['role'] ?? '') === 'super') return true;
    return array_key_exists('fa', $a) && $a['fa'] === null;
}

/** فقط بخش‌ها/فیلدها/ستون‌ها/مدارکی که مجاز هستند را نگه می‌دارد */
function filter_steps(array $steps, callable $can): array
{
    $out = [];
    foreach ($steps as $step) {
        $blocks = [];
        foreach ($step['blocks'] as $b) {
            $key = match ($b['kind']) { 'fields' => 'fields', 'files' => 'docs', default => 'columns' };
            $b[$key] = array_values(array_filter($b[$key], fn($f) => $can($b['name'], $f['name'])));
            if ($b[$key]) $blocks[] = $b;
        }
        if ($blocks) { $step['blocks'] = $blocks; $out[] = $step; }
    }
    return $out;
}

/** مراحل فرم به‌همان‌اندازه که کاربر جاری مجاز است */
function admin_steps(): array
{
    return filter_steps(form_steps(), fn($b, $f) => admin_can($b, $f));
}

/** نام کامل برای نمایش؛ اگر کاربر به نام دسترسی ندارد، کد رهگیری نمایش داده می‌شود */
function sub_display_name(array $sub): string
{
    $parts = [];
    if (admin_col_can('first_name')) $parts[] = trim((string)($sub['first_name'] ?? ''));
    if (admin_col_can('last_name'))  $parts[] = trim((string)($sub['last_name'] ?? ''));
    $n = trim(implode(' ', array_filter($parts, fn($p) => $p !== '')));
    if ($n !== '') return $n;
    return admin_col_can('first_name') || admin_col_can('last_name') ? 'بدون نام' : 'فرم ' . ($sub['tracking_code'] ?? '');
}

/** توضیح رویداد برای نمایش؛ برای کاربر محدودشده اطلاعات هویتی داخل متن پنهان می‌شود */
function log_details_visible(array $log): string
{
    $d = (string)($log['details'] ?? '');
    if (admin_full_access()) return $d;
    return match ($log['action'] ?? '') {
        'submit' => 'ثبت فرم',
        'delete' => 'حذف فرم',
        'search' => 'جستجو',
        default  => $d,
    };
}

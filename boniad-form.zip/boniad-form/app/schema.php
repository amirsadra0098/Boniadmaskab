<?php
/**
 * ساختار جدول‌های پایگاه داده و ارتقای خودکار آن.
 *
 * migrate.php جدول‌های پایه را می‌سازد و سپس schema_upgrade() را اجرا می‌کند.
 * همین ارتقا اگر فایل‌های جدید روی نصب قبلی کپی شده باشند و migrate.php اجرا نشده باشد،
 * در اولین درخواست وب به‌صورت خودکار انجام می‌شود (ensure_schema).
 */

/** شماره‌ی نسخه‌ی ساختار پایگاه داده؛ با هر تغییر در schema_upgrade() افزایش یابد */
const SCHEMA_VERSION = '2';

/** نگاشت انواع ستون بر اساس درایور */
function schema_types(): array
{
    return [
        'mysql' => [
            'pk'   => 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
            'int'  => 'INT',
            'txt'  => 'TEXT',
            'ltxt' => 'LONGTEXT',
            'dt'   => 'DATETIME',
            'bool' => 'TINYINT(1)',
            'tail' => ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        ],
        'pgsql' => [
            'pk'   => 'SERIAL PRIMARY KEY',
            'int'  => 'INTEGER',
            'txt'  => 'TEXT',
            'ltxt' => 'TEXT',
            'dt'   => 'TIMESTAMP',
            'bool' => 'SMALLINT',
            'tail' => '',
        ],
        'sqlite' => [
            'pk'   => 'INTEGER PRIMARY KEY AUTOINCREMENT',
            'int'  => 'INTEGER',
            'txt'  => 'TEXT',
            'ltxt' => 'TEXT',
            'dt'   => 'TEXT',
            'bool' => 'INTEGER',
            'tail' => '',
        ],
    ][db_driver()];
}

function schema_vc(int $n): string { return db_driver() === 'sqlite' ? 'TEXT' : "VARCHAR($n)"; }

/** آیا ستون در جدول وجود دارد؟ (مستقل از درایور) */
function schema_has_column(PDO $pdo, string $table, string $column): bool
{
    try {
        $pdo->query("SELECT $column FROM $table WHERE 1 = 0")->closeCursor();
        return true;
    } catch (Throwable $ex) {
        return false;
    }
}

/**
 * ارتقای ساختار به نسخه‌ی فعلی:
 *   ۱) جدول uploads (مدارک بارگذاری‌شده)
 *   ۲) ستون admins.field_access (دسترسی کاربر به فیلدهای فرم)
 * چندبار اجرا شدن آن بی‌خطر است.
 */
function schema_upgrade(PDO $pdo): void
{
    $T = schema_types();

    $pdo->exec("CREATE TABLE IF NOT EXISTS uploads (
        id {$T['pk']},
        submission_id {$T['int']} NULL,
        token " . schema_vc(64) . " NULL,
        doc_key " . schema_vc(60) . " NOT NULL,
        orig_name " . schema_vc(190) . " NULL,
        stored_name " . schema_vc(90) . " NOT NULL,
        mime " . schema_vc(60) . " NOT NULL,
        size {$T['int']} NOT NULL,
        ip " . schema_vc(45) . " NULL,
        created_at {$T['dt']} NOT NULL
    ){$T['tail']}");

    foreach ([
        'idx_upl_sub'     => 'uploads (submission_id)',
        'idx_upl_token'   => 'uploads (token)',
        'idx_upl_created' => 'uploads (created_at)',
    ] as $name => $def) {
        try { $pdo->exec("CREATE INDEX IF NOT EXISTS $name ON $def"); }
        catch (Throwable $ex) {
            // MySQL قدیمی از IF NOT EXISTS برای ایندکس پشتیبانی نمی‌کند
            try { $pdo->exec("CREATE INDEX $name ON $def"); } catch (Throwable $e2) { /* از قبل وجود دارد */ }
        }
    }

    if (!schema_has_column($pdo, 'admins', 'field_access')) {
        $pdo->exec("ALTER TABLE admins ADD COLUMN field_access {$T['txt']} NULL");
    }

    $st = $pdo->prepare('SELECT COUNT(*) FROM settings WHERE k = ?');
    $st->execute(['schema_version']);
    if ((int)$st->fetchColumn() > 0) {
        $pdo->prepare('UPDATE settings SET v = ? WHERE k = ?')->execute([SCHEMA_VERSION, 'schema_version']);
    } else {
        $pdo->prepare('INSERT INTO settings (k, v) VALUES (?, ?)')->execute(['schema_version', SCHEMA_VERSION]);
    }
}

/** اگر ساختار پایگاه داده قدیمی است، در اولین درخواست وب ارتقا می‌دهد */
function ensure_schema(): void
{
    if (app_setting('schema_version') === SCHEMA_VERSION) return;
    try {
        // فقط روی پایگاه داده‌ی ساخته‌شده (جدول‌های پایه موجود)؛ نصب تازه با migrate.php انجام می‌شود
        db()->query('SELECT 1 FROM admins WHERE 1 = 0')->closeCursor();
        db()->query('SELECT 1 FROM settings WHERE 1 = 0')->closeCursor();
    } catch (Throwable $ex) {
        return;
    }
    try {
        schema_upgrade(db());
    } catch (Throwable $ex) {
        error_log('schema upgrade failed: ' . $ex->getMessage());
    }
}

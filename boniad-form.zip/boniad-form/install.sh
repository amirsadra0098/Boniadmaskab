#!/usr/bin/env bash
# =============================================================================
#  Personal Information Form System - Ubuntu Installer
#  Nginx + PHP-FPM + (MySQL | MariaDB | PostgreSQL | SQLite) [+ phpMyAdmin]
#
#  Usage:  sudo bash install.sh
#          sudo bash install.sh --db mysql --port 8080 --ssl
# =============================================================================

set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------------------------------------------------------- defaults
DB_ENGINE=""
APP_PORT="8080"
APP_DIR="/var/www/boniad-form"
APP_USER="www-data"
DB_NAME="boniad_form"
DB_USER="boniad_form"
DB_PASS=""
ADMIN_USER="admin"
ADMIN_PASS=""
DEV_PASS=""
DEV_PATH="dev"
DEV_MODE="no"
INSTALL_PMA="auto"          # auto | yes | no
SECURE_PMA="no"
USE_SSL="no"
ASSUME_YES="no"
DO_UNINSTALL="no"
APT_MIRROR="auto"           # auto | ir | arvan | iranserver | keep | <URL>
PMA_FILE=""
PMA_ROOT="/usr/share/phpmyadmin"
SITE_NAME="boniad-form"
NGINX_SITES_DIR="${NGINX_SITES_DIR:-/etc/nginx/sites-available}"
SKIP_APT="no"               # set to yes on an update when no package repository is reachable
UPDATE_MODE="auto"          # auto | yes | no   (--update / --fresh)
IS_UPDATE="no"              # set to "yes" when an existing installation was found
DIR_SET="no"; PORT_SET="no"; SSL_SET="no"; DB_OPTS_SET="no"
VERSION_NEW="$(head -n1 "$SRC_DIR/VERSION" 2>/dev/null | tr -d '[:space:]' || true)"
[[ -n "$VERSION_NEW" ]] || VERSION_NEW="unknown"

C_R=$'\e[0m'; C_B=$'\e[1m'; C_G=$'\e[32m'; C_Y=$'\e[33m'; C_E=$'\e[31m'; C_C=$'\e[36m'

say()  { echo -e "${C_C}>${C_R} $*"; }
ok()   { echo -e "${C_G}[ OK ]${C_R} $*"; }
warn() { echo -e "${C_Y}[WARN]${C_R} $*"; }
die()  { echo -e "\n${C_E}[FAIL]${C_R} $*\n" >&2; exit 1; }
hr()   { echo -e "${C_C}------------------------------------------------------------${C_R}"; }
bye()  { echo; echo "  Installation cancelled. Nothing was changed."; echo; exit 0; }

trap 'die "Aborted at line $LINENO."' ERR

# >>> update helpers -----------------------------------------------------------
# These functions detect an existing installation and replace its files safely.
# They are self-contained so they can be tested offline (see tools/ in the repo notes).

# base64 decode (config values are passed encoded so any character is safe)
b64d() { printf '%s' "$1" | base64 -d 2>/dev/null || true; }

# Is the application already installed? Looks where nginx points (unless --dir
# was given), then at $APP_DIR. Sets APP_DIR to the folder that was found.
detect_existing_install() {
  local site="$NGINX_SITES_DIR/$SITE_NAME" root=""
  if [[ "$DIR_SET" != "yes" && -f "$site" ]]; then
    root="$(sed -nE 's#^[[:space:]]*root[[:space:]]+(.+)/public;.*#\1#p' "$site" | head -n1)"
    if [[ -n "$root" && -f "$root/app/config.php" ]]; then APP_DIR="$root"; fi
  fi
  [[ -f "$APP_DIR/app/config.php" && -f "$APP_DIR/app/bootstrap.php" ]]
}

# Reads database/panel settings from the installed app/config.php into EX_* variables.
EX_DRIVER=""; EX_HOST=""; EX_PORT=""; EX_DBNAME=""; EX_DBUSER=""; EX_DBPASS=""; EX_DEVPATH=""; EX_APPKEY=""
load_existing_config() {
  command -v php >/dev/null 2>&1 || return 1
  local out line k v
  out="$(php -r '
    $c = @include $argv[1];
    if (!is_array($c) || empty($c["db"]["driver"])) exit(1);
    $d = $c["db"];
    $v = ["driver" => $d["driver"], "host" => $d["host"] ?? "127.0.0.1", "port" => $d["port"] ?? "",
          "name" => $d["database"] ?? "", "user" => $d["username"] ?? "", "pass" => $d["password"] ?? "",
          "devpath" => $c["dev_path"] ?? "dev", "appkey" => $c["app_key"] ?? ""];
    foreach ($v as $k => $x) echo $k, "=", base64_encode((string)$x), "\n";
  ' "$APP_DIR/app/config.php" 2>/dev/null)" || return 1
  [[ -n "$out" ]] || return 1
  while IFS= read -r line; do
    k="${line%%=*}"; v="${line#*=}"
    case "$k" in
      driver)  EX_DRIVER="$(b64d "$v")" ;;
      host)    EX_HOST="$(b64d "$v")" ;;
      port)    EX_PORT="$(b64d "$v")" ;;
      name)    EX_DBNAME="$(b64d "$v")" ;;
      user)    EX_DBUSER="$(b64d "$v")" ;;
      pass)    EX_DBPASS="$(b64d "$v")" ;;
      devpath) EX_DEVPATH="$(b64d "$v")" ;;
      appkey)  EX_APPKEY="$(b64d "$v")" ;;
    esac
  done <<<"$out"
  [[ -n "$EX_DRIVER" ]]
}

# Reads port / HTTPS / phpMyAdmin from the installed nginx site.
EX_WEBPORT=""; EX_SSL="no"; EX_PMA="no"
read_existing_web() {
  local site="$NGINX_SITES_DIR/$SITE_NAME"
  EX_WEBPORT=""; EX_SSL="no"; EX_PMA="no"
  if [[ -f "$site" ]]; then
    EX_WEBPORT="$(sed -nE 's/^[[:space:]]*listen[[:space:]]+([0-9]+)([[:space:]]+ssl)?;.*/\1/p' "$site" | head -n1)"
    if grep -qE '^[[:space:]]*listen[[:space:]]+[0-9]+[[:space:]]+ssl;' "$site"; then EX_SSL="yes"; fi
    if grep -q 'location \^~ /phpmyadmin' "$site"; then EX_PMA="yes"; fi
  fi
  return 0
}

installed_version() {
  local v=""
  if [[ -f "$APP_DIR/VERSION" ]]; then v="$(head -n1 "$APP_DIR/VERSION" | tr -d '[:space:]')"; fi
  echo "${v:-1.0 (older, no version file)}"
}

# ---- file comparison / replacement ------------------------------------------
SYNC_NEW=0; SYNC_CHANGED=0; SYNC_SAME=0; SYNC_REMOVED=0
SYNC_LOG=()

# Compare (and optionally copy) one file. Content is compared byte for byte, so a
# file that was edited on the server is detected even if its size is unchanged.
# sync_file <src> <dst> <label> <apply yes|no>
sync_file() {
  local s="$1" d="$2" label="$3" apply="$4"
  if [[ ! -f "$s" ]]; then return 0; fi
  if [[ ! -e "$d" ]]; then
    SYNC_NEW=$((SYNC_NEW + 1))
    SYNC_LOG+=("  + $label   (new, $(stat -c%s "$s") bytes)")
    if [[ "$apply" == "yes" ]]; then mkdir -p "$(dirname "$d")"; cp -f "$s" "$d"; fi
  elif ! cmp -s "$s" "$d"; then
    SYNC_CHANGED=$((SYNC_CHANGED + 1))
    SYNC_LOG+=("  ~ $label   ($(stat -c%s "$d") -> $(stat -c%s "$s") bytes)")
    if [[ "$apply" == "yes" ]]; then cp -f "$s" "$d"; fi
  else
    SYNC_SAME=$((SYNC_SAME + 1))
  fi
  return 0
}

# Make <dst> identical to <src>: new files are added, different files replaced and
# files that are no longer part of the release are removed. Paths listed after the
# label are never touched (e.g. app/config.php).
# sync_tree <src> <dst> <apply yes|no> <label> [excluded relative paths...]
sync_tree() {
  local src="$1" dst="$2" apply="$3" label="$4"; shift 4
  local s d rel x skip
  while IFS= read -r -d '' s; do
    rel="${s#"$src"/}"
    skip="no"
    for x in "$@"; do if [[ "$rel" == "$x" ]]; then skip="yes"; fi; done
    if [[ "$skip" == "yes" ]]; then continue; fi
    sync_file "$s" "$dst/$rel" "$label/$rel" "$apply"
  done < <(find "$src" -type f -print0 | sort -z)

  if [[ -d "$dst" ]]; then
    while IFS= read -r -d '' d; do
      rel="${d#"$dst"/}"
      skip="no"
      for x in "$@"; do if [[ "$rel" == "$x" ]]; then skip="yes"; fi; done
      if [[ "$skip" == "yes" || -e "$src/$rel" ]]; then continue; fi
      SYNC_REMOVED=$((SYNC_REMOVED + 1))
      SYNC_LOG+=("  - $label/$rel   (not part of this release)")
      if [[ "$apply" == "yes" ]]; then rm -f "$d"; fi
    done < <(find "$dst" -type f -print0 | sort -z)
    if [[ "$apply" == "yes" ]]; then find "$dst" -mindepth 1 -type d -empty -delete; fi
  fi
  return 0
}

# Runs the comparison for the whole release. apply=no only reports.
sync_release() {
  local apply="$1"
  SYNC_NEW=0; SYNC_CHANGED=0; SYNC_SAME=0; SYNC_REMOVED=0; SYNC_LOG=()
  sync_tree "$SRC_DIR/app"    "$APP_DIR/app"    "$apply" app config.php
  sync_tree "$SRC_DIR/public" "$APP_DIR/public" "$apply" public
  if [[ -d "$SRC_DIR/tools" ]]; then sync_tree "$SRC_DIR/tools" "$APP_DIR/tools" "$apply" tools; fi
  sync_file "$SRC_DIR/README.md" "$APP_DIR/README.md" README.md "$apply"
  sync_file "$SRC_DIR/VERSION"   "$APP_DIR/VERSION"   VERSION   "$apply"
  return 0
}

print_sync_log() {
  local n=0 line
  for line in "${SYNC_LOG[@]+"${SYNC_LOG[@]}"}"; do
    n=$((n + 1))
    if (( n <= 60 )); then echo "$line"; fi
  done
  if (( n > 60 )); then echo "  ... and $((n - 60)) more"; fi
  return 0
}

# PHP syntax check of a folder tree (used on the NEW files before anything is replaced)
check_php_syntax() {
  local f fail=0
  while IFS= read -r -d '' f; do
    if ! php -l "$f" >/dev/null 2>&1; then
      echo -e "${C_E}   Syntax error in: $f${C_R}"
      php -l "$f" || true
      fail=1
    fi
  done < <(find "$@" -name '*.php' -print0)
  [[ $fail -eq 0 ]]
}

# Back up what is installed, replace changed files, verify the result.
UPDATE_BACKUP=""; UPD_NEW=0; UPD_CHANGED=0; UPD_REMOVED=0; UPD_SAME=0
update_files() {
  local stamp bdir i old
  local -a items=()
  stamp="$(date +%Y%m%d-%H%M%S)"
  bdir="$APP_DIR/storage/backup"
  mkdir -p "$bdir"

  # 1) A copy of the current version first (rollback: tar -xzf <file> -C "$APP_DIR")
  for i in app public tools README.md VERSION; do
    if [[ -e "$APP_DIR/$i" ]]; then items+=("$i"); fi
  done
  UPDATE_BACKUP="$bdir/app_before_update_${stamp}.tar.gz"
  tar -czf "$UPDATE_BACKUP" -C "$APP_DIR" "${items[@]}" || die "Could not back up the current version - nothing was changed."
  chmod 600 "$UPDATE_BACKUP"
  while IFS= read -r old; do rm -f "$old"; done < <(ls -1t "$bdir"/app_before_update_*.tar.gz 2>/dev/null | tail -n +6)

  # 2) Replace
  sync_release yes
  UPD_NEW=$SYNC_NEW; UPD_CHANGED=$SYNC_CHANGED; UPD_REMOVED=$SYNC_REMOVED; UPD_SAME=$SYNC_SAME
  print_sync_log

  # 3) Verify: a second comparison must find nothing left to do
  sync_release no
  if (( SYNC_NEW + SYNC_CHANGED + SYNC_REMOVED > 0 )); then
    print_sync_log
    die "Verification failed: some files still differ from the release. Restore with: tar -xzf $UPDATE_BACKUP -C $APP_DIR"
  fi
  return 0
}

# Owner and permissions. Data folders never get the execute bit.
fix_permissions() {
  chown -R "$APP_USER":"$APP_USER" "$APP_DIR"
  find "$APP_DIR" -type d -exec chmod 750 {} \;
  find "$APP_DIR" -type f -exec chmod 640 {} \;
  find "$APP_DIR/storage" -type d -exec chmod 770 {} \;
  find "$APP_DIR/storage" -type f -exec chmod 660 {} \;
  chmod 640 "$APP_DIR/app/config.php"
  return 0
}

# Existing nginx site: only make sure uploads of up to 10 MB are allowed.
patch_nginx_limits() {
  local f="$NGINX_SITES_DIR/$SITE_NAME" cur
  cur="$(sed -nE 's/^[[:space:]]*client_max_body_size[[:space:]]+([0-9]+)[mM];.*/\1/p' "$f" | head -n1)"
  if [[ -z "$cur" ]]; then
    cp -a "$f" "$f.bak-$(date +%Y%m%d-%H%M%S)"
    sed -i -E '0,/^[[:space:]]*server_name .*/s//&\n    client_max_body_size 12m;/' "$f"
    ok "Nginx: added client_max_body_size 12m"
  elif (( cur < 12 )); then
    cp -a "$f" "$f.bak-$(date +%Y%m%d-%H%M%S)"
    sed -i -E 's/^([[:space:]]*client_max_body_size[[:space:]]+)[0-9]+[mM];/\112m;/' "$f"
    ok "Nginx: client_max_body_size raised from ${cur}m to 12m (needed for document uploads)"
  else
    ok "Nginx upload limit is already ${cur}m"
  fi
  return 0
}
# <<< update helpers -----------------------------------------------------------

# --------------------------------------------------------------- arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    --db)             DB_ENGINE="${2:-}"; DB_OPTS_SET="yes"; shift 2 ;;
    --port)           APP_PORT="${2:-}"; PORT_SET="yes"; shift 2 ;;
    --dir)            APP_DIR="${2:-}"; DIR_SET="yes"; shift 2 ;;
    --db-name)        DB_NAME="${2:-}"; DB_OPTS_SET="yes"; shift 2 ;;
    --db-user)        DB_USER="${2:-}"; DB_OPTS_SET="yes"; shift 2 ;;
    --db-pass)        DB_PASS="${2:-}"; DB_OPTS_SET="yes"; shift 2 ;;
    --admin-user)     ADMIN_USER="${2:-}"; DB_OPTS_SET="yes"; shift 2 ;;
    --admin-pass)     ADMIN_PASS="${2:-}"; DB_OPTS_SET="yes"; shift 2 ;;
    --update)         UPDATE_MODE="yes"; shift ;;
    --fresh)          UPDATE_MODE="no"; shift ;;
    --dev-pass)       DEV_PASS="${2:-}"; shift 2 ;;
    --dev-path)       DEV_PATH="${2:-dev}"; shift 2 ;;
    --dev)            DEV_MODE="yes"; shift ;;
    --phpmyadmin)     INSTALL_PMA="yes"; shift ;;
    --no-phpmyadmin)  INSTALL_PMA="no"; shift ;;
    --secure-pma)     SECURE_PMA="yes"; shift ;;
    --ssl)            USE_SSL="yes"; SSL_SET="yes"; shift ;;
    --mirror)         APT_MIRROR="${2:-auto}"; shift 2 ;;
    --pma-file)       PMA_FILE="${2:-}"; shift 2 ;;
    --no-fonts)       shift ;;                      # kept for compatibility
    -y|--yes)         ASSUME_YES="yes"; shift ;;
    --uninstall)      DO_UNINSTALL="yes"; shift ;;
    -h|--help)
      cat <<'USAGE'
Usage: sudo bash install.sh [options]

  --db <mysql|mariadb|pgsql|sqlite>  Database engine (asked interactively if omitted)
  --port <number>                    Web port (default 8080)
  --dir <path>                       Install path (default /var/www/boniad-form)
  --db-name / --db-user / --db-pass  Database settings
  --admin-user / --admin-pass        Admin panel account (random password if omitted)
  --dev-pass <password>              Password for the private builder panel
                                     (used to show/hide the footer credit).
                                     Asked interactively if omitted.
  --dev-path <name>                  URL of that panel (default: dev  ->  /dev)
  --dev                              Builder mode: asks for your password, then lets
                                     you turn the footer credit on or off.
                                     Does NOT install anything.
  --phpmyadmin | --no-phpmyadmin     Install phpMyAdmin or skip it
  --secure-pma                       Protect /phpmyadmin with an extra HTTP password
  --ssl                              Generate a self-signed certificate and enable HTTPS
  --mirror <auto|ir|iranserver|keep|URL>
                                     APT mirror. "auto" falls back to an Iranian
                                     mirror when the official one is unreachable.
  --pma-file <path>                  Install phpMyAdmin from a local tar.gz (no download)
  -y, --yes                          Run without prompts
  --update                           Update an existing installation (this is automatic
                                     when one is found; the option makes it mandatory)
  --fresh                            Ignore an existing installation and install from
                                     scratch (new config, new passwords)
  --uninstall                        Remove the service (database and files are kept)
  -h, --help                         Show this help

Updating: when the app is already installed, the installer finds it by itself,
compares every file with the new release byte by byte, backs up the old files,
replaces new / changed / no-longer-needed files and keeps your configuration,
database, accounts, uploads and settings. Nothing about the database or the
admin account is changed.

Examples:
  sudo bash install.sh --dev
  sudo bash install.sh
  sudo bash install.sh --db mysql --port 8080 --ssl --mirror ir -y
  sudo bash install.sh --db mysql --pma-file /root/phpMyAdmin.tar.gz -y
USAGE
      exit 0 ;;
    *) die "Unknown option: $1  (try --help)" ;;
  esac
done

# ----------------------------------------------------------- prerequisites
[[ $EUID -eq 0 ]] || die "This script must run as root:  sudo bash install.sh"
if [[ "$DEV_MODE" != "yes" ]]; then
  command -v apt-get >/dev/null 2>&1 || die "This script supports Ubuntu/Debian only."
  [[ -d "$SRC_DIR/app" && -d "$SRC_DIR/public" ]] || die "Could not find 'app' and 'public' next to install.sh"
  command -v openssl >/dev/null 2>&1 || die "openssl is required:  sudo apt-get install -y openssl"
fi

# =============================================================================
#  Builder mode:  sudo bash install.sh --dev
#  Asks for the builder password, then toggles the footer credit.
# =============================================================================
if [[ "$DEV_MODE" == "yes" ]]; then
  DEV_TOOL="$APP_DIR/tools/dev.php"
  [[ -f "$DEV_TOOL" ]] || DEV_TOOL="$SRC_DIR/tools/dev.php"
  [[ -f "$DEV_TOOL" ]] || die "Could not find tools/dev.php
   Is the app installed at $APP_DIR ?  Use --dir <path> to point at it."

  RUN_AS=()
  id -u "$APP_USER" >/dev/null 2>&1 && RUN_AS=(sudo -u "$APP_USER")

  STATE="$("${RUN_AS[@]}" php "$DEV_TOOL" status 2>/dev/null || echo error)"

  hr
  echo -e "${C_B}   Builder panel - rhino-team.ir${C_R}"
  hr
  echo

  if [[ "$STATE" == "nopass" ]]; then
    echo "  No builder password is set yet. Create one now."
    echo
    read -r -s -p "  New password (min 8 chars): " P1; echo
    read -r -s -p "  Repeat it: " P2; echo
    [[ "$P1" == "$P2" ]] || die "Passwords do not match."
    printf '%s' "$P1" | "${RUN_AS[@]}" php "$DEV_TOOL" set-pass >/dev/null       || die "Password must be at least 8 characters."
    ok "Password saved."
    STATE="$("${RUN_AS[@]}" php "$DEV_TOOL" status)"
  else
    [[ "$STATE" == "on" || "$STATE" == "off" ]] || die "Cannot read app settings. Is the database running?"
    read -r -s -p "  Your password: " DP; echo
    if ! printf '%s' "$DP" | "${RUN_AS[@]}" php "$DEV_TOOL" verify; then
      die "Wrong password."
    fi
    unset DP
    ok "Signed in."
  fi

  echo
  if [[ "$STATE" == "on" ]]; then
    echo "  Footer credit is currently:  SHOWN"
  else
    echo "  Footer credit is currently:  HIDDEN"
  fi
  echo
  echo "    1) Show the footer credit"
  echo "    2) Hide the footer credit"
  echo "    3) Change builder password"
  echo
  echo "    0) Exit"
  echo
  read -r -p "  Your choice [0]: " DCH
  case "${DCH:-0}" in
    1) "${RUN_AS[@]}" php "$DEV_TOOL" credit-on  >/dev/null; ok "Footer credit is now SHOWN." ;;
    2) "${RUN_AS[@]}" php "$DEV_TOOL" credit-off >/dev/null; ok "Footer credit is now HIDDEN." ;;
    3) read -r -s -p "  New password (min 8 chars): " N1; echo
       read -r -s -p "  Repeat it: " N2; echo
       [[ "$N1" == "$N2" ]] || die "Passwords do not match."
       printf '%s' "$N1" | "${RUN_AS[@]}" php "$DEV_TOOL" set-pass >/dev/null          || die "Password must be at least 8 characters."
       unset N1 N2
       ok "Password changed." ;;
    0|q|Q|exit|quit) bye ;;
    *) die "Invalid choice: '${DCH}'. Pick 0-3." ;;
  esac
  echo
  exit 0
fi

OS_NAME="$( { . /etc/os-release 2>/dev/null && echo "${PRETTY_NAME:-}"; } || true )"
[[ -n "$OS_NAME" ]] || OS_NAME="unknown"

# =============================================================================
#  Uninstall
# =============================================================================
if [[ "$DO_UNINSTALL" == "yes" ]]; then
  hr; say "Removing service..."
  rm -f "/etc/nginx/sites-enabled/$SITE_NAME" "$NGINX_SITES_DIR/$SITE_NAME"
  systemctl reload nginx 2>/dev/null || true
  rm -f /usr/local/bin/boniad-backup /etc/cron.d/boniad-backup
  warn "$APP_DIR and the database were NOT deleted, so your data stays safe."
  warn "Delete them manually if you really want to:  rm -rf $APP_DIR"
  ok "Service removed."
  exit 0
fi

# =============================================================================
#  Existing installation?  (automatic; --fresh skips this, --update requires it)
# =============================================================================
if [[ "$UPDATE_MODE" != "no" ]]; then
  if detect_existing_install; then
    if load_existing_config; then
      IS_UPDATE="yes"
    elif [[ "$UPDATE_MODE" == "yes" ]]; then
      die "Found an installation in $APP_DIR but could not read its app/config.php."
    else
      IS_UPDATE="no"
      warn "Found files in $APP_DIR but could not read its app/config.php - doing a fresh install."
    fi
  elif [[ "$UPDATE_MODE" == "yes" ]]; then
    die "No existing installation found (looked in $APP_DIR). Use --dir <path> if it lives elsewhere."
  fi
fi

if [[ "$IS_UPDATE" == "yes" ]]; then
  read_existing_web
  # Take everything from the installed copy, so the update never changes it
  DB_ENGINE="$EX_DRIVER"; PDO_DRIVER="$EX_DRIVER"
  DB_HOST="$EX_HOST"; DB_PORT="$EX_PORT"; DB_NAME="$EX_DBNAME"; DB_USER="$EX_DBUSER"; DB_PASS="$EX_DBPASS"
  DEV_PATH="${EX_DEVPATH:-dev}"; APP_KEY="$EX_APPKEY"
  if [[ -n "$EX_WEBPORT" ]]; then
    # The existing nginx site is kept as it is, so its port / HTTPS settings win
    if [[ "$PORT_SET" == "yes" && "$APP_PORT" != "$EX_WEBPORT" ]]; then
      warn "--port is ignored on an update (the site keeps port $EX_WEBPORT). Use --fresh to change it."
    fi
    if [[ "$SSL_SET" == "yes" && "$EX_SSL" != "yes" ]]; then
      warn "--ssl is ignored on an update (the site is served without HTTPS). Use --fresh to change it."
    fi
    APP_PORT="$EX_WEBPORT"; USE_SSL="$EX_SSL"
  fi
  if [[ "$INSTALL_PMA" == "yes" ]]; then
    warn "phpMyAdmin is not touched by an update (use --fresh to reinstall it)."
  fi
  INSTALL_PMA="no"   # never reinstall / reset phpMyAdmin on update
  INSTALLED_VERSION="$(installed_version)"
fi

# =============================================================================
#  Database selection
# =============================================================================
clear || true
hr
echo -e "${C_B}   Personal Information Form System - Server Installer${C_R}"
echo -e "   OS: $OS_NAME"
hr
echo

if [[ "$IS_UPDATE" == "yes" && "$DB_OPTS_SET" == "yes" ]]; then
  warn "This is an update: database / admin options on the command line are ignored (use --fresh to reinstall)."
fi

if [[ -z "$DB_ENGINE" ]]; then
  cat <<'MENU'
  Which database should be installed?

    1) MySQL       <- Recommended (installs phpMyAdmin too)
                      Stable, graphical admin tool, easy backups, handles
                      many people filling the form at the same time.
    2) MariaDB     Drop-in MySQL replacement, slightly lighter (phpMyAdmin included)
    3) PostgreSQL  Stronger with JSON data, but no real benefit at this scale
    4) SQLite      No separate service, single file. Testing or very few users only.

    0) Exit        Quit without changing anything

MENU
  read -r -p "  Your choice [1]: " choice
  case "${choice:-1}" in
    1) DB_ENGINE="mysql" ;;
    2) DB_ENGINE="mariadb" ;;
    3) DB_ENGINE="pgsql" ;;
    4) DB_ENGINE="sqlite" ;;
    0|q|Q|exit|quit) bye ;;
    *) die "Invalid choice: '${choice}'. Run again and pick 0-4." ;;
  esac
fi

case "$DB_ENGINE" in
  mysql|mariadb|pgsql|sqlite) ;;
  postgres|postgresql) DB_ENGINE="pgsql" ;;
  *) die "Invalid database engine: $DB_ENGINE" ;;
esac

if [[ "$INSTALL_PMA" == "auto" ]]; then
  if [[ "$DB_ENGINE" == "mysql" || "$DB_ENGINE" == "mariadb" ]]; then INSTALL_PMA="yes"; else INSTALL_PMA="no"; fi
fi

PDO_DRIVER="$DB_ENGINE"
[[ "$DB_ENGINE" == "mariadb" ]] && PDO_DRIVER="mysql"

# --------------------------------------------- builder panel password
if [[ -z "$DEV_PASS" && "$ASSUME_YES" != "yes" && "$IS_UPDATE" != "yes" ]]; then
  echo
  hr
  echo "  Builder panel (only you use this)"
  echo
  echo "  A private page at /$DEV_PATH lets you show or hide the"
  echo "  \"Built by rhino-team.ir\" line in the footer."
  echo "  Choose a password for it. Leave empty to set it later"
  echo "  on first visit to that page."
  echo
  read -r -s -p "  Builder password (min 8 chars, hidden): " DEV_PASS; echo
  if [[ -n "$DEV_PASS" ]]; then
    read -r -s -p "  Repeat it: " DEV_PASS2; echo
    if [[ "$DEV_PASS" != "$DEV_PASS2" ]]; then
      warn "Passwords do not match - you can set it later at /$DEV_PATH"
      DEV_PASS=""
    elif [[ ${#DEV_PASS} -lt 8 ]]; then
      warn "Too short - you can set it later at /$DEV_PATH"
      DEV_PASS=""
    fi
  fi
  hr
fi

[[ -n "$DB_PASS"    ]] || DB_PASS="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)"
[[ -n "$ADMIN_PASS" ]] || ADMIN_PASS="$(openssl rand -base64 12 | tr -d '/+=' | cut -c1-10)Aa1"
[[ -n "${APP_KEY:-}" ]] || APP_KEY="$(openssl rand -hex 32)"
PMA_DB_USER="pmaadmin"
PMA_DB_PASS="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)"
PMA_HTTP_USER="pma"
PMA_HTTP_PASS="$(openssl rand -base64 12 | tr -d '/+=' | cut -c1-12)"

SERVER_IP="$( { hostname -I 2>/dev/null || true; } | awk '{print $1}' )"
[[ -n "$SERVER_IP" ]] || SERVER_IP="127.0.0.1"

echo
hr
if [[ "$IS_UPDATE" == "yes" ]]; then
  echo -e "  ${C_B}UPDATE of an existing installation${C_R}"
  echo "   Found in   : $APP_DIR"
  echo "   Version    : $INSTALLED_VERSION  ->  $VERSION_NEW"
  echo "   Kept as is : configuration, database, accounts, passwords, uploads, logo"
  echo
  echo "   Files that will be added (+), replaced (~) or removed (-):"
  sync_release no
  print_sync_log
  if (( SYNC_NEW + SYNC_CHANGED + SYNC_REMOVED == 0 )); then
    echo "   (all files are already identical to this release)"
  fi
  echo "   Summary    : $SYNC_NEW new, $SYNC_CHANGED changed, $SYNC_REMOVED removed, $SYNC_SAME identical"
  echo "   The current files are backed up to storage/backup/ first."
  echo
else
  echo -e "  ${C_B}Installation summary${C_R}"
fi
echo "   Database   : $DB_ENGINE"
echo "   Install to : $APP_DIR"
echo "   Port       : $APP_PORT"
echo "   phpMyAdmin : $INSTALL_PMA"
echo "   HTTPS      : $USE_SSL"
echo "   APT mirror : $APT_MIRROR"
if [[ "$USE_SSL" == "yes" ]]; then echo "   Final URL  : https://$SERVER_IP:$APP_PORT"; else echo "   Final URL  : http://$SERVER_IP:$APP_PORT"; fi
hr
if [[ "$ASSUME_YES" != "yes" ]]; then
  echo "    [Y] Continue     [N] Exit"
  if [[ "$IS_UPDATE" == "yes" ]]; then
    read -r -p "  Proceed with the update? [Y/n]: " go
  else
    read -r -p "  Proceed with installation? [Y/n]: " go
  fi
  case "${go:-Y}" in
    [Yy]|"") ;;
    *) bye ;;
  esac
fi
echo

export DEBIAN_FRONTEND=noninteractive

# =============================================================================
#  1) APT mirror + base packages
# =============================================================================
reachable() { curl -fsS --max-time 10 -o /dev/null "$1" 2>/dev/null; }

CODENAME="$( { . /etc/os-release 2>/dev/null && echo "${VERSION_CODENAME:-}"; } || true )"
[[ -n "$CODENAME" ]] || CODENAME="noble"
IR_MIRRORS=( "https://mirror.arvancloud.ir/ubuntu" "https://mirror.iranserver.com/ubuntu" )

case "$APT_MIRROR" in
  keep)        MIRROR_URL="" ;;
  auto)        MIRROR_URL="auto" ;;
  ir|arvan)    MIRROR_URL="https://mirror.arvancloud.ir/ubuntu" ;;
  iranserver)  MIRROR_URL="https://mirror.iranserver.com/ubuntu" ;;
  http*)       MIRROR_URL="$APT_MIRROR" ;;
  *) die "Invalid --mirror value: $APT_MIRROR" ;;
esac

if [[ "$MIRROR_URL" == "auto" ]]; then
  say "Checking the official Ubuntu repository..."
  if reachable "http://archive.ubuntu.com/ubuntu/dists/$CODENAME/Release"; then
    ok "Official repository is reachable"
    MIRROR_URL=""
  else
    warn "Official Ubuntu repository is unreachable - trying Iranian mirrors..."
    MIRROR_URL=""
    for m in "${IR_MIRRORS[@]}"; do
      printf "   %-32s " "$(echo "$m" | cut -d/ -f3)"
      if reachable "$m/dists/$CODENAME/Release"; then echo "reachable"; MIRROR_URL="$m"; break
      else echo "unreachable"; fi
    done
    if [[ -z "$MIRROR_URL" ]]; then
      if [[ "$IS_UPDATE" == "yes" ]]; then
        warn "No package repository is reachable - skipping package installation (an update does not need it)."
        SKIP_APT="yes"
      else
        die "Neither the official repository nor the Iranian mirrors are reachable.
   Check the server's internet connection, or pass your own mirror:
     sudo bash install.sh --mirror https://mirror.example.ir/ubuntu"
      fi
    fi
  fi
fi

if [[ -n "$MIRROR_URL" ]]; then
  say "Switching APT to $MIRROR_URL"
  STAMP="$(date +%Y%m%d-%H%M%S)"
  if [[ -f /etc/apt/sources.list.d/ubuntu.sources ]]; then
    cp -a /etc/apt/sources.list.d/ubuntu.sources "/etc/apt/sources.list.d/ubuntu.sources.bak-$STAMP"
    sed -i -E "s#^URIs:.*#URIs: $MIRROR_URL#" /etc/apt/sources.list.d/ubuntu.sources
  fi
  if [[ -s /etc/apt/sources.list ]]; then
    cp -a /etc/apt/sources.list "/etc/apt/sources.list.bak-$STAMP"
    sed -i -E "s#https?://[a-z0-9.-]*archive[.]ubuntu[.]com/ubuntu#$MIRROR_URL#g; s#https?://security[.]ubuntu[.]com/ubuntu#$MIRROR_URL#g" /etc/apt/sources.list
  fi
  ok "Previous repository files backed up with suffix .bak-$STAMP"
fi

if [[ "$SKIP_APT" != "yes" ]]; then
  say "Updating package lists..."
  if ! apt-get update -qq; then
    if [[ "$IS_UPDATE" == "yes" ]]; then
      warn "apt-get update failed - continuing with the packages that are already installed."
      SKIP_APT="yes"
    else
      die "apt-get update failed.
   Try a different mirror:      sudo bash install.sh --mirror iranserver
   Or your organisation mirror: sudo bash install.sh --mirror https://mirror.example.ir/ubuntu"
    fi
  fi
fi

if [[ "$SKIP_APT" != "yes" ]]; then
  say "Installing Nginx and PHP..."
  if ! apt-get install -y -qq sudo nginx php-fpm php-cli php-mbstring php-xml php-zip \
                              php-curl php-gd curl unzip openssl ca-certificates >/dev/null; then
    if [[ "$IS_UPDATE" == "yes" ]]; then
      warn "Installing packages failed - continuing with the packages that are already installed."
    else
      die "Installing base packages failed. Check the apt output above."
    fi
  fi
fi

PHPVER="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
FPM_SOCK="/run/php/php${PHPVER}-fpm.sock"
ok "PHP $PHPVER installed"

# Document uploads (photos, ID cards, PDFs): up to 10 MB per file
for SAPI in fpm cli; do
  CONFD="/etc/php/${PHPVER}/${SAPI}/conf.d"
  if [[ -d "$CONFD" ]]; then
    cat > "$CONFD/99-boniad-form.ini" <<'PHPINI'
; Personal Information Form - document uploads
upload_max_filesize = 10M
post_max_size = 12M
max_file_uploads = 20
memory_limit = 256M
PHPINI
  fi
done
ok "PHP upload limits configured (10 MB per file)"

# =============================================================================
#  2) Database
# =============================================================================
if [[ "$IS_UPDATE" != "yes" ]]; then DB_HOST="127.0.0.1"; DB_PORT="3306"; fi

if [[ "$IS_UPDATE" == "yes" ]]; then
  # The database, its user and its password already exist and stay untouched.
  say "Keeping the existing $DB_ENGINE database (no changes)..."
  if [[ "$SKIP_APT" != "yes" ]]; then
    case "$PDO_DRIVER" in
      mysql)  apt-get install -y -qq "php${PHPVER}-mysql" >/dev/null 2>&1 || apt-get install -y -qq php-mysql >/dev/null 2>&1 || true ;;
      pgsql)  apt-get install -y -qq "php${PHPVER}-pgsql" >/dev/null 2>&1 || apt-get install -y -qq php-pgsql >/dev/null 2>&1 || true ;;
      sqlite) apt-get install -y -qq "php${PHPVER}-sqlite3" >/dev/null 2>&1 || apt-get install -y -qq php-sqlite3 >/dev/null 2>&1 || true ;;
    esac
  fi
  case "$PDO_DRIVER" in
    mysql)  systemctl start mysql 2>/dev/null || systemctl start mariadb 2>/dev/null || true ;;
    pgsql)  systemctl start postgresql 2>/dev/null || true ;;
  esac
  ok "Existing database kept"
else
case "$DB_ENGINE" in
  mysql|mariadb)
    if [[ "$DB_ENGINE" == "mysql" ]]; then
      say "Installing MySQL Server..."
      if ! apt-get install -y -qq mysql-server >/dev/null 2>&1; then
        warn "Package mysql-server is not available; installing MariaDB instead."
        apt-get install -y -qq mariadb-server >/dev/null
        DB_ENGINE="mariadb"
      fi
    else
      say "Installing MariaDB Server..."
      apt-get install -y -qq mariadb-server >/dev/null
    fi
    apt-get install -y -qq "php${PHPVER}-mysql" >/dev/null 2>&1 || apt-get install -y -qq php-mysql >/dev/null

    systemctl enable --now mysql 2>/dev/null || systemctl enable --now mariadb 2>/dev/null || true
    sleep 2

    say "Creating database and user..."
    mysql <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
ALTER USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
CREATE USER IF NOT EXISTS '${PMA_DB_USER}'@'localhost' IDENTIFIED BY '${PMA_DB_PASS}';
ALTER USER '${PMA_DB_USER}'@'localhost' IDENTIFIED BY '${PMA_DB_PASS}';
GRANT ALL PRIVILEGES ON *.* TO '${PMA_DB_USER}'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL
    ok "Database '${DB_NAME}' is ready"
    ;;

  pgsql)
    say "Installing PostgreSQL..."
    apt-get install -y -qq postgresql postgresql-contrib >/dev/null
    apt-get install -y -qq "php${PHPVER}-pgsql" >/dev/null 2>&1 || apt-get install -y -qq php-pgsql >/dev/null
    systemctl enable --now postgresql
    DB_PORT="5432"
    sleep 2
    say "Creating database and user..."
    sudo -u postgres psql -v ON_ERROR_STOP=0 <<SQL >/dev/null
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${DB_USER}') THEN
    CREATE ROLE ${DB_USER} LOGIN PASSWORD '${DB_PASS}';
  ELSE
    ALTER ROLE ${DB_USER} WITH PASSWORD '${DB_PASS}';
  END IF;
END \$\$;
SQL
    sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 || \
      sudo -u postgres createdb -O "${DB_USER}" -E UTF8 "${DB_NAME}"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};" >/dev/null
    ok "Database '${DB_NAME}' is ready"
    ;;

  sqlite)
    say "Installing SQLite..."
    apt-get install -y -qq sqlite3 >/dev/null
    apt-get install -y -qq "php${PHPVER}-sqlite3" >/dev/null 2>&1 || apt-get install -y -qq php-sqlite3 >/dev/null
    DB_NAME="${APP_DIR}/storage/db/form.sqlite"
    ok "SQLite is ready"
    ;;
esac
fi

# =============================================================================
#  3) Deploy application files
# =============================================================================
if [[ "$IS_UPDATE" == "yes" ]]; then
  # The new files are checked BEFORE anything is replaced, so a broken package can never break a working site.
  say "Checking the new PHP files for syntax errors..."
  check_php_syntax "$SRC_DIR/app" "$SRC_DIR/public" "$SRC_DIR/tools" || die "The new package contains syntax errors - nothing was changed."
  ok "New files are valid"

  say "Updating application files in $APP_DIR ..."
  update_files
  mkdir -p "$APP_DIR/storage/logs" "$APP_DIR/storage/db" "$APP_DIR/storage/backup" "$APP_DIR/storage/branding" "$APP_DIR/storage/uploads"
  fix_permissions
  ok "Files updated: $UPD_NEW new, $UPD_CHANGED replaced, $UPD_REMOVED removed, $UPD_SAME already identical"
  ok "Backup of the previous version: $UPDATE_BACKUP"
else
say "Copying application files to $APP_DIR ..."
mkdir -p "$APP_DIR"
rm -rf "$APP_DIR/app" "$APP_DIR/public" "$APP_DIR/tools"
cp -r "$SRC_DIR/app" "$SRC_DIR/public" "$APP_DIR/"
[[ -d "$SRC_DIR/tools" ]] && cp -r "$SRC_DIR/tools" "$APP_DIR/" || true
rm -f "$APP_DIR/app/config.php"
[[ -f "$SRC_DIR/README.md" ]] && cp "$SRC_DIR/README.md" "$APP_DIR/" || true
[[ -f "$SRC_DIR/VERSION" ]] && cp "$SRC_DIR/VERSION" "$APP_DIR/" || true
mkdir -p "$APP_DIR/storage/logs" "$APP_DIR/storage/db" "$APP_DIR/storage/backup" "$APP_DIR/storage/branding" "$APP_DIR/storage/uploads"

cat > "$APP_DIR/app/config.php" <<PHPCONF
<?php
return [
    'org_title'  => 'بنیاد مسکن انقلاب اسلامی',
    'form_title' => 'فرم اطلاعات فردی',
    'sub_title'  => 'مدیریت حراست',
    'base_path'  => '',
    'dev_path'   => '${DEV_PATH}',
    'app_key'    => '${APP_KEY}',
    'db' => [
        'driver'   => '${PDO_DRIVER}',
        'host'     => '${DB_HOST}',
        'port'     => ${DB_PORT},
        'database' => '${DB_NAME}',
        'username' => '${DB_USER}',
        'password' => '${DB_PASS}',
    ],
    'rate_limit_per_hour' => 8,
    'debug' => false,
];
PHPCONF

fix_permissions
ok "Files deployed"
fi

# ------------------------------------------------------------ syntax check
say "Checking PHP files for syntax errors..."
SYNTAX_FAIL=0
while IFS= read -r -d '' f; do
  if ! php -l "$f" >/dev/null 2>&1; then
    echo -e "${C_E}   Syntax error in: $f${C_R}"
    php -l "$f" || true
    SYNTAX_FAIL=1
  fi
done < <(find "$APP_DIR/app" "$APP_DIR/public" -name '*.php' -print0)
[[ $SYNTAX_FAIL -eq 0 ]] || die "Some PHP files contain syntax errors."
ok "All PHP files are valid"

# =============================================================================
#  4) Create tables and the admin account
# =============================================================================
say "Creating database tables..."
MIGRATE_ARGS=()
# On an update the admin account exists already and is never touched
[[ "$IS_UPDATE" == "yes" ]] || MIGRATE_ARGS+=( --admin-user="$ADMIN_USER" --admin-pass="$ADMIN_PASS" )
[[ -z "$DEV_PASS" ]] || MIGRATE_ARGS+=( --dev-pass="$DEV_PASS" )
sudo -u "$APP_USER" php "$APP_DIR/app/migrate.php" ${MIGRATE_ARGS[@]+"${MIGRATE_ARGS[@]}"}
ok "Database schema ready"

if [[ "$DB_ENGINE" == "sqlite" ]]; then
  chown -R "$APP_USER":"$APP_USER" "$APP_DIR/storage"
  find "$APP_DIR/storage/db" -type d -exec chmod 770 {} \;
  find "$APP_DIR/storage/db" -type f -exec chmod 660 {} \;
fi

# =============================================================================
#  5) Fonts (shipped with the app, no download needed)
# =============================================================================
FONT_DIR="$APP_DIR/public/assets/fonts"
if compgen -G "$FONT_DIR/*.woff2" >/dev/null; then
  chown -R "$APP_USER":"$APP_USER" "$FONT_DIR"
  chmod 640 "$FONT_DIR"/* 2>/dev/null || true
  ok "Vazirmatn font bundled with the app (no internet required)"
else
  warn "Font files are missing from the app folder; system fonts will be used."
fi

# =============================================================================
#  6) phpMyAdmin
# =============================================================================
PMA_ENABLED="no"
if [[ "$INSTALL_PMA" == "yes" ]]; then
  say "Installing phpMyAdmin..."
  TMPZ="/tmp/pma.tar.gz"
  PMA_GOT=0
  if [[ -n "$PMA_FILE" ]]; then
    if [[ -f "$PMA_FILE" ]]; then
      cp "$PMA_FILE" "$TMPZ"; PMA_GOT=1
      say "Using local archive: $PMA_FILE"
    else
      warn "phpMyAdmin archive not found: $PMA_FILE"
    fi
  fi
  if [[ $PMA_GOT -eq 0 ]] && curl -fsSL --max-time 120 -o "$TMPZ" \
       "https://www.phpmyadmin.net/downloads/phpMyAdmin-latest-all-languages.tar.gz"; then
    PMA_GOT=1
  fi
  if [[ $PMA_GOT -eq 1 ]]; then
    rm -rf "$PMA_ROOT"; mkdir -p "$PMA_ROOT"
    tar -xzf "$TMPZ" --strip-components=1 -C "$PMA_ROOT"
    rm -f "$TMPZ"
    BLOWFISH="$(openssl rand -hex 16)"
    cat > "$PMA_ROOT/config.inc.php" <<PMACONF
<?php
\$cfg['blowfish_secret'] = '${BLOWFISH}';
\$i = 1;
\$cfg['Servers'][\$i]['auth_type']  = 'cookie';
\$cfg['Servers'][\$i]['host']       = '127.0.0.1';
\$cfg['Servers'][\$i]['compress']   = false;
\$cfg['Servers'][\$i]['AllowNoPassword'] = false;
\$cfg['UploadDir']   = '';
\$cfg['SaveDir']     = '';
\$cfg['TempDir']     = '${PMA_ROOT}/tmp';
\$cfg['DefaultLang'] = 'fa';
\$cfg['LoginCookieValidity'] = 3600;
PMACONF
    mkdir -p "$PMA_ROOT/tmp"
    chown -R "$APP_USER":"$APP_USER" "$PMA_ROOT/tmp" "$PMA_ROOT/config.inc.php"
    chmod 700 "$PMA_ROOT/tmp"
    PMA_ENABLED="yes"
    ok "phpMyAdmin installed"

    if [[ "$SECURE_PMA" == "yes" ]]; then
      apt-get install -y -qq apache2-utils >/dev/null
      htpasswd -bc /etc/nginx/.pma_htpasswd "$PMA_HTTP_USER" "$PMA_HTTP_PASS" >/dev/null 2>&1
      chown root:"$APP_USER" /etc/nginx/.pma_htpasswd; chmod 640 /etc/nginx/.pma_htpasswd
      ok "phpMyAdmin protected with an extra HTTP password"
    fi
  else
    warn "Downloading phpMyAdmin failed. Trying the apt package..."
    if apt-get install -y -qq phpmyadmin >/dev/null 2>&1; then
      PMA_ROOT="/usr/share/phpmyadmin"; PMA_ENABLED="yes"; ok "phpMyAdmin installed from apt"
    else
      warn "phpMyAdmin was not installed. The system works fine without it."
      warn "Install it later with:  sudo bash install.sh --pma-file /path/to/phpMyAdmin.tar.gz"
    fi
  fi
fi

# =============================================================================
#  7) Self-signed certificate
# =============================================================================
SSL_DIR="/etc/ssl/boniad-form"
if [[ "$USE_SSL" == "yes" && "$IS_UPDATE" == "yes" && -f "$SSL_DIR/server.crt" && -f "$SSL_DIR/server.key" ]]; then
  ok "Existing HTTPS certificate kept"
elif [[ "$USE_SSL" == "yes" ]]; then
  say "Generating self-signed certificate for $SERVER_IP ..."
  mkdir -p "$SSL_DIR"
  openssl req -x509 -nodes -newkey rsa:2048 -days 3650 \
    -keyout "$SSL_DIR/server.key" -out "$SSL_DIR/server.crt" \
    -subj "/C=IR/O=Boniad Maskan/CN=$SERVER_IP" \
    -addext "subjectAltName=IP:$SERVER_IP,DNS:localhost" >/dev/null 2>&1
  chmod 600 "$SSL_DIR/server.key"
  ok "Certificate created (browsers will show a warning - that is expected)"
fi

# =============================================================================
#  8) Nginx
# =============================================================================
say "Configuring Nginx..."
if [[ "$IS_UPDATE" == "yes" && -f "$NGINX_SITES_DIR/${SITE_NAME}" ]]; then
  # Keep the existing site (port, HTTPS, phpMyAdmin, your own tweaks); only the upload limit is checked.
  patch_nginx_limits
else

PMA_BLOCK=""
if [[ "$PMA_ENABLED" == "yes" ]]; then
  PMA_AUTH=""
  if [[ "$SECURE_PMA" == "yes" ]]; then
    PMA_AUTH="        auth_basic \"phpMyAdmin\";
        auth_basic_user_file /etc/nginx/.pma_htpasswd;"
  fi
  PMA_BLOCK="
    location ^~ /phpmyadmin {
        alias ${PMA_ROOT};
        index index.php;
${PMA_AUTH}

        location ~ ^/phpmyadmin/(.+\.php)\$ {
            alias ${PMA_ROOT}/\$1;
            fastcgi_pass unix:${FPM_SOCK};
            fastcgi_index index.php;
            include fastcgi_params;
            fastcgi_param SCRIPT_FILENAME \$request_filename;
        }
        location ~* ^/phpmyadmin/(.+\.(jpg|jpeg|gif|css|png|js|ico|html|xml|txt|woff2?|svg|map))\$ {
            alias ${PMA_ROOT}/\$1;
        }
    }
"
fi

SSL_LISTEN=""
if [[ "$USE_SSL" == "yes" ]]; then
  SSL_LISTEN="    listen ${APP_PORT} ssl;
    ssl_certificate     ${SSL_DIR}/server.crt;
    ssl_certificate_key ${SSL_DIR}/server.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;"
else
  SSL_LISTEN="    listen ${APP_PORT};"
fi

cat > "$NGINX_SITES_DIR/${SITE_NAME}" <<NGINX
server {
${SSL_LISTEN}
    server_name _;

    root ${APP_DIR}/public;
    index index.php;

    charset utf-8;
    client_max_body_size 12m;
    client_body_timeout 120s;

    access_log /var/log/nginx/${SITE_NAME}.access.log;
    error_log  /var/log/nginx/${SITE_NAME}.error.log;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "same-origin" always;

    gzip on;
    gzip_types text/css application/javascript application/json image/svg+xml;
    gzip_min_length 512;

    location / {
        try_files \$uri \$uri/ /index.php\$is_args\$args;
    }

    location ~ ^/index\.php(/|\$) {
        fastcgi_pass unix:${FPM_SOCK};
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param PATH_INFO \$fastcgi_path_info;
        fastcgi_read_timeout 120;
        fastcgi_buffers 16 16k;
        fastcgi_buffer_size 32k;
    }

    location ~* \.(css|js|woff2?|png|jpg|jpeg|svg|ico)\$ {
        expires 7d;
        access_log off;
        try_files \$uri =404;
    }

    location ~ /\. { deny all; }
    location ~ \.php\$ { return 404; }
${PMA_BLOCK}
}
NGINX

ln -sf "$NGINX_SITES_DIR/${SITE_NAME}" "/etc/nginx/sites-enabled/${SITE_NAME}"
if [[ "$APP_PORT" == "80" && -e /etc/nginx/sites-enabled/default ]]; then
  rm -f /etc/nginx/sites-enabled/default
fi
fi

nginx -t >/dev/null 2>&1 || { nginx -t; die "Nginx configuration is invalid."; }
systemctl enable --now nginx >/dev/null 2>&1 || true
systemctl reload nginx
systemctl enable --now "php${PHPVER}-fpm" >/dev/null 2>&1 || true
systemctl restart "php${PHPVER}-fpm"
ok "Nginx configured"

# =============================================================================
#  9) Firewall
# =============================================================================
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi "^Status: active"; then
  ufw allow "${APP_PORT}/tcp" >/dev/null 2>&1 || true
  ok "Port ${APP_PORT} opened in the firewall"
fi

# =============================================================================
#  10) Backup script
# =============================================================================
say "Installing the backup script..."
cat > /usr/local/bin/boniad-backup <<BACKUP
#!/usr/bin/env bash
# Database + uploaded documents backup for the Personal Information Form System
set -euo pipefail
APP_DIR="${APP_DIR}"
OUT="\${APP_DIR}/storage/backup"
STAMP="\$(date +%Y-%m-%d_%H%M%S)"
mkdir -p "\$OUT"

case "${PDO_DRIVER}" in
  mysql)
    mysqldump --single-transaction --default-character-set=utf8mb4 \\
      -u '${DB_USER}' -p'${DB_PASS}' '${DB_NAME}' | gzip > "\$OUT/db_\${STAMP}.sql.gz" ;;
  pgsql)
    PGPASSWORD='${DB_PASS}' pg_dump -h 127.0.0.1 -U '${DB_USER}' '${DB_NAME}' | gzip > "\$OUT/db_\${STAMP}.sql.gz" ;;
  sqlite)
    gzip -c '${DB_NAME}' > "\$OUT/db_\${STAMP}.sqlite.gz" ;;
esac

find "\$OUT" -name 'db_*.gz' -mtime +30 -delete

# Uploaded documents: incremental copy (only new/changed files; nothing is ever deleted from the backup)
if [ -d "\${APP_DIR}/storage/uploads" ]; then
  mkdir -p "\$OUT/uploads"
  cp -au "\${APP_DIR}/storage/uploads/." "\$OUT/uploads/"
fi
echo "Backup created: \$OUT/db_\${STAMP}"
BACKUP
chmod 750 /usr/local/bin/boniad-backup

cat > /etc/cron.d/boniad-backup <<CRON
# Daily backup at 02:00
0 2 * * * root /usr/local/bin/boniad-backup >/dev/null 2>&1
CRON
ok "Daily backup enabled (storage/backup: 30 database copies + uploaded documents)"

# =============================================================================
#  11) Final checks
# =============================================================================
if [[ -f "$APP_DIR/tools/selftest.php" ]]; then
  say "Running the built-in test suite..."
  if sudo -u "$APP_USER" php "$APP_DIR/tools/selftest.php"; then
    ok "Built-in tests passed"
  else
    warn "Some built-in tests failed - review the output above."
  fi
fi

say "Checking the login captcha..."
if php -r 'exit(extension_loaded("gd") && function_exists("imagettftext") ? 0 : 1);'; then
  if [[ -f "$APP_DIR/public/assets/fonts/Vazirmatn-Bold.ttf" ]] \
     || ls /usr/share/fonts/truetype/dejavu/*.ttf >/dev/null 2>&1; then
    ok "Image captcha is ready"
  else
    warn "No TrueType font found; captcha will be drawn at lower quality."
  fi
else
  warn "PHP GD extension is missing; captcha falls back to SVG."
fi

say "Testing the service..."
SCHEME="http"; [[ "$USE_SSL" == "yes" ]] && SCHEME="https"
sleep 1
HTTP_CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 "$SCHEME://127.0.0.1:$APP_PORT/" || echo 000)"
if [[ "$HTTP_CODE" == "200" ]]; then
  ok "Service responds (HTTP $HTTP_CODE)"
else
  warn "Service returned HTTP $HTTP_CODE"
  warn "Logs: /var/log/nginx/${SITE_NAME}.error.log and $APP_DIR/storage/logs/php-error.log"
fi

# =============================================================================
#  Summary
# =============================================================================
CRED_FILE="/root/boniad-form-credentials.txt"
if [[ "$IS_UPDATE" == "yes" ]]; then
  # Nothing about accounts or passwords changed, so the credentials file is left alone
  { echo; echo "[ Update ]  $(date)  ->  version $VERSION_NEW  (files: $UPD_NEW new, $UPD_CHANGED replaced, $UPD_REMOVED removed; backup: $UPDATE_BACKUP)"; } >> "$CRED_FILE" 2>/dev/null || true
  chmod 600 "$CRED_FILE" 2>/dev/null || true
  echo
  hr
  echo -e "  ${C_G}${C_B}Update completed successfully${C_R}"
  hr
  echo "   Version       : $INSTALLED_VERSION  ->  $VERSION_NEW"
  echo "   Files         : $UPD_NEW new, $UPD_CHANGED replaced, $UPD_REMOVED removed, $UPD_SAME identical"
  echo "   Previous files: $UPDATE_BACKUP"
  echo "   Public form   : $SCHEME://$SERVER_IP:$APP_PORT/"
  echo "   Admin panel   : $SCHEME://$SERVER_IP:$APP_PORT/admin"
  echo "   Accounts, passwords, database, uploads and settings were NOT changed."
  echo "   To roll back  : sudo tar -xzf $UPDATE_BACKUP -C $APP_DIR && sudo systemctl restart php${PHPVER}-fpm"
  hr
  echo
  exit 0
fi
{
  echo "==============================================================="
  echo " Personal Information Form System - Installation details"
  echo " Installed at: $(date)"
  echo "==============================================================="
  echo
  echo "[ URLs ]"
  echo "  Public form   : $SCHEME://$SERVER_IP:$APP_PORT/"
  echo "  Admin panel   : $SCHEME://$SERVER_IP:$APP_PORT/admin"
  echo "  Track status  : $SCHEME://$SERVER_IP:$APP_PORT/track"
  [[ "$PMA_ENABLED" == "yes" ]] && echo "  phpMyAdmin    : $SCHEME://$SERVER_IP:$APP_PORT/phpmyadmin"
  echo
  echo "[ Admin panel login ]"
  echo "  Username : $ADMIN_USER"
  echo "  Password : $ADMIN_PASS"
  echo
  echo "[ Database ($DB_ENGINE) ]"
  echo "  Name     : $DB_NAME"
  echo "  User     : $DB_USER"
  echo "  Password : $DB_PASS"
  if [[ "$PMA_ENABLED" == "yes" ]]; then
    echo
    echo "[ phpMyAdmin login ]"
    echo "  User     : $PMA_DB_USER"
    echo "  Password : $PMA_DB_PASS"
    if [[ "$SECURE_PMA" == "yes" ]]; then
      echo "  Extra HTTP auth -> user: $PMA_HTTP_USER  password: $PMA_HTTP_PASS"
    fi
  fi
  echo
  echo "[ Paths ]"
  echo "  Application  : $APP_DIR"
  echo "  Config file  : $APP_DIR/app/config.php"
  echo "  App log      : $APP_DIR/storage/logs/php-error.log"
  echo "  Nginx log    : /var/log/nginx/${SITE_NAME}.error.log"
  echo "  Backups      : $APP_DIR/storage/backup  (daily at 02:00)"
  echo "  Manual backup: sudo /usr/local/bin/boniad-backup"
} > "$CRED_FILE"
chmod 600 "$CRED_FILE"

echo
hr
echo -e "  ${C_G}${C_B}Installation completed successfully${C_R}"
hr
cat "$CRED_FILE"
hr
echo -e "  ${C_Y}These details were saved to:${C_R} $CRED_FILE"
[[ "$USE_SSL" != "yes" ]] && echo -e "  ${C_Y}Tip:${C_R} re-run with --ssl to encrypt traffic on the network."
echo -e "  ${C_Y}Change the admin password from Settings after your first login.${C_R}"
echo
